﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using JulMar.Windows.Mvvm;
using System;
using PictureViewer.Data;

namespace PictureViewer.ViewModels
{
    /// <summary>
    /// The ViewModel for the application
    /// </summary>
    public class MainViewModel : ViewModel
    {
        private bool _showTitles;
        private PictureViewModel _selectedPicture;

        public const string RemovePictureMessage = "RemovePicture";

        /// <summary>
        /// True to show titles
        /// </summary>
        public bool ShowTitles
        {
            get { return _showTitles; }
            set { _showTitles = value; OnPropertyChanged("ShowTitles"); }
        }

        /// <summary>
        /// The currently selected picture
        /// </summary>
        public PictureViewModel SelectedPicture
        {
            get { return _selectedPicture; }
            set { _selectedPicture = value; OnPropertyChanged("SelectedPicture"); }
        }

        /// <summary>
        /// The collection of pictures
        /// </summary>
        public ObservableCollection<PictureViewModel> Pictures { get; private set; }

        /// <summary>
        /// Command to display the selected picture properties
        /// </summary>
        public ICommand ShowPropertiesCommand { get; private set; }

        /// <summary>
        /// Add a new picture
        /// </summary>
        public ICommand AddNewCommand { get; private set; }

        /// <summary>
        /// Remove a picture
        /// </summary>
        public ICommand RemoveCommand { get; private set; }

        /// <summary>
        /// Command to shut the applicationd down.
        /// </summary>
        public ICommand ExitCommand { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public MainViewModel()
        {
            // Allow this to be targeted by the message mediator
            RegisterWithMessageMediator();

            // Show titles.
            ShowTitles = true;

            // Load pictures from the user's pictures folder
            var pictures = PictureLocator.LoadFromPath(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures))
                .Select(pe => new PictureViewModel(pe));

            Pictures = new ObservableCollection<PictureViewModel>(pictures);
            ShowPropertiesCommand = new DelegatingCommand<PictureViewModel>(p => p.ShowProperties(), p => p != null);
            AddNewCommand = new DelegatingCommand(OnAddNewPicture);
            RemoveCommand = new DelegatingCommand<PictureViewModel>(OnRemovePicture, p => p != null);

            ExitCommand = new DelegatingCommand(() => RaiseCloseRequest(true));
        }

        /// <summary>
        /// Adds a new picture
        /// </summary>
        private void OnAddNewPicture()
        {
            PictureViewModel pictureViewModel = new PictureViewModel();
            pictureViewModel.ShowProperties();
            if (pictureViewModel.IsValid)
            {
                Pictures.Add(pictureViewModel);
            }
        }

        /// <summary>
        /// Removes a pictures
        /// </summary>
        /// <param name="pictureViewModel"></param>
        [MessageMediatorTarget(RemovePictureMessage)]
        private void OnRemovePicture(PictureViewModel pictureViewModel)
        {
            Pictures.Remove(pictureViewModel);
        }
    }
}