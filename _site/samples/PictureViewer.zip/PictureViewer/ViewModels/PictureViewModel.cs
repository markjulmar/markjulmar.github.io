﻿using System.Windows.Input;
using JulMar.Windows.Mvvm;
using PictureViewer.Data;
using System.Windows;
using JulMar.Windows.Interfaces;
using PictureViewer.Interfaces;

namespace PictureViewer.ViewModels
{
    /// <summary>
    /// ViewModel to represent a picture image
    /// </summary>
    public class PictureViewModel : ViewModel
    {
        private readonly PictureInfo _picture;
        private bool _isSelected;

        /// <summary>
        /// Title for the picture
        /// </summary>
        public string Title
        {
            get { return _picture.Title; }
            set { _picture.Title = value; OnPropertyChanged("Title"); }
        }

        /// <summary>
        /// True if this image is selected in the view
        /// </summary>
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; OnPropertyChanged("IsSelected"); }
        }

        /// <summary>
        /// Position (X)
        /// </summary>
        public int X
        {
            get { return (int) _picture.X; }
            set { _picture.X = value; OnPropertyChanged("X"); }
        }

        /// <summary>
        /// Position (Y)
        /// </summary>
        public int Y
        {
            get { return (int) _picture.Y; }
            set { _picture.Y = value; OnPropertyChanged("Y"); }
        }

        /// <summary>
        /// Center point for the elliptical clipping path
        /// </summary>
        public Point CenterPoint
        {
            get { return new Point(Width/2,Height/2); }
        }

        /// <summary>
        /// Radius of the elliptical clipping path
        /// </summary>
        public double RadiusX
        {
            get { return Width/2; }
        }

        /// <summary>
        /// Radius of the elliptical clipping path
        /// </summary>
        public double RadiusY
        {
            get { return Height / 2; }
        }

        /// <summary>
        /// Top of the clipping rectangle for the triangle shape
        /// </summary>
        public Point ClippingT1
        {
            get { return new Point(Width / 2, 0); }
        }

        /// <summary>
        /// Left/Bottom of the clipping rectangle for the triangle shape
        /// </summary>
        public Point ClippingT2
        {
            get { return new Point(0, Height); }
        }

        /// <summary>
        /// Right/Bottom of the clipping rectangle for the triangle shape
        /// </summary>
        public Point ClippingT3
        {
            get { return new Point(Width, Height); }
        }

        /// <summary>
        /// Width
        /// </summary>
        public double Width
        {
            get { return _picture.Width; }
            set { _picture.Width = value; OnPropertyChanged("Width", "CenterPoint", "RadiusX", "ClippingT1", "ClippingT3"); }
        }

        /// <summary>
        /// Height
        /// </summary>
        public double Height
        {
            get { return _picture.Height; }
            set { _picture.Height = value; OnPropertyChanged("Height", "CenterPoint", "RadiusY", "ClippingT2", "ClippingT3"); }
        }

        /// <summary>
        /// Clipping style
        /// </summary>
        public ClippingStyle ClipStyle
        {
            get { return _picture.ClipStyle; }
            set { _picture.ClipStyle = value; OnPropertyChanged("ClipStyle"); }
        }

        /// <summary>
        /// Image to display (file path)
        /// </summary>
        public string Image
        {
            get { return _picture.ImageUrl; }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    _picture.ImageUrl = value;
                    OnPropertyChanged("Image");
                }
            }
        }

        /// <summary>
        /// True/False if the image exists
        /// </summary>
        public bool IsValid
        {
            get { return System.IO.File.Exists(Image) && Width > 0 && Height > 0; }
        }

        /// <summary>
        /// Command to show the image properties.
        /// </summary>
        public ICommand ShowPropertiesCommand { get; private set; }

        /// <summary>
        /// Command to select a new file.
        /// </summary>
        public ICommand SelectNewImageFile { get; private set; }

        /// <summary>
        /// Command to remove this picture
        /// </summary>
        public ICommand RemovePicture { get; private set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public PictureViewModel()
        {
            _picture = new PictureInfo();
            ShowPropertiesCommand = new DelegatingCommand(ShowProperties);
            SelectNewImageFile = new DelegatingCommand(OnSelectNewFile);
            RemovePicture = new DelegatingCommand(() => SendMessage(MainViewModel.RemovePictureMessage, this));
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="pictureInfo">Underlying data</param>
        public PictureViewModel(PictureInfo pictureInfo) : this()
        {
            _picture = pictureInfo;
        }

        /// <summary>
        /// Display the UI associated with this picture
        /// </summary>
        internal void ShowProperties()
        {
            var uiVisualizer = Resolve<IUIVisualizer>();
            if (uiVisualizer != null)
            {
                uiVisualizer.ShowDialog("ShowElementProperties", this);
            }
        }

        /// <summary>
        /// Selects a new filename
        /// </summary>
        private void OnSelectNewFile()
        {
            ISelectFile fileSelector = Resolve<ISelectFile>();
            if (fileSelector != null)
            {
                string filename = fileSelector.SelectFile("Image Files|*.jpg;*.bmp;*.tif;*.png");
                if (!string.IsNullOrEmpty(filename))
                    Image = filename;
            }
        }
    }
}
