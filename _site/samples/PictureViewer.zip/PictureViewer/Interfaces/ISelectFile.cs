﻿namespace PictureViewer.Interfaces
{
    public interface ISelectFile
    {
        string SelectFile(string fileFilters);
    }
}
