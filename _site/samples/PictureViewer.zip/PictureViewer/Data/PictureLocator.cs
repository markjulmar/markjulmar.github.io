﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace PictureViewer.Data
{
    /// <summary>
    /// Class to load pictures
    /// </summary>
    public static class PictureLocator
    {
        private static readonly string[] SearchPatterns = {"*.jpg", "*.bmp", "*.tif", "*.png"};

        /// <summary>
        /// Loads all the images from a specified path
        /// </summary>
        /// <param name="path">Path</param>
        /// <returns>iterator of PictureInfo objects</returns>
        public static IEnumerable<PictureInfo> LoadFromPath(string path)
        {
            var rndGenerator = new Random();

            // Foreach of the search patterns
            return SearchPatterns
                // ..Get all the matching filenames
                .Select(s => Directory.GetFiles(path, s))
                // ..Concact into a single sequence of filenames
                .SelectMany(sc => sc.AsEnumerable())
                // ..create a PictureInfo to represent each one
                .Select(file => new PictureInfo
                    {
                        ImageUrl = file,
                        ClipStyle = (ClippingStyle) rndGenerator.Next(Enum.GetValues(typeof (ClippingStyle)).Length),
                        Width = rndGenerator.Next(100,300),
                        Height = rndGenerator.Next(100,300),
                        Title = Path.GetFileName(file),
                        X = rndGenerator.NextDouble()*800,
                        Y = rndGenerator.NextDouble()*600
                    });
        }
    }
}
