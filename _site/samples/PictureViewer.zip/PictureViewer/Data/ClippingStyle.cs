﻿namespace PictureViewer.Data
{
    /// <summary>
    /// Clipping style for the images
    /// </summary>
    public enum ClippingStyle
    {
        /// <summary>
        /// Clip in a rectangle (default)
        /// </summary>
        Rectangle,
        /// <summary>
        /// Clip in an ellipse/circle
        /// </summary>
        Circle,
        /// <summary>
        /// Clip in a triangle
        /// </summary>
        Triangle
    }
}