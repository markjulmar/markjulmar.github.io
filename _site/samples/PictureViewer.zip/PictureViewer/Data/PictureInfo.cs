namespace PictureViewer.Data
{
    /// <summary>
    /// Represents a single picture to display
    /// </summary>
    public class PictureInfo
    {
        /// <summary>
        /// Shape that clips the picture.
        /// </summary>
        public ClippingStyle ClipStyle { get; set; }

        /// <summary>
        /// Title of the picture
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// URL for the image
        /// </summary>
        public string ImageUrl { get; set; }

        /// <summary>
        /// Left coordinate
        /// </summary>
        public double X { get; set; }

        /// <summary>
        /// Top coordinate
        /// </summary>
        public double Y { get; set; }

        /// <summary>
        /// Width of the displayed image
        /// </summary>
        public double Width { get; set; }

        /// <summary>
        /// Height of the displayed image
        /// </summary>
        public double Height { get; set; }
    }
}