﻿namespace PictureViewer.Views
{
    public partial class PropertyWindow
    {
        public PropertyWindow()
        {
            InitializeComponent();
        }
    }
}


