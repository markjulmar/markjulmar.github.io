﻿using PictureViewer.Interfaces;
using Microsoft.Win32;

namespace PictureViewer.Services
{
    /// <summary>
    /// Simple open file dialog selector service
    /// </summary>
    public class OpenFileDialogSelector : ISelectFile
    {
        public string SelectFile(string fileFilters)
        {
            var openFileDialog = new OpenFileDialog
             {
                 Multiselect = false,
                 CheckFileExists = true,
                 Filter = fileFilters,
                 RestoreDirectory = true
             };

            // Display the open file dialog to prompt the user.
            if (openFileDialog.ShowDialog().Value)
            {
                return openFileDialog.FileName;
            }

            return null;
        }
    }
}
