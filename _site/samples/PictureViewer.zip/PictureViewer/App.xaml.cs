﻿using JulMar.Windows.Mvvm;
using JulMar.Windows.Interfaces;
using PictureViewer.Interfaces;
using PictureViewer.Services;
using PictureViewer.Views;

namespace PictureViewer
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        public App()
        {
            // Register the typical services (UI, Error, etc.) for this application.
            ViewModel.RegisterKnownServiceTypes();

            // Register the file selector service.
            ViewModel.ServiceProvider.Add(typeof(ISelectFile), new OpenFileDialogSelector());

            // Register the UI dialogs.
            var uiVisualizer = ViewModel.ServiceProvider.Resolve<IUIVisualizer>();
                uiVisualizer.Register("ShowElementProperties", typeof(PropertyWindow));
        }
    }
}
