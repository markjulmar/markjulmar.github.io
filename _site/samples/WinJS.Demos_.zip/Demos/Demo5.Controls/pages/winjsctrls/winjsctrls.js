﻿// For an introduction to the Page Control template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232511
(function () {
    "use strict";

    WinJS.UI.Pages.define("/pages/winjsctrls/winjsctrls.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {
            // TODO: Initialize the page here.

            // Pages automatically call this for you.. normally
            // you would have to tell the system about all your WinJS controls.
            //WinJS.UI.processAll();

            var cameraSelect = document.getElementById("selectCamera");
            var menu = document.getElementById("cameraMenu").winControl;

            cameraSelect.addEventListener("click", function() {
                menu.show(cameraSelect, "bottom");
            });
        },

        unload: function () {
            // TODO: Respond to navigations away from this page.
        },

        updateLayout: function (element) {
            /// <param name="element" domElement="true" />

            // TODO: Respond to changes in layout.
        }
    });
})();
