﻿(function () {
    "use strict";

    WinJS.Namespace.define("Binding.Mode", {
        twoWay: WinJS.Binding.initializer(function(source, sourceProps, dest, destProps) {
            WinJS.Binding.defaultBind(source, sourceProps, dest, destProps);

            dest.onchange = function() {
                var d = dest[destProps[0]];
                var s = source[sourceProps[0]];
                if (s !== d) source[sourceProps[0]] = d;
            };
        })
    });

    WinJS.UI.Pages.define("/pages/home/home.html", {
        // This function is called whenever a user navigates to this page. It
        // populates the page elements with the app's data.
        ready: function (element, options) {

            var book = {
                title: "Harry Potter and the Chamber of Secrets",
                author: "J.K. Rowling",
                price: 7.99
            };

            var bookViewModel = WinJS.Binding.as(book);

            document.getElementById("updatePrice").addEventListener("click", function() {
                bookViewModel.price *= 2;
            });

            WinJS.Binding.processAll(null, bookViewModel);
        }
    });
})();
