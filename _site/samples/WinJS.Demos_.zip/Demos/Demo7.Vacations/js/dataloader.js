﻿(function() {

    "use strict";

    var vacations = new WinJS.Binding.List();

    var uri = new Windows.Foundation.Uri("ms-appx:///data/vacationData.txt");
    Windows.Storage.StorageFile.getFileFromApplicationUriAsync(uri)
        .then(Windows.Storage.FileIO.readTextAsync)
        .done(function(jsonText) {
            var data = JSON.parse(jsonText);
            data.vacations.forEach(function(cat) {
                cat.destinations.forEach(function(v) {
                    vacations.push(WinJS.Binding.as(v));
                });
            });
        });

    WinJS.Namespace.define("VacationData", { allVacations: vacations });

})();