﻿// For an introduction to the Blank template, see the following documentation:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    var localSettings = Windows.Storage.ApplicationData.current.localSettings;
    var AES = Windows.ApplicationModel.Activation.ApplicationExecutionState;

    var logger = new function () {
        this.key = "appLog";

        this.add = function (msg) {
            msg = "<li>" + (new Date()).toLocaleTimeString() + ": " + msg + "</li>";
            var store = localSettings.values;
            if (store.hasKey(this.key)) {
                store[this.key] += msg;
            }
            else {
                store[this.key] = msg;
            }
        };

        this.clear = function () {
            var store = localSettings.values;
            store.remove(this.key);
        };

        this.refresh = function () {
            var store = localSettings.values;
            var host = document.getElementById("events");

            if (store.hasKey(this.key)) {
                WinJS.Utilities.setInnerHTML(host, "<ul>" + store[this.key] + "</ul>");
            }
            else {
                WinJS.Utilities.empty(host);
            }
        };
    };

    // exposes logger variable as "Application.log"
    WinJS.Namespace.define("Application", { log: logger });

    document.addEventListener("DOMContentLoaded", function () {
        Application.log.add("document.DOMContentLoaded");
    });

    document.addEventListener("visibilitychange", function () {
        Application.log.add("document.visibilitychanged: " + document.visibilityState);
    });

    app.onloaded = function (e) {
        Application.log.add("app.onloaded");
    };

    app.onready = function (e) {
        Application.log.add("app.onready");
    };

    app.onactivated = function (args) {

        var state = "unknown";
        switch (args.detail.previousExecutionState)
        {
            case AES.closedByUser:
                state = "closedByUser";
                break;
            case AES.notRunning:
                state = "notRunning";
                break;
            case AES.running:
                state = "running";
                break;
            case AES.suspended:
                state = "suspended";
                break;
            case AES.terminated:
                state = "terminated";
                break;
        }

        Application.log.add("app.onactivated: " + state);

        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: This application has been newly launched. Initialize
                // your application here.
            } else {
                // TODO: This application has been reactivated from suspension.
                // Restore application state here.
            }
            args.setPromise(WinJS.UI.processAll().then(function() {
                Application.log.refresh();
            }));

            document.getElementById("clear").addEventListener("click", function () {
                Application.log.clear();
                Application.log.refresh();
            });

            document.getElementById("refresh").addEventListener("click", function () {
                Application.log.refresh();
            });
        }
    };

    app.oncheckpoint = function (args) {
        // TODO: This application is about to be suspended. Save any state
        // that needs to persist across suspensions here. You might use the
        // WinJS.Application.sessionState object, which is automatically
        // saved and restored across suspension. If you need to complete an
        // asynchronous operation before your application is suspended, call
        // args.setPromise().

        Application.log.add("app.oncheckpoint");
    };

    Windows.UI.WebUI.WebUIApplication.addEventListener("resuming", function (e) {
        Application.log.add("app.onresuming");
    });

    app.start();
})();
