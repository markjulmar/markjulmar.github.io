using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace SequenceRibbonUI.ViewModels
{
    /// <summary>
    /// This View Model which represents a group within 
    /// the Ribbon.
    /// </summary>
    public class RibbonItemViewModel
    {
        /// <summary>
        /// The text for the header on the group
        /// </summary>
        public string Header { get; set; }

        /// <summary>
        /// The list of items for the ribbon
        /// </summary>
        public IList<RibbonItemViewModel> Items { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public RibbonItemViewModel()
        {
            Items = new ObservableCollection<RibbonItemViewModel>();
        }
    }
}