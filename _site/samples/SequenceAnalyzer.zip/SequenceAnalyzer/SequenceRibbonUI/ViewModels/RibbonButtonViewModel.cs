using System.Windows.Input;

namespace SequenceRibbonUI.ViewModels
{
    /// <summary>
    /// This View Model provides context for each button in the
    /// Ribbon UI
    /// </summary>
    public class RibbonButtonViewModel : RibbonItemViewModel
    {
        /// <summary>
        /// Command to execute
        /// </summary>
        public ICommand Command { get; set; }

        /// <summary>
        /// Small Image to display
        /// </summary>
        public string SmallImageUrl { get; set; }

        /// <summary>
        /// Large Image to display
        /// </summary>
        public string LargeImageUrl { get; set; }
    }
}