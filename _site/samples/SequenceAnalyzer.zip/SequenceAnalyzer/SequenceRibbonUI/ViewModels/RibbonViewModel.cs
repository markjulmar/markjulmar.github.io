﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Contracts;
using Microsoft.Practices.Prism.ViewModel;

namespace SequenceRibbonUI.ViewModels
{
    /// <summary>
    /// The ViewModel for the ribbon UI.  This is instantiated as
    /// a singleton with PRISM.
    /// </summary>
    public class RibbonViewModel : NotificationObject, IRibbonCommand
    {
        /// <summary>
        /// The items for the ribbon
        /// </summary>
        public IList<RibbonItemViewModel> Items { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public RibbonViewModel()
        {
            Items = new ObservableCollection<RibbonItemViewModel>();
        }

        /// <summary>
        /// Registers a new command with the Ribbon.  The
        /// Command is tied to a RibbonButton.
        /// </summary>
        /// <param name="groupName">Group to place it in</param>
        /// <param name="label">Label for the button</param>
        /// <param name="largeImageUrl">URL for the Large Image</param>
        /// <param name="smallImageUrl">URL for the Small Image</param>
        /// <param name="command">Command to execute when button is clicked.</param>
        public void RegisterViewWithRibbon(string groupName, 
            string label, string largeImageUrl, 
            string smallImageUrl, ICommand command)
        {
            // Find the group name.
            var groupItem = Items.SingleOrDefault(item => item.Header == groupName);
            if (groupItem == null)
            {
                groupItem = new RibbonItemViewModel() {Header = groupName};
                Items.Add(groupItem);
            }

            // Add the command.
            groupItem.Items.Add(new RibbonButtonViewModel
            {
                Header = label,
                LargeImageUrl = largeImageUrl,
                SmallImageUrl = smallImageUrl,
                Command = command
            });
        }
    }
}
