﻿using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Prism.Regions;
using Contracts;
using SequenceRibbonUI.Views;
using SequenceRibbonUI.ViewModels;

namespace SequenceRibbonUI.Modules
{
    /// <summary>
    /// Prism initialization module
    /// </summary>
    public class InitModule : IModule
    {
        private readonly IUnityContainer _container;
        private readonly IRegionManager _regionManager;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="container">Injected Unity container</param>
        /// <param name="regionManager">Injection region manager from Prism</param>
        public InitModule(IUnityContainer container, IRegionManager regionManager)
        {
            _container = container;
            _regionManager = regionManager;
        }

        /// <summary>
        /// Notifies the module that it has be initialized.
        /// </summary>
        public void Initialize()
        {
            // Force a singleton for the VM so we get the same object
            // for all registrations
            _container.RegisterType<IRibbonCommand, RibbonViewModel>(
                new ContainerControlledLifetimeManager());

            // Associate our Ribbon UI with the appropriate region
            // in the main window.
            _regionManager.RegisterViewWithRegion("RibbonRegion", typeof (RibbonView));
        }
    }
}
