﻿using SequenceRibbonUI.ViewModels;

namespace SequenceRibbonUI.Views
{
    /// <summary>
    /// Interaction logic for RibbonView.xaml
    /// </summary>
    public partial class RibbonView
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="viewModel">Injected ViewModel</param>
        public RibbonView(RibbonViewModel viewModel)
        {
            DataContext = viewModel;
            InitializeComponent();
        }
    }
}
