using System.Collections.Generic;
using Bio;
using Microsoft.Practices.Prism.Events;

namespace SequenceLoaderUI.Modules
{
    /// <summary>
    /// Module event to indicate our service has loaded new sequences
    /// </summary>
    internal class LoadedNewSequenceEvent : CompositePresentationEvent<IEnumerable<ISequence>>
    {
    }
}