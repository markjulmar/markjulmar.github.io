﻿using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.Regions;
using SequenceLoaderUI.Views;
using Contracts;
using Microsoft.Win32;

namespace SequenceLoaderUI.Modules
{
    /// <summary>
    /// Initialization module
    /// </summary>
    public class InitModule : IModule
    {
        private readonly IRegionManager _regionManager;
        private readonly IRibbonCommand _ribbonCommands;
        private readonly ISequenceLoader _sequenceLoader;
        private readonly IEventAggregator _eventAggregator;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="regionManager">Injected region manager from Prism</param>
        /// <param name="ribbonCommands">Injected Ribbon Command service</param>
        /// <param name="sequenceLoader">Injected Sequence Loader service</param>
        /// <param name="eventAggregator">Injected Event Aggregator from Prism</param>
        public InitModule(IRegionManager regionManager, 
            IRibbonCommand ribbonCommands, 
            ISequenceLoader sequenceLoader,
            IEventAggregator eventAggregator)
        {
            _regionManager = regionManager;
            _ribbonCommands = ribbonCommands;
            _sequenceLoader = sequenceLoader;
            _eventAggregator = eventAggregator;
        }

        /// <summary>
        /// Notifies the module that it has be initialized.
        /// </summary>
        public void Initialize()
        {
            // Add our sequence list UI to the main app
            _regionManager.RegisterViewWithRegion("SequenceListRegion", typeof (SequenceListView));

            // Add a button to the Ribbon to load sequences
            _ribbonCommands.RegisterViewWithRibbon(
                "File", "Add Sequences", 
                "/SequenceLoaderUI;Component/Images/LargeIcon.png",
                "/SequenceLoaderUI;Component/Images/SmallIcon.png",
                new DelegateCommand(LoadNewSequenceFile));
        }

        /// <summary>
        /// This is called when the user clicks the button to load
        /// sequences.
        /// </summary>
        private void LoadNewSequenceFile()
        {
            // Create an OpenFileDialog prompt
            OpenFileDialog openFileDialog = new OpenFileDialog
                {
                    CheckFileExists = true,
                    DefaultExt = ".fasta",
                    Filter = "*.* (All Files)|*.*",
                    Title = "Open New Bio File"
                };

            // Prompt the user for the file
            if (openFileDialog.ShowDialog().Value)
            {
                // If they gave us a file, use the sequence loader
                // service to load it up.
                var newSequences =_sequenceLoader.Load(openFileDialog.FileName);
                if (newSequences != null)
                {
                    // Fire the loaded new sequence(s) event so
                    // our UI knows to show new sequences.
                    _eventAggregator.GetEvent<LoadedNewSequenceEvent>()
                        .Publish(newSequences);
                }
            }
        }
    }
}
