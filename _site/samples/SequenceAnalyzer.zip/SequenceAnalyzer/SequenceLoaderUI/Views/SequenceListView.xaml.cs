﻿using SequenceLoaderUI.ViewModels;

namespace SequenceLoaderUI.Views
{
    /// <summary>
    /// Interaction logic for SequenceListView.xaml
    /// </summary>
    public partial class SequenceListView
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="viewModel">Injected view model</param>
        public SequenceListView(SequenceListViewModel viewModel)
        {
            DataContext = viewModel;
            InitializeComponent();
        }
    }
}
