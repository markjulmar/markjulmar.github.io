﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Input;
using Bio;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.Interactivity.InteractionRequest;
using Sequence.Data.Events;
using SequenceLoaderUI.Modules;
using Microsoft.Practices.Prism.ViewModel;

namespace SequenceLoaderUI.ViewModels
{
    /// <summary>
    /// View Model for our sequence list
    /// </summary>
    public class SequenceListViewModel : NotificationObject
    {
        private ISequence _selectedSequence;
        private readonly IEventAggregator _eventAggregator;
        
        /// <summary>
        /// Loaded list of sequences
        /// </summary>
        public IList<ISequence> Sequences { get; private set; }

        /// <summary>
        /// Command executed to remove a sequence
        /// </summary>
        public ICommand RemoveSequence { get; private set; }

        /// <summary>
        /// Interaction Prompt used to prompt the user to delete
        /// a sequence - this is used when the user right-clicks
        /// on a sequence.
        /// </summary>
        public InteractionRequest<Confirmation> PromptDeleteRequest { get; private set; }

        /// <summary>
        /// The currently selected sequence
        /// </summary>
        public ISequence SelectedSequence
        {
            get { return _selectedSequence; }
            set
            {
                // Set the internal field, notify WPF
                _selectedSequence = value; 
                RaisePropertyChanged(() => SelectedSequence);

                // Tell the rest of the world (app) that a new
                // sequence has been selected. We pass the sequence
                // as the data so they all know what it is.
                _eventAggregator.GetEvent<SequenceSelectionEvent>()
                    .Publish(_selectedSequence);
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="eventAggregator">Injected event aggregator</param>
        public SequenceListViewModel(IEventAggregator eventAggregator)
        {
            _eventAggregator = eventAggregator;
            Sequences = new ObservableCollection<ISequence>();

            eventAggregator.GetEvent<LoadedNewSequenceEvent>()
                .Subscribe(OnNewSequencesLoaded);

            RemoveSequence = new DelegateCommand<ISequence>(OnRemoveSequence);
            PromptDeleteRequest = new InteractionRequest<Confirmation>();
        }

        /// <summary>
        /// Method used to remove a sequence from the list.
        /// </summary>
        /// <param name="sequence">Sequence to remove</param>
        private void OnRemoveSequence(ISequence sequence)
        {
            Debug.Assert(Sequences.Contains(sequence));

            int pos = Sequences.IndexOf(sequence);

            // Prompt the user to delete the sequence.
            PromptDeleteRequest.Raise(
                new Confirmation
                    {
                        Content = "Are you sure you want to remove " + sequence.ID,
                        Title = "Remove a sequence?"
                    },
                cb =>
                    {
                        if (cb.Confirmed)
                        {
                            Sequences.Remove(sequence);
                            SelectedSequence = Sequences.Count > 0 ? Sequences[pos] : null;
                        }
                    });
        }

        /// <summary>
        /// This method is invoked when the loader service loads
        /// one or more sequences from a file.  Here we will add them
        /// into the UI.
        /// </summary>
        /// <param name="sequences">Newly available sequences</param>
        private void OnNewSequencesLoaded(IEnumerable<ISequence> sequences)
        {
            // Add the new sequences to our UI list.
            foreach (var seq in sequences)
                Sequences.Add(seq);

            // If we don't have a selected sequence, then select the first one.
            if (SelectedSequence == null)
                SelectedSequence = Sequences.First();
        }
    }
}
