﻿using System.Windows;
using System.Windows.Interactivity;
using Microsoft.Practices.Prism.Interactivity.InteractionRequest;

namespace WPF.Behaviors
{
    /// <summary>
    /// Simple MessageBox Yes/No prompt.
    /// </summary>
    public class MessageBoxPromptAction : TriggerAction<FrameworkElement>
    {
        /// <summary>
        /// Invokes the action.
        /// </summary>
        /// <param name="parameter">The parameter to the action. If the action does not require a parameter, the parameter may be set to a null reference.</param>
        protected override void Invoke(object parameter)
        {
            var args = parameter as InteractionRequestedEventArgs;
            if (args != null)
            {
                var result = MessageBox.Show(args.Context.Content as string,
                                             args.Context.Title, MessageBoxButton.YesNo);
                Confirmation confirmation = args.Context as Confirmation;
                if (confirmation != null)
                    confirmation.Confirmed = result == MessageBoxResult.Yes;

                if (args.Callback != null)
                    args.Callback();
            }
        }
    }
}
