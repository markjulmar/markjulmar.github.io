﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace SequenceDetailsUI.Views
{
    /// <summary>
    /// This converter decides on a unique color for each of the
    /// nucleotide values.
    /// </summary>
    public class NucleotideColorConverter : IValueConverter
    {
        public static Brush[] AvailableBrushes; 

        /// <summary>
        /// Initialize our available brushes
        /// </summary>
        static NucleotideColorConverter()
        {
            Random RNG = new Random(0);
            AvailableBrushes = new Brush[256];

            AvailableBrushes[(int)'A'] = Brushes.Red;
            AvailableBrushes[(int)'G'] = Brushes.Green;
            AvailableBrushes[(int)'C'] = Brushes.Blue;
            AvailableBrushes[(int)'T'] = Brushes.DarkViolet;
            AvailableBrushes[(int)'U'] = Brushes.DarkSlateBlue;
            AvailableBrushes[(int)'-'] = Brushes.LightGray;
            AvailableBrushes[(int)'*'] = Brushes.Black;

            for (int i = 0; i < 256; i++)
            {
                if (AvailableBrushes[i] == null)
                    AvailableBrushes[i] = new SolidColorBrush(
                        Color.FromRgb(
                            (byte) RNG.Next(128),
                            (byte) RNG.Next(128),
                            (byte) RNG.Next(128)));
            }
        }

        /// <summary>
        /// Converts a value. 
        /// </summary>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        /// <param name="value">The value produced by the binding source.</param><param name="targetType">The type of the binding target property.</param><param name="parameter">The converter parameter to use.</param><param name="culture">The culture to use in the converter.</param>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value is char 
                ? AvailableBrushes[(byte) ((char) value)] 
                : DependencyProperty.UnsetValue;
        }

        /// <summary>
        /// Converts a value. 
        /// </summary>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        /// <param name="value">The value that is produced by the binding target.</param><param name="targetType">The type to convert to.</param><param name="parameter">The converter parameter to use.</param><param name="culture">The culture to use in the converter.</param>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
