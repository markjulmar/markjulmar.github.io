﻿using System.Windows.Controls;
using SequenceDetailsUI.ViewModels;

namespace SequenceDetailsUI.Views
{
    /// <summary>
    /// Interaction logic for SequenceDetailsView.xaml
    /// </summary>
    public partial class SequenceDetailsView : UserControl
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="viewModel">ViewModel (injected)</param>
        public SequenceDetailsView(SequenceDetailsViewModel viewModel)
        {
            DataContext = viewModel;
            InitializeComponent();
        }
    }
}
