﻿using System.ComponentModel;
using System.Windows.Controls;
using SequenceDetailsUI.ViewModels;

namespace SequenceDetailsUI.Views
{
    /// <summary>
    /// Interaction logic for SequenceStatisticsView.xaml
    /// </summary>
    public partial class SequenceStatisticsView : UserControl
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="viewModel">ViewModel (injected)</param>
        public SequenceStatisticsView(SequenceStatisticsViewModel viewModel)
        {
            DataContext = viewModel;
            viewModel.PropertyChanged += ViewModelOnPropertyChanged;
            InitializeComponent();
        }

        /// <summary>
        /// This is called when the view model changes state.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ViewModelOnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "CurrentSequenceAlphabet" 
                && pieChart != null)
            {
                var vm = (SequenceStatisticsViewModel) sender;
                if (vm.CurrentSequenceAlphabet != null)
                {
                    pieChart.Brushes.Clear();
                    foreach (byte value in vm.CurrentSequenceAlphabet)
                        pieChart.Brushes.Add(NucleotideColorConverter.AvailableBrushes[value]);
                    pieChart.InvalidateVisual();
                }
            }
        }
    }
}
