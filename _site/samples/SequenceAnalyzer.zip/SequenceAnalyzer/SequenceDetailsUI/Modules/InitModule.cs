﻿using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Prism.Regions;
using SequenceDetailsUI.Views;

namespace SequenceDetailsUI.Modules
{
    /// <summary>
    /// Initialization module
    /// </summary>
    public class InitModule : IModule
    {
        private readonly IRegionManager _regionManager;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="regionManager">Region Manager (injected)</param>
        public InitModule(IRegionManager regionManager)
        {
            _regionManager = regionManager;
        }

        /// <summary>
        /// Notifies the module that it has be initialized.
        /// </summary>
        public void Initialize()
        {
            // Add the details view into the UI
            _regionManager.RegisterViewWithRegion("DetailsRegion", 
                typeof(SequenceDetailsView));

            // Add the statistics into the graph region
            _regionManager.RegisterViewWithRegion("GraphRegion",
                typeof(SequenceStatisticsView));
        }
    }
}
