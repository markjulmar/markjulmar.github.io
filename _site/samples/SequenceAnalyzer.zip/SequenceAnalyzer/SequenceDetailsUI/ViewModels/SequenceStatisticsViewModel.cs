﻿using System;
using System.Collections.Generic;
using Bio;
using Microsoft.Practices.Prism.Events;
using Microsoft.Practices.Prism.ViewModel;
using Sequence.Data.Events;

namespace SequenceDetailsUI.ViewModels
{
    /// <summary>
    /// This is the View Model for the statistic view.
    /// </summary>
    public class SequenceStatisticsViewModel : NotificationObject
    {
        private ISequence _sequence;
        private bool _isVisible;

        /// <summary>
        /// True if this view should be visible.
        /// </summary>
        public bool IsVisible
        {
            get { return _isVisible; }
            set { _isVisible = value; RaisePropertyChanged(() => IsVisible); }
        }

        /// <summary>
        /// The statistics we've gathered. This is a 
        /// character (symbol) to frequency count
        /// </summary>
        public IEnumerable<Tuple<char,double,double>> Statistics
        { 
            get
            {
                if (_sequence != null)
                {
                    SequenceStatistics stats = new SequenceStatistics(_sequence);
                    foreach (byte symbol in _sequence.Alphabet)
                    {
                        double count = stats.GetCount(symbol);
                        // Bug in .NET Bio related to gap symbols.
                        if (_sequence.Alphabet.CheckIsGap(symbol))
                            count /= 2;
                        yield return Tuple.Create((char)symbol, count, count/_sequence.Count);
                    }
                }
                else yield break;
            }
        }

        /// <summary>
        /// The current sequence alphabet being used for stats
        /// </summary>
        public IAlphabet CurrentSequenceAlphabet
        {
            get { return (_sequence != null) ? _sequence.Alphabet : null; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="eventAggregator">Event Aggregator (injected)</param>
        public SequenceStatisticsViewModel(IEventAggregator eventAggregator)
        {
            // Subscribe to the sequence change event so we know then
            // the current sequence has changed.
            eventAggregator.GetEvent<SequenceSelectionEvent>()
                .Subscribe(OnSequenceChange);
        }

        /// <summary>
        /// This is called when the user selects a different 
        /// sequence.
        /// </summary>
        /// <param name="newSequence">The sequence</param>
        private void OnSequenceChange(ISequence newSequence)
        {
            if (_sequence != newSequence)
            {
                // Set our internal field and tell WPF our statistics
                // has changed.
                _sequence = newSequence;

                // Tell WPF that the sequence has changed.
                RaisePropertyChanged(() => CurrentSequenceAlphabet);
                RaisePropertyChanged(() => Statistics);

                IsVisible = _sequence != null;
            }
        }
    }
}
