﻿using System;
using System.Collections.Generic;
using System.Linq;
using Bio;
using Microsoft.Practices.Prism.ViewModel;
using Microsoft.Practices.Prism.Events;
using Sequence.Data.Events;

namespace SequenceDetailsUI.ViewModels
{
    /// <summary>
    /// View Model for the Sequence Details.
    /// </summary>
    public class SequenceDetailsViewModel : NotificationObject
    {
        private ISequence _sequence;
        private bool _isVisible;

        /// <summary>
        /// True if this view should be visible.
        /// </summary>
        public bool IsVisible
        {
            get { return _isVisible; }
            set { _isVisible = value; RaisePropertyChanged(() => IsVisible); }
        }

        /// <summary>
        /// The sequence data - presented as a set of characters.
        /// </summary>
        public IEnumerable<char> Sequence 
        {
            get { return (_sequence != null) ? _sequence.Select(b => Char.ToUpper((char) b)) : Enumerable.Empty<char>(); }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="eventAggregator">Event Aggregator (injected)</param>
        public SequenceDetailsViewModel(IEventAggregator eventAggregator)
        {
            // Subscribe to the SequenceSelection event so we know
            // when the user selects a new sequence.
            eventAggregator.GetEvent<SequenceSelectionEvent>()
                .Subscribe(OnSequenceChange);
        }

        /// <summary>
        /// This is called when the user selects a new sequence.
        /// </summary>
        /// <param name="newSequence">New sequence</param>
        private void OnSequenceChange(ISequence newSequence)
        {
            // Set our internal field and tell WPF that the
            // Sequence property has changed.
            _sequence = newSequence;
            RaisePropertyChanged(() => Sequence);

            IsVisible = _sequence != null;
        }
    }
}
