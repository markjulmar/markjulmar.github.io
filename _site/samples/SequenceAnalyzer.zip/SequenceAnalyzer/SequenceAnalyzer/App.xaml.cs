﻿using System.Windows;

namespace SequenceAnalyzer
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        /// <summary>
        /// Main entry point for the application - this
        /// creates our Bootstrapper instance and starts the app.
        /// </summary>
        protected override void OnStartup(StartupEventArgs e)
        {
            new Bootstrapper().Run();
        }
    }
}
