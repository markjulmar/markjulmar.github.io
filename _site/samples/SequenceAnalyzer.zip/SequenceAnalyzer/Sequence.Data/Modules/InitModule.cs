﻿using Contracts;
using Microsoft.Practices.Prism.Modularity;
using Microsoft.Practices.Unity;
using Sequence.Data.Services;

namespace Sequence.Data.Modules
{
    /// <summary>
    /// Initialization module
    /// </summary>
    public class InitModule : IModule
    {
        private readonly IUnityContainer _container;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="container">Unity Container injected into module</param>
        public InitModule(IUnityContainer container)
        {
            _container = container;
        }

        /// <summary>
        /// Notifies the module that it has be initialized.
        /// </summary>
        public void Initialize()
        {
            // Register the ISequenceLoader interface implementation
            _container.RegisterType<ISequenceLoader, SequenceLoader>();
        }
    }
}
