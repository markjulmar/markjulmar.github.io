﻿using System.Collections.Generic;
using System.Linq;
using Bio;
using Bio.IO;
using System.IO;
using Contracts;

namespace Sequence.Data.Services
{
    /// <summary>
    /// Sequence Loader implementation
    /// </summary>
    public class SequenceLoader : ISequenceLoader
    {
        /// <summary>
        /// Loads a file-based set of sequences.
        /// </summary>
        /// <param name="filename">Filename</param>
        /// <returns>Returning sequences</returns>
        public IEnumerable<ISequence> Load(string filename)
        {
            var parser = SequenceParsers.FindParserByFileName(filename);
            if (parser == null)
            {
                string extension = Path.GetExtension(filename);
                if (!string.IsNullOrEmpty(extension))
                {
                    parser = SequenceParsers.All
                        .FirstOrDefault(sp => sp.SupportedFileTypes.Contains(extension));
                }
            }
            return parser != null ? parser.Parse() : null;
        }
    }
}
