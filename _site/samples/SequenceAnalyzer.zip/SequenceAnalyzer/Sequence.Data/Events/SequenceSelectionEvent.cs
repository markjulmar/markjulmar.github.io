﻿using Bio;
using Microsoft.Practices.Prism.Events;

namespace Sequence.Data.Events
{
    /// <summary>
    /// Event that will be raised by Prism when we select
    /// a new sequence.
    /// </summary>
    public class SequenceSelectionEvent : CompositePresentationEvent<ISequence>
    {
    }
}
