﻿using System.Collections.Generic;
using Bio;

namespace Contracts
{
    /// <summary>
    /// This interface is used to load a file of sequences.
    /// Under the covers it will utilize .NET Bio.
    /// </summary>
    public interface ISequenceLoader
    {
        /// <summary>
        /// Loads a file-based set of sequences.
        /// </summary>
        /// <param name="filename">Filename</param>
        /// <returns>Returning sequences</returns>
        IEnumerable<ISequence> Load(string filename);
    }
}
