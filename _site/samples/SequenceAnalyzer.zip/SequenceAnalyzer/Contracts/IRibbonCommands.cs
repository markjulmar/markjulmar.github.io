﻿using System.Windows.Input;

namespace Contracts
{
    /// <summary>
    /// This interface is used to drive the Ribbon module, 
    /// other modules may request this service and then add their
    /// own buttons into the Ribbon UI.
    /// </summary>
    public interface IRibbonCommand
    {
        /// <summary>
        /// Registers a new command with the Ribbon.  The
        /// Command is tied to a RibbonButton.
        /// </summary>
        /// <param name="groupName">Group to place it in</param>
        /// <param name="label">Label for the button</param>
        /// <param name="largeImageUrl">URL for the Large Image</param>
        /// <param name="smallImageUrl">URL for the Small Image</param>
        /// <param name="command">Command to execute when button is clicked.</param>
        void RegisterViewWithRibbon(string groupName, 
            string label, string largeImageUrl, string smallImageUrl, 
            ICommand command);
    }
}
