﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using System;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MonitorFocusScopes.xaml
    /// </summary>
    public partial class MonitorFocusScopes : Window
    {
        private DispatcherTimer _timer;
        ObservableCollection<FocusScopeData> _focusScopes;

        public MonitorFocusScopes()
        {
            Loaded += MonitorFocusScopes_Loaded;
            Closed += delegate { _timer.IsEnabled = false; };
            InitializeComponent();
        }

        void MonitorFocusScopes_Loaded(object sender, RoutedEventArgs e)
        {
            _timer = new DispatcherTimer(TimeSpan.FromMilliseconds(500), DispatcherPriority.Normal,
                                         (s, ev) => CheckKeyboardFocus(), Dispatcher) {IsEnabled = true };

            _focusScopes = new ObservableCollection<FocusScopeData>(
                    from fe in Application.Current.MainWindow.EnumerateVisualTree()
                    where FocusManager.GetIsFocusScope(fe)
                    select new FocusScopeData {FocusScope = fe, FocusedElement = FocusManager.GetFocusedElement(fe)});

            FocusManager.FocusedElementProperty.OverrideMetadata(
                typeof (FrameworkElement), new PropertyMetadata(OnLogicalFocusChanged));

            DataContext = _focusScopes;
        }

        void OnLogicalFocusChanged(DependencyObject dpo, DependencyPropertyChangedEventArgs e)
        {
            var fe = _focusScopes.FirstOrDefault(fsd => fsd.FocusScope == dpo);
            if (fe != null)
                fe.FocusedElement = e.NewValue;

            CheckKeyboardFocus();
        }

        private void CheckKeyboardFocus()
        {
            _focusScopes.All(
                fs => { fs.IsKeyboardFocused = (fs.FocusedElement == Keyboard.FocusedElement); return true; });
        }
    }

    #region FocusScopeData
    class FocusScopeData : INotifyPropertyChanged
    {
        private DependencyObject _focusScope;
        public DependencyObject FocusScope
        {
            get { return _focusScope; }
            set { _focusScope = value; OnPropertyChanged("FocusScope"); }
        }

        private object _focusElement;
        public object FocusedElement
        {
            get { return _focusElement; }
            set { _focusElement = value; OnPropertyChanged("FocusedElement"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }

        private bool _isKeyboardFocused;
        public bool IsKeyboardFocused
        {
            get { return _isKeyboardFocused; }
            set { _isKeyboardFocused = value; OnPropertyChanged("IsKeyboardFocused"); }
        }
    }
    #endregion
}
