﻿using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using Microsoft.Win32;
using System.IO;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            Loaded += Window1_Loaded;
            InitializeComponent();
        }

        void Window1_Loaded(object sender, RoutedEventArgs e)
        {
            new MonitorFocusScopes().Show();

            CommandBindings.Add(new CommandBinding(ApplicationCommands.Open, OnOpenFile));
            CommandBindings.Add(new CommandBinding(ApplicationCommands.Close, (s, ev) => Close()));
        }

        private void OnOpenFile(object sender, ExecutedRoutedEventArgs e)
        {
            var ofd = new OpenFileDialog
              {
                  Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*",
                  CheckFileExists = true
              };

            if (ofd.ShowDialog(this).Value)
            {
                using (Stream stream = ofd.OpenFile())
                {
                    var tr = new TextRange(rtb.Document.ContentStart, rtb.Document.ContentEnd);
                    tr.Load(stream, DataFormats.Text);

                }
            }
        }
    }
}
