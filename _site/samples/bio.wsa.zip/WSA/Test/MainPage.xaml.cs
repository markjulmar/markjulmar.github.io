﻿using System;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Navigation;
using Test.ViewModels;

namespace Test
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage
    {
        public MainPage()
        {
            DataContext = new MainViewModel();
            this.InitializeComponent();
        }

        private MainViewModel ViewModel
        {
            get { return (MainViewModel) DataContext; }
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            OnLoadFile(null, new RoutedEventArgs());
        }

        private async void OnLoadFile(object sender, RoutedEventArgs e)
        {
            // Select a file
            FileOpenPicker filePicker = new FileOpenPicker();
            filePicker.FileTypeFilter.Add(".fasta");
            filePicker.ViewMode = PickerViewMode.List;

            // Load the file
            StorageFile sf = await filePicker.PickSingleFileAsync();
            if (sf != null)
            {
                await ViewModel.LoadFile(sf);
            }
        }
    }
}
