﻿using System.IO;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media.Imaging;
using Bio;
using Bio.IO;
using JulMar.Windows.Extensions;
using JulMar.Windows.Mvvm;
using System;
using System.Linq;
using System.Threading.Tasks;
using Windows.Storage;

namespace Test.ViewModels
{
    /// <summary>
    /// Simple view model to load a set of sequences and generate a bitmap from the values.
    /// </summary>
    public sealed class MainViewModel : SimpleViewModel
    {
        private ISequence[] _sequences;
        private WriteableBitmap _image;
        private double _multiplier;

        public ISequence[] Sequences
        {
            get { return _sequences; }
            set { SetPropertyValue(ref _sequences, value); }
        }

        public WriteableBitmap Image
        {
            get { return _image; }
            set { SetPropertyValue(ref _image, value); }
        }

        public double Multiplier
        {
            get { return _multiplier; }
            set
            {
                if (SetPropertyValue(ref _multiplier, value))
                {
                    LoadBitmap().NoWarning();
                }
            }
        }

        public double ImageWidth { get; private set; }
        public double ImageHeight { get; private set; }

        public MainViewModel()
        {
            _multiplier = 4;

            ImageWidth = Window.Current.Bounds.Width - 200;
            ImageHeight = Window.Current.Bounds.Height - 200;
        }

        public async Task LoadFile(StorageFile file)
        {
            var parser = SequenceParsers.FindParserByFileName(file);
            if (parser != null)
            {
                var data = parser.Parse().ToArray();
                parser.Close();

                Sequences = data;
                await LoadBitmap();
            }
        }

        private async Task LoadBitmap()
        {
            var data = Sequences;
            int multipler = (int) Multiplier;

            int width = (int)data.Max(s => s.Count);
            int height = data.Length;
            byte[] pixels = new byte[width * height * 4 * multipler * multipler]; // Bgra8

            await Task.Run(() =>
            {
                // Generate the sequence map
                Parallel.For(0, height, row =>
                {
                    ISequence s = data[row];
                    for (int col = 0; col < width; col++)
                    {
                        Color clr = (col < s.Count) ? GetColor(s[col]) : Colors.Transparent;

                        for (int crow = 0; crow < multipler; crow++)
                        {
                            for (int ccol = 0; ccol < multipler; ccol++)
                            {
                                int x = col * multipler + ccol;
                                int y = row * multipler + crow;

                                int index = 4 * (y * width * multipler + x);
                                pixels[index + 0] = clr.B;
                                pixels[index + 1] = clr.G;
                                pixels[index + 2] = clr.R;
                                pixels[index + 3] = clr.A;
                            }
                        }
                    }
                });
            });

            if (multipler == (int)  Multiplier && ReferenceEquals(Sequences, data))
            {
                WriteableBitmap wbmp = new WriteableBitmap(width * multipler, height * multipler);
                Image = wbmp;
                
                var pixelStream = wbmp.PixelBuffer.AsStream();
                pixelStream.Seek(0, SeekOrigin.Begin);
                pixelStream.Write(pixels, 0, pixels.Length);
                wbmp.Invalidate();
            }
        }

        private Color GetColor(byte val)
        {
            switch (Char.ToLower((char)val))
            {
                case 'a':
                    return Colors.Red;
                case 'g':
                    return Colors.Green;
                case 'c':
                    return Colors.Blue;
                case 't':
                case 'u':
                    return Colors.Orange;
            }
            return Colors.Transparent;
        }
    }
}
