﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Documents;

namespace Test.Converters
{
    public static class RichTextBlockExtensions
    {
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof (object[]), 
                typeof (RichTextBlockExtensions),
                new PropertyMetadata(null, OnTextChanged));

        private static void OnTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            RichTextBlock rtb = (RichTextBlock) d;
            if (rtb == null)
            {
                return;
            }

            rtb.Blocks.Clear();

            object[] ic = (object[])e.NewValue;
            if (ic != null)
            {
                foreach (Block block in ic)
                {
                    rtb.Blocks.Add(block);
                }
            }
        }

        public static object[] GetText(RichTextBlock tb)
        {
            return (object[])tb.GetValue(TextProperty);
        }

        public static void SetText(RichTextBlock tb, object[] ic)
        {
            tb.SetValue(TextProperty, ic);
        }

    }
}
