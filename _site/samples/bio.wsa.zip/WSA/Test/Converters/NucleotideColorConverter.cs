﻿using System;
using Bio;
using Windows.UI;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Documents;
using Windows.UI.Xaml.Media;

namespace Test.Converters
{
    public sealed class NucleotideColorConverter : IValueConverter
    {
        Brush BrushA = new SolidColorBrush(Colors.Pink);
        Brush BrushG = new SolidColorBrush(Colors.LightGreen);
        Brush BrushC = new SolidColorBrush(Colors.LightBlue);
        Brush BrushT = new SolidColorBrush(Colors.LightSalmon);
        Brush DefaultBrush = new SolidColorBrush(Colors.LightGray);

        public object Convert(object value, Type targetType, object parameter, string language)
        {
            ISequence sequence = (ISequence) value;

            Paragraph p = new Paragraph();
            foreach (var item in sequence)
            {
                char ch = (char) item;
                p.Inlines.Add(
                    new Run() { Text = ch.ToString(), Foreground = GetBrushColor(ch) });
            }

            return new[] {p};
        }

        Brush GetBrushColor(char nc)
        {
            nc = Char.ToUpperInvariant(nc);
            if (nc == 'A')
                return BrushA;
            if (nc == 'G')
                return BrushG;
            if (nc == 'C')
                return BrushC;
            if (nc == 'T' || nc == 'U')
                return BrushT;
            return DefaultBrush;
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
}
