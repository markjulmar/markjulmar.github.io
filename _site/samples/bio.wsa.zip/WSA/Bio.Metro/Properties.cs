﻿using System;
using Windows.ApplicationModel.Resources;

namespace Bio.Properties
{
    /// <summary>
    ///   A strongly-typed resource class, for looking up localized strings, etc.
    /// </summary>
    internal class Resource
    {
        private static ResourceLoader _resourceMgr;
        private static global::System.Globalization.CultureInfo _resourceCulture;

        internal Resource()
        {
        }

        /// <summary>
        ///   Returns the cached ResourceManager instance used by this class.
        /// </summary>
        internal static ResourceLoader ResourceManager
        {
            get
            {
                if (_resourceMgr == null)
                {
                    _resourceMgr = new ResourceLoader("Bio/Properties");
                }
                return _resourceMgr;
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Byte array must have an even number of values..
        /// </summary>
        internal static string Ab1ColorDataFromByteArrayEvenNumberRequired
        {
            get
            {
                return ResourceManager.GetString("Ab1ColorDataFromByteArrayEvenNumberRequired");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The file signature {0} does not match the expected signature of {1}..
        /// </summary>
        internal static string Ab1InvalidFileSignatureExceptionFormat
        {
            get
            {
                return ResourceManager.GetString("Ab1InvalidFileSignatureExceptionFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid file version.  Expected version {0}, actual version was {1}..
        /// </summary>
        internal static string Ab1InvalidFileVersionExceptionFormat
        {
            get
            {
                return ResourceManager.GetString("Ab1InvalidFileVersionExceptionFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Sequence for the accession number {0} not found..
        /// </summary>
        internal static string AccessionSequenceNotFound
        {
            get
            {
                return ResourceManager.GetString("AccessionSequenceNotFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Aligned sequences count cannot be 0.
        /// </summary>
        internal static string AlignedSequenceCount
        {
            get
            {
                return ResourceManager.GetString("AlignedSequenceCount");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SequenceAlphabet is null. Set it to correct alphabet!.
        /// </summary>
        internal static string ALPHABET_NULL
        {
            get
            {
                return ResourceManager.GetString("ALPHABET_NULL");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Alphabet of Reference sequence is not matching with the alphabet of query sequence..
        /// </summary>
        internal static string AlphabetMisMatch
        {
            get
            {
                return ResourceManager.GetString("AlphabetMisMatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to AmbiguousDna.
        /// </summary>
        internal static string AmbiguousDnaAlphabetName
        {
            get
            {
                return ResourceManager.GetString("AmbiguousDnaAlphabetName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to AmbiguousProtein.
        /// </summary>
        internal static string AmbiguousProteinAlphabetName
        {
            get
            {
                return ResourceManager.GetString("AmbiguousProteinAlphabetName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to AmbiguousRna.
        /// </summary>
        internal static string AmbiguousRnaAlphabetName
        {
            get
            {
                return ResourceManager.GetString("AmbiguousRnaAlphabetName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Parse applied biosystems binary format as defined in http://www6.appliedbiosystems.com/support/software_community/ABIF_File_Format.pdf..
        /// </summary>
        internal static string APPLIEDBIOSYSTEMS_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("APPLIEDBIOSYSTEMS_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .abi,.ab1.
        /// </summary>
        internal static string APPLIEDBIOSYSTEMS_FILETYPES
        {
            get
            {
                return ResourceManager.GetString("APPLIEDBIOSYSTEMS_FILETYPES");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Applied Biosystems.
        /// </summary>
        internal static string APPLIEDBIOSYSTEMS_NAME
        {
            get
            {
                return ResourceManager.GetString("APPLIEDBIOSYSTEMS_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Start of range must be smaller than end..
        /// </summary>
        internal static string ARGUMENT_OUT_OF_RANGE
        {
            get
            {
                return ResourceManager.GetString("ARGUMENT_OUT_OF_RANGE");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Azure BLAST.
        /// </summary>
        internal static string AZURE_BLAST_NAME
        {
            get
            {
                return ResourceManager.GetString("AZURE_BLAST_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to BAM filename and Index filename can&apos;t be same..
        /// </summary>
        internal static string BAM_BAMFileNIndexFileContbeSame
        {
            get
            {
                return ResourceManager.GetString("BAM_BAMFileNIndexFileContbeSame");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Can&apos;t use this instance anymore as underlying stream is already disposed..
        /// </summary>
        internal static string BAM_CantUseBAMIndexStreamDisposed
        {
            get
            {
                return ResourceManager.GetString("BAM_CantUseBAMIndexStreamDisposed");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .bam.
        /// </summary>
        internal static string BAM_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("BAM_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to BAM format does not supports writing multiple ISequenceAlignment objects to a file..
        /// </summary>
        internal static string BAM_FormatMultipleAlignmentsNotSupported
        {
            get
            {
                return ResourceManager.GetString("BAM_FormatMultipleAlignmentsNotSupported");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to BAM formatter does not support formatting to string..
        /// </summary>
        internal static string BAM_FormatStringNotSupported
        {
            get
            {
                return ResourceManager.GetString("BAM_FormatStringNotSupported");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .bai.
        /// </summary>
        internal static string BAM_INDEXFILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("BAM_INDEXFILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid BAM file..
        /// </summary>
        internal static string BAM_InvalidBAMFile
        {
            get
            {
                return ResourceManager.GetString("BAM_InvalidBAMFile");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid CIGAR found..
        /// </summary>
        internal static string BAM_InvalidCIGAR
        {
            get
            {
                return ResourceManager.GetString("BAM_InvalidCIGAR");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid encoded sequence value.
        /// </summary>
        internal static string BAM_InvalidEncodedSequenceValue
        {
            get
            {
                return ResourceManager.GetString("BAM_InvalidEncodedSequenceValue");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid BAM index file..
        /// </summary>
        internal static string BAM_InvalidIndexFile
        {
            get
            {
                return ResourceManager.GetString("BAM_InvalidIndexFile");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid integer value &quot;{0}&quot; found in optional field &quot;{1}&quot;..
        /// </summary>
        internal static string BAM_InvalidIntValueInOptField
        {
            get
            {
                return ResourceManager.GetString("BAM_InvalidIntValueInOptField");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid integer value &quot;{0}&quot; found in optional field &quot;{1}&quot; of the alingned seq &quot;{2}&quot;..
        /// </summary>
        internal static string BAM_InvalidIntValueInOptFieldOfAlignedSeq
        {
            get
            {
                return ResourceManager.GetString("BAM_InvalidIntValueInOptFieldOfAlignedSeq");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid optional valuetype.
        /// </summary>
        internal static string BAM_InvalidOptValType
        {
            get
            {
                return ResourceManager.GetString("BAM_InvalidOptValType");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to BAM.
        /// </summary>
        internal static string BAM_NAME
        {
            get
            {
                return ResourceManager.GetString("BAM_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Reference sequence name \&quot;{0}\&quot; not found..
        /// </summary>
        internal static string BAM_RefSeqNotFound
        {
            get
            {
                return ResourceManager.GetString("BAM_RefSeqNotFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to BAM parser does not supports reading from a text reader..
        /// </summary>
        internal static string BAM_TextreaderNotSupportedMessage
        {
            get
            {
                return ResourceManager.GetString("BAM_TextreaderNotSupportedMessage");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to BAM formatter does not support writing to text writer..
        /// </summary>
        internal static string BAM_TextWriterNotSupported
        {
            get
            {
                return ResourceManager.GetString("BAM_TextWriterNotSupported");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unable to read compressed block.
        /// </summary>
        internal static string BAM_UnableToReadCompressedBlock
        {
            get
            {
                return ResourceManager.GetString("BAM_UnableToReadCompressedBlock");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Writes a SequenceAlignmentMap to a particular location, usually a file. 
        ///The output is formatted according to the BAM file format..
        /// </summary>
        internal static string BAMFORMATTER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("BAMFORMATTER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to BAM only supports SAMDNA aplhabet..
        /// </summary>
        internal static string BAMFormatterSupportsDNAOnly
        {
            get
            {
                return ResourceManager.GetString("BAMFormatterSupportsDNAOnly");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A BAMParser reads from a source of binary data that is formatted according to the BAM 
        ///file specification, and converts the data to in-memory SequenceAlignmentMap object..
        /// </summary>
        internal static string BAMPARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("BAMPARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Alphabet can&apos;t be set as BAM supports only SAMDNA alphabet..
        /// </summary>
        internal static string BAMParserAlphabetCantBeSet
        {
            get
            {
                return ResourceManager.GetString("BAMParserAlphabetCantBeSet");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Batch count must be greater than zero..
        /// </summary>
        internal static string BatchCountCondition
        {
            get
            {
                return ResourceManager.GetString("BatchCountCondition");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Chromosome sequence ranges format..
        /// </summary>
        internal static string BedDesc
        {
            get
            {
                return ResourceManager.GetString("BedDesc");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .bed.
        /// </summary>
        internal static string BedFileFormats
        {
            get
            {
                return ResourceManager.GetString("BedFileFormats");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to BED.
        /// </summary>
        internal static string BedName
        {
            get
            {
                return ResourceManager.GetString("BedName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to BLAST @ BioHPC.
        /// </summary>
        internal static string BIOHPC_BLAST_NAME
        {
            get
            {
                return ResourceManager.GetString("BIOHPC_BLAST_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to BlastXmlParser.Parse: No records were found in the input..
        /// </summary>
        internal static string BlastNoRecords
        {
            get
            {
                return ResourceManager.GetString("BlastNoRecords");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Number of bases to be extended before stopping alignment.
        /// </summary>
        internal static string BREAK_LENGTH_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("BREAK_LENGTH_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Break Length.
        /// </summary>
        internal static string BREAK_LENGTH_NAME
        {
            get
            {
                return ResourceManager.GetString("BREAK_LENGTH_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Reverse Complement builder (char array) has incorrect length. Should be equal to sequence length.
        /// </summary>
        internal static string BuilderIncorrectLength
        {
            get
            {
                return ResourceManager.GetString("BuilderIncorrectLength");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Cannot add more than {0} child nodes to edge.
        /// </summary>
        internal static string Cannotaddmorethanchildnodestoedge
        {
            get
            {
                return ResourceManager.GetString("Cannotaddmorethanchildnodestoedge");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Clustal file has unknown sequence {0}.
        /// </summary>
        internal static string ClustalUnknownSequence
        {
            get
            {
                return ResourceManager.GetString("ClustalUnknownSequence");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .aln.
        /// </summary>
        internal static string CLUSTALW_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("CLUSTALW_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to ClustalW.
        /// </summary>
        internal static string CLUSTALW_NAME
        {
            get
            {
                return ResourceManager.GetString("CLUSTALW_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A ClustalWParser reads from a source of text that is formatted according to the ClustalW flat file specification, and converts the data to in-memory ISequenceAlignment objects..
        /// </summary>
        internal static string CLUSTALWPARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("CLUSTALWPARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to RefStart={0} QueryStart={1} Length={2} Score={3} WrapScore={4} IsGood={5}.
        /// </summary>
        internal static string ClusterToStringFormat
        {
            get
            {
                return ResourceManager.GetString("ClusterToStringFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Command Line Argument Error: .
        /// </summary>
        internal static string CmdLineParserException
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserException");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid value found. Parameter &quot;.
        /// </summary>
        internal static string CmdLineParserExceptionInvalidValueFound
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionInvalidValueFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &quot; must not have a value.
        /// </summary>
        internal static string CmdLineParserExceptionInvalidValueFoundBool
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionInvalidValueFoundBool");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &quot; does not have an numeric value.
        /// </summary>
        internal static string CmdLineParserExceptionInvalidValueFoundInt
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionInvalidValueFoundInt");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &quot; does not have a series of numeric values.
        /// </summary>
        internal static string CmdLineParserExceptionInvalidValueFoundInts
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionInvalidValueFoundInts");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &quot; must have a string value.
        /// </summary>
        internal static string CmdLineParserExceptionInvalidValueFoundString
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionInvalidValueFoundString");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Repeated parameter found! Parameter &quot;.
        /// </summary>
        internal static string CmdLineParserExceptionRepeatedParameterFound
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionRepeatedParameterFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &quot; must only be used once.
        /// </summary>
        internal static string CmdLineParserExceptionRepeatedParameterFoundOnce
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionRepeatedParameterFoundOnce");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The required first parameter is missing.
        /// </summary>
        internal static string CmdLineParserExceptionRequiredFirstParameterMissing
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionRequiredFirstParameterMissing");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A required parameter is missing. Parameter &quot;.
        /// </summary>
        internal static string CmdLineParserExceptionRequiredParameterMissing
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionRequiredParameterMissing");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &quot; is required but missing.
        /// </summary>
        internal static string CmdLineParserExceptionRequiredParameterMissing2
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionRequiredParameterMissing2");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Command arguments incorrect in &quot;.
        /// </summary>
        internal static string CmdLineParserExceptionSyntaxError
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionSyntaxError");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &quot;. Error near: &quot;... .
        /// </summary>
        internal static string CmdLineParserExceptionSyntaxError2
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionSyntaxError2");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &quot;. Quote parameters containing spaces.
        /// </summary>
        internal static string CmdLineParserExceptionSyntaxError3
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionSyntaxError3");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unknown parameter found: &quot;.
        /// </summary>
        internal static string CmdLineParserExceptionUnknownParameterFound
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionUnknownParameterFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &quot;. Unknown parameters are not allowed.
        /// </summary>
        internal static string CmdLineParserExceptionUnknownParameterFound2
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionUnknownParameterFound2");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Value without parameter found: &quot;.
        /// </summary>
        internal static string CmdLineParserExceptionValueWithoutParameterFound
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionValueWithoutParameterFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &quot;. Each value must be assigned to a parameter.
        /// </summary>
        internal static string CmdLineParserExceptionValueWithoutParameterFound2
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserExceptionValueWithoutParameterFound2");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to first parameter.
        /// </summary>
        internal static string CmdLineParserFirstParam
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserFirstParam");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to int.
        /// </summary>
        internal static string CmdLineParserInt
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserInt");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Optional:.
        /// </summary>
        internal static string CmdLineParserOptional
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserOptional");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Parameters:.
        /// </summary>
        internal static string CmdLineParserParameters
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserParameters");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to ^([\\s]*)([/-](?&lt;name&gt;[^\\s-/:=]+)([:=]?)([\\s]*)(?&lt;value&gt;(\&quot;[^\&quot;]*\&quot;)|(&apos;[^&apos;]*&apos;)|([\\s]*[^/-][^\\s]+[\\s]*)|([^/-]+)|)?([\\s]*))*$.
        /// </summary>
        internal static string CmdLineParserRegEx
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserRegEx");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Required:.
        /// </summary>
        internal static string CmdLineParserRequired
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserRequired");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to string.
        /// </summary>
        internal static string CmdLineParserString
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserString");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Usage:.
        /// </summary>
        internal static string CmdLineParserUsage
        {
            get
            {
                return ResourceManager.GetString("CmdLineParserUsage");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Trim length cannot exceed past the number of peak locations..
        /// </summary>
        internal static string ColorDataTrimLengthArgumentException
        {
            get
            {
                return ResourceManager.GetString("ColorDataTrimLengthArgumentException");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Color data start index must lie within the range of peak locations..
        /// </summary>
        internal static string ColorDataTrimStartIndexOutOfRange
        {
            get
            {
                return ResourceManager.GetString("ColorDataTrimStartIndexOutOfRange");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Could not find complement for one or more symbols..
        /// </summary>
        internal static string ComplementNotFound
        {
            get
            {
                return ResourceManager.GetString("ComplementNotFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Complement for the symbol {0} is not supported by {1} Alphabet..
        /// </summary>
        internal static string ComplementNotSupportedByalphabet
        {
            get
            {
                return ResourceManager.GetString("ComplementNotSupportedByalphabet");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Location with Complement operator cannot contain more than one sub locations..
        /// </summary>
        internal static string ComplementWithMorethanOneSubLocs
        {
            get
            {
                return ResourceManager.GetString("ComplementWithMorethanOneSubLocs");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A condition failed..
        /// </summary>
        internal static string ConditionFailed
        {
            get
            {
                return ResourceManager.GetString("ConditionFailed");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Consensus has not been computed.
        /// </summary>
        internal static string ContigLength
        {
            get
            {
                return ResourceManager.GetString("ContigLength");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Could not find the DeltaAlignment at specified position {0} of the file :{1}.
        ///Delta alignment file is corrupted. .
        /// </summary>
        internal static string CorruptedDeltaAlignmentFile
        {
            get
            {
                return ResourceManager.GetString("CorruptedDeltaAlignmentFile");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Could not identify alphabet type..
        /// </summary>
        internal static string CouldNotIdentifyAlphabetType
        {
            get
            {
                return ResourceManager.GetString("CouldNotIdentifyAlphabetType");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Could not recognize the specified alphabet type..
        /// </summary>
        internal static string CouldNotRecognizeAlphabet
        {
            get
            {
                return ResourceManager.GetString("CouldNotRecognizeAlphabet");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Could not recognize the specified symbol..
        /// </summary>
        internal static string CouldNotRecognizeSymbol
        {
            get
            {
                return ResourceManager.GetString("CouldNotRecognizeSymbol");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Count cannot be less than zero.
        /// </summary>
        internal static string CountCannotBeLessThanZero
        {
            get
            {
                return ResourceManager.GetString("CountCannotBeLessThanZero");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to No parser exists for the ab1 format version {0}.
        /// </summary>
        internal static string DataParserFactoryNoParserExistsForVersionFormat
        {
            get
            {
                return ResourceManager.GetString("DataParserFactoryNoParserExistsForVersionFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Data virtualization needs to be enabled with proper file name..
        /// </summary>
        internal static string DataVirtualizationNeedsInputFile
        {
            get
            {
                return ResourceManager.GetString("DataVirtualizationNeedsInputFile");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Delta alignment id {2} does not match the specified position {1} in the file {2}.
        /// </summary>
        internal static string DeltaAlignmentIDDoesnotMatch
        {
            get
            {
                return ResourceManager.GetString("DeltaAlignmentIDDoesnotMatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Ref ID={0} Query Id={1} Ref start={2} Ref End={3} Query start={4} Query End={5}, Direction={6}.
        /// </summary>
        internal static string DeltaAlignmentToStringFormat
        {
            get
            {
                return ResourceManager.GetString("DeltaAlignmentToStringFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Corrupted collection file..
        /// </summary>
        internal static string DeltaCollectionFileCorrupted
        {
            get
            {
                return ResourceManager.GetString("DeltaCollectionFileCorrupted");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to For DensePairAnsi the missingValue must be (UO &apos;?&apos;, &apos;?&apos;).
        /// </summary>
        internal static string DensePairAnsiMissingValueSignatureMustBe
        {
            get
            {
                return ResourceManager.GetString("DensePairAnsiMissingValueSignatureMustBe");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Destination Array Not Large Enough.
        /// </summary>
        internal static string DestArrayNotLargeEnough
        {
            get
            {
                return ResourceManager.GetString("DestArrayNotLargeEnough");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Sequence and quality scores lengths are not same. Sequence length: {0}, Quality scores length: {1}.
        /// </summary>
        internal static string DifferenceInSequenceAndQualityScoresLengthMessage
        {
            get
            {
                return ResourceManager.GetString("DifferenceInSequenceAndQualityScoresLengthMessage");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Dna.
        /// </summary>
        internal static string DnaAlphabetName
        {
            get
            {
                return ResourceManager.GetString("DnaAlphabetName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to DoubleRangeValidator: Invalid arguments..
        /// </summary>
        internal static string DoubleRangeInvalidArgs
        {
            get
            {
                return ResourceManager.GetString("DoubleRangeInvalidArgs");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Duplicate SQ header found for {0}..
        /// </summary>
        internal static string DuplicateSQHeader
        {
            get
            {
                return ResourceManager.GetString("DuplicateSQHeader");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Duplicate read found. Id:{0}.
        /// </summary>
        internal static string DuplicatingReadIds
        {
            get
            {
                return ResourceManager.GetString("DuplicatingReadIds");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to EBI WU-BLAST.
        /// </summary>
        internal static string EBIWUBLAST_NAME
        {
            get
            {
                return ResourceManager.GetString("EBIWUBLAST_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Empty sequence.
        /// </summary>
        internal static string EmptySequence
        {
            get
            {
                return ResourceManager.GetString("EmptySequence");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to EndData can not be null or empty..
        /// </summary>
        internal static string EndDataCannotBeNull
        {
            get
            {
                return ResourceManager.GetString("EndDataCannotBeNull");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A call to CheckCondition() failed.
        /// </summary>
        internal static string ErrorCheckConditionFailed
        {
            get
            {
                return ResourceManager.GetString("ErrorCheckConditionFailed");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to CheckCondition.FirstAndOnly() failed to Get the first item.
        /// </summary>
        internal static string ErrorCheckConditionFirstAndOnlyTooFew
        {
            get
            {
                return ResourceManager.GetString("ErrorCheckConditionFirstAndOnlyTooFew");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to CheckCondition.FirstAndOnly() found more than one item available.
        /// </summary>
        internal static string ErrorCheckConditionFirstAndOnlyTooMany
        {
            get
            {
                return ResourceManager.GetString("ErrorCheckConditionFirstAndOnlyTooMany");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Error converting character nucleotide [{0}] to double.  Expected &apos;A&apos;, &apos;C&apos;, &apos;G&apos;, or &apos;T&apos;.
        /// </summary>
        internal static string ErrorConvertingCharacterNucleotideToDouble
        {
            get
            {
                return ResourceManager.GetString("ErrorConvertingCharacterNucleotideToDouble");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Error converting double [{0}] to a character nucleotide.  Expected 0.0, 1.0, 2.0, or 3.0.
        /// </summary>
        internal static string ErrorConvertingDoubleToNucleotide
        {
            get
            {
                return ResourceManager.GetString("ErrorConvertingDoubleToNucleotide");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected val length [{0}] to be 1.
        /// </summary>
        internal static string ErrorConvertingSparseValToStore
        {
            get
            {
                return ResourceManager.GetString("ErrorConvertingSparseValToStore");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Error converting value [{0}] gave the special &apos;MissingValue &apos;[{1}].
        /// </summary>
        internal static string ErrorConvertingValGaveMissingValue
        {
            get
            {
                return ResourceManager.GetString("ErrorConvertingValGaveMissingValue");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The input data should be grouped by var.
        /// </summary>
        internal static string ErrorInputDataShouldBeGroupedByVar
        {
            get
            {
                return ResourceManager.GetString("ErrorInputDataShouldBeGroupedByVar");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to No files match the name given [{0}].
        /// </summary>
        internal static string ErrorNoFilesMatchSpecifiedName
        {
            get
            {
                return ResourceManager.GetString("ErrorNoFilesMatchSpecifiedName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected double [{0}] to be -1 or 1.
        /// </summary>
        internal static string ExpectDoubleToBeMinusOneOrOne
        {
            get
            {
                return ResourceManager.GetString("ExpectDoubleToBeMinusOneOrOne");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expect each data row to have {0} characters..
        /// </summary>
        internal static string ExpectEachDataRowToHaveNCharacters
        {
            get
            {
                return ResourceManager.GetString("ExpectEachDataRowToHaveNCharacters");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected &apos;var&apos; as first column of header.  Found [{0}] in file [{1}].
        /// </summary>
        internal static string Expected_var_AsFirstColumnOfHeader
        {
            get
            {
                return ResourceManager.GetString("Expected_var_AsFirstColumnOfHeader");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected all matrices to have the same &apos;MissingValue&apos; value.
        /// </summary>
        internal static string ExpectedAllMatricesToHaveSameMissingValue
        {
            get
            {
                return ResourceManager.GetString("ExpectedAllMatricesToHaveSameMissingValue");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected argument count of 3 or 4.
        /// </summary>
        internal static string ExpectedArgCountOfThreeOrFour
        {
            get
            {
                return ResourceManager.GetString("ExpectedArgCountOfThreeOrFour");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {3} Expected {0} required argument(s) after parsing named arguments (which may include required), but found {1}. ({2}).
        /// </summary>
        internal static string ExpectedArguments
        {
            get
            {
                return ResourceManager.GetString("ExpectedArguments");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected bool? to be true or false.
        /// </summary>
        internal static string ExpectedBoolToBeTrueOrFalse
        {
            get
            {
                return ResourceManager.GetString("ExpectedBoolToBeTrueOrFalse");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected byteArray.Length [{0}] and BytesPerValue [{[1}] to be equal.
        /// </summary>
        internal static string ExpectedByteArrayLengthAndBytesPerValueToBeEqual
        {
            get
            {
                return ResourceManager.GetString("ExpectedByteArrayLengthAndBytesPerValueToBeEqual");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected char [{0}] to be &apos;0&apos; or &apos;1&apos;.
        /// </summary>
        internal static string ExpectedCharToBeZeroOrOne
        {
            get
            {
                return ResourceManager.GetString("ExpectedCharToBeZeroOrOne");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected the number of columns in the input array [{0}] to match the number of items in varList [{1}].
        /// </summary>
        internal static string ExpectedColumnKeysCountToEqualValueArrayCount
        {
            get
            {
                return ResourceManager.GetString("ExpectedColumnKeysCountToEqualValueArrayCount");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected the columns of the two matrices to match.
        /// </summary>
        internal static string ExpectedColumnsToMatch
        {
            get
            {
                return ResourceManager.GetString("ExpectedColumnsToMatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected every column to be a member of the permutation.
        /// </summary>
        internal static string ExpectedEveryColumnToBeAMemberOfThePermutation
        {
            get
            {
                return ResourceManager.GetString("ExpectedEveryColumnToBeAMemberOfThePermutation");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected every column to be used once and only once in a permutation.
        /// </summary>
        internal static string ExpectedEveryColumnToBeUsedOnceInThePermuation
        {
            get
            {
                return ResourceManager.GetString("ExpectedEveryColumnToBeUsedOnceInThePermuation");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected every re-mapped colKey to be in original matrix.  Unmatched keys include [{0}].
        /// </summary>
        internal static string ExpectedEveryRemappedColKeyToBeInOriginalMatrix
        {
            get
            {
                return ResourceManager.GetString("ExpectedEveryRemappedColKeyToBeInOriginalMatrix");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected every &apos;var&apos; line in file [{0}] to have exactly one tab, found [{1}].
        /// </summary>
        internal static string ExpectedEveryVarLineToHaveOneTab
        {
            get
            {
                return ResourceManager.GetString("ExpectedEveryVarLineToHaveOneTab");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected file [{0}] to have data.
        /// </summary>
        internal static string ExpectedFileToHaveData
        {
            get
            {
                return ResourceManager.GetString("ExpectedFileToHaveData");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected file [{0}] to have header.
        /// </summary>
        internal static string ExpectedFileToHaveHeader
        {
            get
            {
                return ResourceManager.GetString("ExpectedFileToHaveHeader");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected header as first line of file [{0}].
        /// </summary>
        internal static string ExpectedHeaderAsFirstLineOfFile
        {
            get
            {
                return ResourceManager.GetString("ExpectedHeaderAsFirstLineOfFile");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected header to be &apos;var&lt;tab&gt;cid&lt;tab&gt;val&apos;, found [{0}].
        /// </summary>
        internal static string ExpectedHeaderToBe_var_cid_val
        {
            get
            {
                return ResourceManager.GetString("ExpectedHeaderToBe_var_cid_val");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected item [{0}] to already exist.  Item not found.
        /// </summary>
        internal static string ExpectedItemToExist
        {
            get
            {
                return ResourceManager.GetString("ExpectedItemToExist");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected item [{0}] to not exist.  Found item more than once.
        /// </summary>
        internal static string ExpectedItemToNotExist
        {
            get
            {
                return ResourceManager.GetString("ExpectedItemToNotExist");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The colKeys of the MatrixView must be a subset the colKeys of the parentMatrix. The sets can also be equal.
        /// </summary>
        internal static string ExpectedMatrixViewColKeysToBeSubsetOfParentMatrix
        {
            get
            {
                return ResourceManager.GetString("ExpectedMatrixViewColKeysToBeSubsetOfParentMatrix");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The rowKeys of the MatrixView must be a subset the rowKeys of the parentMatrix. The sets can also be equal.
        /// </summary>
        internal static string ExpectedMatrixViewRowKeysToBeSubsetOfParentMatrix
        {
            get
            {
                return ResourceManager.GetString("ExpectedMatrixViewRowKeysToBeSubsetOfParentMatrix");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected maxLength parameter to be greater than 1.
        /// </summary>
        internal static string ExpectedMaxLengthToGreaterThanOne
        {
            get
            {
                return ResourceManager.GetString("ExpectedMaxLengthToGreaterThanOne");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected no comments in RowKeysAnsi and related files.  File [{0}].
        /// </summary>
        internal static string ExpectedNoCommentsInRowKeysAnsiFiles
        {
            get
            {
                return ResourceManager.GetString("ExpectedNoCommentsInRowKeysAnsiFiles");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected non-zero length for the array of matrices.
        /// </summary>
        internal static string ExpectedNonZeroLengthArrayOfMatrices
        {
            get
            {
                return ResourceManager.GetString("ExpectedNonZeroLengthArrayOfMatrices");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected non-zero length comment.
        /// </summary>
        internal static string ExpectedNonZeroLengthCommentToken
        {
            get
            {
                return ResourceManager.GetString("ExpectedNonZeroLengthCommentToken");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected no overlap between rowKeys.
        /// </summary>
        internal static string ExpectedNoOverlapBetweenRowKeys
        {
            get
            {
                return ResourceManager.GetString("ExpectedNoOverlapBetweenRowKeys");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected one value in the storeList for every colKey.
        /// </summary>
        internal static string ExpectedOneValueForEveryColKey
        {
            get
            {
                return ResourceManager.GetString("ExpectedOneValueForEveryColKey");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected rowKey and colKey to be in matrix.  rowKey [{0}] or colKey [{1}] not found..
        /// </summary>
        internal static string ExpectedRowKeyAndColKeyToBeInMatrix
        {
            get
            {
                return ResourceManager.GetString("ExpectedRowKeyAndColKeyToBeInMatrix");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected the number of rows in the input array [{0}] to match the number of items in varList [{1}].
        /// </summary>
        internal static string ExpectedRowKeysCountToEqualValueArrayCount
        {
            get
            {
                return ResourceManager.GetString("ExpectedRowKeysCountToEqualValueArrayCount");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected rows of  matrices to match.
        /// </summary>
        internal static string ExpectedRowsOfMatricesToMatch
        {
            get
            {
                return ResourceManager.GetString("ExpectedRowsOfMatricesToMatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected storeList.Count [{0}] to equal colCount [{1}].
        /// </summary>
        internal static string ExpectedStoreListCountToEqualColCount
        {
            get
            {
                return ResourceManager.GetString("ExpectedStoreListCountToEqualColCount");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected 3 fields on each line,  found {0} in [{1}].
        /// </summary>
        internal static string ExpectedThreeFields
        {
            get
            {
                return ResourceManager.GetString("ExpectedThreeFields");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected to read all the bytes of a value.
        /// </summary>
        internal static string ExpectedToReadAllBytesOfValue
        {
            get
            {
                return ResourceManager.GetString("ExpectedToReadAllBytesOfValue");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected two fields, found [{0}].
        /// </summary>
        internal static string ExpectedTwoFieldsFoundN
        {
            get
            {
                return ResourceManager.GetString("ExpectedTwoFieldsFoundN");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected unique rowkeys in the matrix.
        /// </summary>
        internal static string ExpectedUniqueRowKeysInMatrix
        {
            get
            {
                return ResourceManager.GetString("ExpectedUniqueRowKeysInMatrix");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected UoPair&apos;s elements to be IComparable.
        /// </summary>
        internal static string ExpectedUoPairElementsToBeIComparable
        {
            get
            {
                return ResourceManager.GetString("ExpectedUoPairElementsToBeIComparable");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected a valid Range string in the form m-n or m or &apos;empty&apos; (or &apos;null&apos;).  Found [{0}].
        /// </summary>
        internal static string ExpectedValidRangeString
        {
            get
            {
                return ResourceManager.GetString("ExpectedValidRangeString");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected the &apos;val&apos; to be a single character.  Found [{0}].
        /// </summary>
        internal static string ExpectedValToBeSingleCharacter
        {
            get
            {
                return ResourceManager.GetString("ExpectedValToBeSingleCharacter");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expected 2 characters in val, found [{0}].
        /// </summary>
        internal static string ExpectedValToContainTwoCharacters
        {
            get
            {
                return ResourceManager.GetString("ExpectedValToContainTwoCharacters");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expect file to end after last value.
        /// </summary>
        internal static string ExpectFileToEndAfterLastValue
        {
            get
            {
                return ResourceManager.GetString("ExpectFileToEndAfterLastValue");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expect rowKey file and main file to agree on the rowkeys.
        /// </summary>
        internal static string ExpectRowKeyFileAndMainFileToAgreeOnTheRowkeys
        {
            get
            {
                return ResourceManager.GetString("ExpectRowKeyFileAndMainFileToAgreeOnTheRowkeys");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Expect to read rowKey.
        /// </summary>
        internal static string ExpectToReadRowKey
        {
            get
            {
                return ResourceManager.GetString("ExpectToReadRowKey");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .fa,.mpfa,.fna,.faa,.fsa,.fas,.fasta.
        /// </summary>
        internal static string FASTA_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("FASTA_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Fasta.
        /// </summary>
        internal static string FASTA_NAME
        {
            get
            {
                return ResourceManager.GetString("FASTA_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to FastA file should not contain sequences of more than one base alphabet type..
        /// </summary>
        internal static string FastAContainsMorethanOnebaseAlphabet
        {
            get
            {
                return ResourceManager.GetString("FastAContainsMorethanOnebaseAlphabet");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Writes an ISequence to a particular location, usually a file. The output is formatted
        ///according to the FastA file format. .
        /// </summary>
        internal static string FASTAFORMATTER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("FASTAFORMATTER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to FastA.
        /// </summary>
        internal static string FastAName
        {
            get
            {
                return ResourceManager.GetString("FastAName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A FastaParser reads from a source of text that is formatted according to the FASTA flat
        ///file specification, and converts the data to in-memory ISequence objects.  For advanced
        ///users, the ability to select an encoding for the internal memory representation is
        ///provided. There is also a default encoding for each alphabet that may be encountered..
        /// </summary>
        internal static string FASTAPARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("FASTAPARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Quality score line is empty for the sequence Id: {0}.
        /// </summary>
        internal static string FastQ_EmptyQualityScoreLine
        {
            get
            {
                return ResourceManager.GetString("FastQ_EmptyQualityScoreLine");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .fq,.fastq.
        /// </summary>
        internal static string FASTQ_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("FASTQ_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Quality scores header does not match with sequence header for the sequence Id: {0}.
        /// </summary>
        internal static string FastQ_InvalidQualityScoreHeaderData
        {
            get
            {
                return ResourceManager.GetString("FastQ_InvalidQualityScoreHeaderData");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Input file or data stream is missing &quot;+&quot; in the quality score header line for the sequence Id: {0}.
        /// </summary>
        internal static string FastQ_InvalidQualityScoreHeaderLine
        {
            get
            {
                return ResourceManager.GetString("FastQ_InvalidQualityScoreHeaderLine");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Total number of quality scores and sequence symbols are not same for the sequence Id: {0}.
        /// </summary>
        internal static string FastQ_InvalidQualityScoresLength
        {
            get
            {
                return ResourceManager.GetString("FastQ_InvalidQualityScoresLength");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Sequence data line is empty for the sequence Id: {0}.
        /// </summary>
        internal static string FastQ_InvalidSequenceLine
        {
            get
            {
                return ResourceManager.GetString("FastQ_InvalidSequenceLine");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Not a QualitativeSequence.
        /// </summary>
        internal static string FastQ_NotAQualitativeSequence
        {
            get
            {
                return ResourceManager.GetString("FastQ_NotAQualitativeSequence");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Writes an QualitativeSequence to a particular location, usually a file. The output is formatted according to the FASTQ file format..
        /// </summary>
        internal static string FASTQFORMATTER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("FASTQFORMATTER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to FastQ.
        /// </summary>
        internal static string FastQName
        {
            get
            {
                return ResourceManager.GetString("FastQName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A FastQParser reads from a source of text that is formatted according to the FASTQ file specification, and converts the data to in-memory QualitativeSequence objects..
        /// </summary>
        internal static string FASTQPARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("FASTQPARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Each line contains two columns and tab as delimiter.First column contain sequence id and second column contains the sequence..
        /// </summary>
        internal static string FIELDPARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("FIELDPARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .txt.
        /// </summary>
        internal static string FIELDPARSER_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("FIELDPARSER_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Field Parser.
        /// </summary>
        internal static string FIELDPARSER_NAME
        {
            get
            {
                return ResourceManager.GetString("FIELDPARSER_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {0} is already open. To open a new file please close the current file and try again..
        /// </summary>
        internal static string FileAlreadyOpen
        {
            get
            {
                return ResourceManager.GetString("FileAlreadyOpen");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The file name must not include any path information. It will be created in the other file&apos;s directory..
        /// </summary>
        internal static string FileNameMustNotContainPathInformation
        {
            get
            {
                return ResourceManager.GetString("FileNameMustNotContainPathInformation");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to File is already open..
        /// </summary>
        internal static string FileNotClosed
        {
            get
            {
                return ResourceManager.GetString("FileNotClosed");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to File is not opened. Please call Open method  to open the file..
        /// </summary>
        internal static string FileNotOpened
        {
            get
            {
                return ResourceManager.GetString("FileNotOpened");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to First input sequence alphabet does not match similarity matrix alphabet..
        /// </summary>
        internal static string FirstInputSequenceMismatchSimilarityMatrix
        {
            get
            {
                return ResourceManager.GetString("FirstInputSequenceMismatchSimilarityMatrix");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Maximum fixed diagonal difference.
        /// </summary>
        internal static string FIXED_SEPARATION_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("FIXED_SEPARATION_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Fixed Separation.
        /// </summary>
        internal static string FIXED_SEPARATION_NAME
        {
            get
            {
                return ResourceManager.GetString("FIXED_SEPARATION_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Forward Read is empty.
        /// </summary>
        internal static string ForwardReadCount
        {
            get
            {
                return ResourceManager.GetString("ForwardReadCount");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Cost of inserting a gap character.
        /// </summary>
        internal static string GAP_COST_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("GAP_COST_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Gap Cost.
        /// </summary>
        internal static string GAP_COST_NAME
        {
            get
            {
                return ResourceManager.GetString("GAP_COST_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Cost of extending an already existing gap.
        /// </summary>
        internal static string GAP_EXTENSION_COST_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("GAP_EXTENSION_COST_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Gap Extension Cost.
        /// </summary>
        internal static string GAP_EXTENSION_COST_NAME
        {
            get
            {
                return ResourceManager.GetString("GAP_EXTENSION_COST_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .gb,.gbk,.genbank.
        /// </summary>
        internal static string GENBANK_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("GENBANK_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to GenBank.
        /// </summary>
        internal static string GENBANK_NAME
        {
            get
            {
                return ResourceManager.GetString("GENBANK_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unexpected empty feature key..
        /// </summary>
        internal static string GenbankEmptyFeature
        {
            get
            {
                return ResourceManager.GetString("GenbankEmptyFeature");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Failed to parse locus token: {0}, Locus: {1}.
        /// </summary>
        internal static string GenBankFailedToParseLocusTokenFormat
        {
            get
            {
                return ResourceManager.GetString("GenBankFailedToParseLocusTokenFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Writes an ISequence to a particular location, usually a file. The output is formatted
        ///according to the GenBank file format. A method is also provided for quickly accessing
        ///the content in string form for applications that do not need to first write to file..
        /// </summary>
        internal static string GENBANKFORMATTER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("GENBANKFORMATTER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid feature line: {0}..
        /// </summary>
        internal static string GenbankInvalidFeature
        {
            get
            {
                return ResourceManager.GetString("GenbankInvalidFeature");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A GenBankParser reads from a source of text that is formatted according to the GenBank flat
        ///file specification, and converts the data to in-memory ISequence objects.  For advanced
        ///users, the ability to select an encoding for the internal memory representation is
        ///provided. There is also a default encoding for each alphabet that may be encountered..
        /// </summary>
        internal static string GENBANKPARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("GENBANKPARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unknown LOCUS format: {0}..
        /// </summary>
        internal static string GenBankUnknownLocusFormat
        {
            get
            {
                return ResourceManager.GetString("GenBankUnknownLocusFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .gff.
        /// </summary>
        internal static string GFF_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("GFF_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to GFF.
        /// </summary>
        internal static string GFF_NAME
        {
            get
            {
                return ResourceManager.GetString("GFF_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Writes an ISequence to a particular location, usually a file. The output is formatted
        ///according to the GFF file format. A method is also provided for quickly accessing
        ///the content in string form for applications that do not need to first write to file..
        /// </summary>
        internal static string GFFFORMATTER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("GFFFORMATTER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid {0} field: {1}..
        /// </summary>
        internal static string GffInvalidField
        {
            get
            {
                return ResourceManager.GetString("GffInvalidField");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid sequence line: {0}..
        /// </summary>
        internal static string GffInvalidSequence
        {
            get
            {
                return ResourceManager.GetString("GffInvalidSequence");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to GFF file contains no features..
        /// </summary>
        internal static string GFFNoFeatures
        {
            get
            {
                return ResourceManager.GetString("GFFNoFeatures");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A GffParser reads from a source of text that is formatted according to the GFF flat
        ///file specification, and converts the data to in-memory ISequence objects.  For advanced
        ///users, the ability to select an encoding for the internal memory representation is
        ///provided. There is also a default encoding for each alphabet that may be encountered..
        /// </summary>
        internal static string GFFPARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("GFFPARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unsupported GFF version: {0}..
        /// </summary>
        internal static string GffUnsupportedVersion
        {
            get
            {
                return ResourceManager.GetString("GffUnsupportedVersion");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Header should not contain null values..
        /// </summary>
        internal static string HeaderContainsNullValue
        {
            get
            {
                return ResourceManager.GetString("HeaderContainsNullValue");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Input sequences use different alphabets..
        /// </summary>
        internal static string InputAlphabetsMismatch
        {
            get
            {
                return ResourceManager.GetString("InputAlphabetsMismatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Length of input sequence should be greater than Length of MUM [{0}]..
        /// </summary>
        internal static string InputSequenceMustBeGreaterThanMUM
        {
            get
            {
                return ResourceManager.GetString("InputSequenceMustBeGreaterThanMUM");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to IntRangeValidator: Invalid arguments.
        /// </summary>
        internal static string IntRangeInvalidArgs
        {
            get
            {
                return ResourceManager.GetString("IntRangeInvalidArgs");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Bad input in file [{0}].
        /// </summary>
        internal static string INVALID_INPUT_FILE
        {
            get
            {
                return ResourceManager.GetString("INVALID_INPUT_FILE");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Symbol {0} is not a valid {1} symbol.
        /// </summary>
        internal static string INVALID_SYMBOL
        {
            get
            {
                return ResourceManager.GetString("INVALID_SYMBOL");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The alphabet type specified is invalid..
        /// </summary>
        internal static string InvalidAlphabetType
        {
            get
            {
                return ResourceManager.GetString("InvalidAlphabetType");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid encoded quality score found. {0} is not supported in {1} format..
        /// </summary>
        internal static string InvalidEncodedQualityScoreFound
        {
            get
            {
                return ResourceManager.GetString("InvalidEncodedQualityScoreFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid end data [{0}].
        /// </summary>
        internal static string InvalidEndData
        {
            get
            {
                return ResourceManager.GetString("InvalidEndData");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid item size.  Expected {0} bytes but found {1} for the item of type {2}..
        /// </summary>
        internal static string InvalidItemSizeExceptionFormat
        {
            get
            {
                return ResourceManager.GetString("InvalidItemSizeExceptionFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid location string [{0}].
        /// </summary>
        internal static string InvalidLocationString
        {
            get
            {
                return ResourceManager.GetString("InvalidLocationString");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid MinLengthOfMatch. It should be more than 0..
        /// </summary>
        internal static string InvalidMinLengthOfMatch
        {
            get
            {
                return ResourceManager.GetString("InvalidMinLengthOfMatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid optional field [{0}].
        /// </summary>
        internal static string InvalidOptionalField
        {
            get
            {
                return ResourceManager.GetString("InvalidOptionalField");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The parameter is invalid..
        /// </summary>
        internal static string InvalidParameter
        {
            get
            {
                return ResourceManager.GetString("InvalidParameter");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid {0}: &quot;{1}&quot;. The allowed pattern is: {2}..
        /// </summary>
        internal static string InvalidPatternMessage
        {
            get
            {
                return ResourceManager.GetString("InvalidPatternMessage");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid QName value. Maximum allowed length for QName value is 255 characters..
        /// </summary>
        internal static string InvalidQNameLength
        {
            get
            {
                return ResourceManager.GetString("InvalidQNameLength");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid quality score: [{0}].
        /// </summary>
        internal static string InvalidQualityScore
        {
            get
            {
                return ResourceManager.GetString("InvalidQualityScore");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid quality score found. {0} is not supported in {1} format..
        /// </summary>
        internal static string InvalidQualityScoreFound
        {
            get
            {
                return ResourceManager.GetString("InvalidQualityScoreFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Query direction must be Forward or Reverse.
        /// </summary>
        internal static string InvalidQueryDirection
        {
            get
            {
                return ResourceManager.GetString("InvalidQueryDirection");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid Range: &apos;begin&apos; [{0}] must be less than &apos;last&apos; [{1}].
        /// </summary>
        internal static string InvalidRangeBeginMustBeLessThanLast
        {
            get
            {
                return ResourceManager.GetString("InvalidRangeBeginMustBeLessThanLast");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid {0}: &quot;{1}&quot;. The allowed range is {2} to {3}..
        /// </summary>
        internal static string InvalidRangeMessage
        {
            get
            {
                return ResourceManager.GetString("InvalidRangeMessage");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid Range Size: Size of range must be greater than 0.  Found [{0}].
        /// </summary>
        internal static string InvalidRangeSizeOfRangeMustBeGreaterThanZero
        {
            get
            {
                return ResourceManager.GetString("InvalidRangeSizeOfRangeMustBeGreaterThanZero");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid Range Size: Size of range must be less than long.MaxValue.  Found [{0}].
        /// </summary>
        internal static string InvalidRangeSizeOfRangeMustBeLessThanMaxValue
        {
            get
            {
                return ResourceManager.GetString("InvalidRangeSizeOfRangeMustBeLessThanMaxValue");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Alphabet of {0} sequence is invalid..
        /// </summary>
        internal static string InvalidReferredAlphabet
        {
            get
            {
                return ResourceManager.GetString("InvalidReferredAlphabet");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid reference number found: {0}.
        /// </summary>
        internal static string InvalidRefNumber
        {
            get
            {
                return ResourceManager.GetString("InvalidRefNumber");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Only RNA or AmbiguousRNA sequence is allowed as input..
        /// </summary>
        internal static string InvalidRNASequenceInput
        {
            get
            {
                return ResourceManager.GetString("InvalidRNASequenceInput");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SearchParameter: Only int, float, and stringList supported..
        /// </summary>
        internal static string InvalidSearchParameter
        {
            get
            {
                return ResourceManager.GetString("InvalidSearchParameter");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid separator {0}.
        /// </summary>
        internal static string InvalidSeparator
        {
            get
            {
                return ResourceManager.GetString("InvalidSeparator");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid start data: {0}.
        /// </summary>
        internal static string InvalidStartData
        {
            get
            {
                return ResourceManager.GetString("InvalidStartData");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Start position must be less than or equal to the end position..
        /// </summary>
        internal static string InvalidStartNEndPositions
        {
            get
            {
                return ResourceManager.GetString("InvalidStartNEndPositions");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Could not recognize symbol: {0}.
        /// </summary>
        internal static string InvalidSymbol
        {
            get
            {
                return ResourceManager.GetString("InvalidSymbol");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Could not recognize one or more symbol in the sequence: {0}.
        /// </summary>
        internal static string InvalidSymbolInString
        {
            get
            {
                return ResourceManager.GetString("InvalidSymbolInString");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unknown type format: {0}..
        /// </summary>
        internal static string InvalidType
        {
            get
            {
                return ResourceManager.GetString("InvalidType");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {0} Format error - {1}.
        /// </summary>
        internal static string IOFormatErrorMessage
        {
            get
            {
                return ResourceManager.GetString("IOFormatErrorMessage");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to No text to parse in the specified input file or data stream..
        /// </summary>
        internal static string IONoTextToParse
        {
            get
            {
                return ResourceManager.GetString("IONoTextToParse");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Kmer sequence index is out of range for node.
        /// </summary>
        internal static string KmerIndexOutOfRange
        {
            get
            {
                return ResourceManager.GetString("KmerIndexOutOfRange");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to K-mers must be even to avoid palindromes.
        /// </summary>
        internal static string KmerLengthEven
        {
            get
            {
                return ResourceManager.GetString("KmerLengthEven");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to K-mer lengths greater than 31 are not supported..
        /// </summary>
        internal static string KmerLengthGreaterThan31
        {
            get
            {
                return ResourceManager.GetString("KmerLengthGreaterThan31");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Kmer Length is larger than the sequence length.
        /// </summary>
        internal static string KmerLengthIsTooLong
        {
            get
            {
                return ResourceManager.GetString("KmerLengthIsTooLong");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Kmer Length should be greater than 12.
        /// </summary>
        internal static string KmerLengthShouldBeOver12
        {
            get
            {
                return ResourceManager.GetString("KmerLengthShouldBeOver12");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Kmer length must be a positive number..
        /// </summary>
        internal static string KmerLengthShouldBePositive
        {
            get
            {
                return ResourceManager.GetString("KmerLengthShouldBePositive");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Kmer position or length is out of range for node.
        /// </summary>
        internal static string KmerPositionOutOfRange
        {
            get
            {
                return ResourceManager.GetString("KmerPositionOutOfRange");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SuffixTree builder using Dictionary.
        /// </summary>
        internal static string KurtzSuffixTreeBuilderName
        {
            get
            {
                return ResourceManager.GetString("KurtzSuffixTreeBuilderName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Minimum legnth of Maximal Unique Match.
        /// </summary>
        internal static string LENGTH_OF_MUM_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("LENGTH_OF_MUM_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Length of MUM.
        /// </summary>
        internal static string LENGTH_OF_MUM_NAME
        {
            get
            {
                return ResourceManager.GetString("LENGTH_OF_MUM_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Clone Library &apos;{0}&apos; doesn&apos;t exist.
        /// </summary>
        internal static string LibraryExist
        {
            get
            {
                return ResourceManager.GetString("LibraryExist");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Clone Library - Invalid Parameters.
        /// </summary>
        internal static string LibraryInvalidParameters
        {
            get
            {
                return ResourceManager.GetString("LibraryInvalidParameters");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to List is empty. Should contain at least one element!.
        /// </summary>
        internal static string LIST_EMPTY
        {
            get
            {
                return ResourceManager.GetString("LIST_EMPTY");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Bio.log.
        /// </summary>
        internal static string LogFileName
        {
            get
            {
                return ResourceManager.GetString("LogFileName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Mandatory tag {0} is not found for the record type {1}..
        /// </summary>
        internal static string MandatoryTagNotFound
        {
            get
            {
                return ResourceManager.GetString("MandatoryTagNotFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to RefStart={0} QueryStart={1} Length={2} Score={3} WrapScore={4} IsGood={5}.
        /// </summary>
        internal static string MatchExtensionToStringFormat
        {
            get
            {
                return ResourceManager.GetString("MatchExtensionToStringFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to RefStart={0} QueryStart={1} Length={2}.
        /// </summary>
        internal static string MatchToStringFormat
        {
            get
            {
                return ResourceManager.GetString("MatchToStringFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to ForwardReadID={0}, ReverseReadID={1}, MeanLength={2}, Standard Deviation={3}.
        /// </summary>
        internal static string MatePairToStringFormat
        {
            get
            {
                return ResourceManager.GetString("MatePairToStringFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The value in the pair should not be the special &apos;missing value&apos;..
        /// </summary>
        internal static string MatrixSpecialValueUseError
        {
            get
            {
                return ResourceManager.GetString("MatrixSpecialValueUseError");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Maximum separation between the adjacent matches in clusters.
        /// </summary>
        internal static string MAXIMUM_SEPARATION_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("MAXIMUM_SEPARATION_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Maximum Separation.
        /// </summary>
        internal static string MAXIMUM_SEPARATION_NAME
        {
            get
            {
                return ResourceManager.GetString("MAXIMUM_SEPARATION_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The Converter may not convert a non-missing value into the missing value..
        /// </summary>
        internal static string MayNotConvert
        {
            get
            {
                return ResourceManager.GetString("MayNotConvert");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Minimum output score.
        /// </summary>
        internal static string MINIMUM_SCORE_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("MINIMUM_SCORE_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Minimum Score.
        /// </summary>
        internal static string MINIMUM_SCORE_NAME
        {
            get
            {
                return ResourceManager.GetString("MINIMUM_SCORE_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Minimum two sequences are required to run alignment..
        /// </summary>
        internal static string MinimumTwoSequences
        {
            get
            {
                return ResourceManager.GetString("MinimumTwoSequences");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to MinLengthOfMatch should be greater than 0.
        /// </summary>
        internal static string MinLengthMustBeGreaterThanZero
        {
            get
            {
                return ResourceManager.GetString("MinLengthMustBeGreaterThanZero");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Complement overlap of items.
        /// </summary>
        internal static string MsgComplementOverlapItems
        {
            get
            {
                return ResourceManager.GetString("MsgComplementOverlapItems");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to plain overlap of items.
        /// </summary>
        internal static string MsgPlainOverlapItems
        {
            get
            {
                return ResourceManager.GetString("MsgPlainOverlapItems");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to ReverseComplement overlap of items.
        /// </summary>
        internal static string MsgReverseComplementOverlapItems
        {
            get
            {
                return ResourceManager.GetString("MsgReverseComplementOverlapItems");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Reverse overlap of items.
        /// </summary>
        internal static string MsgReverseOverlapItems
        {
            get
            {
                return ResourceManager.GetString("MsgReverseOverlapItems");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to MultiWaySuffixTree.
        /// </summary>
        internal static string MultiWaySuffixTreeName
        {
            get
            {
                return ResourceManager.GetString("MultiWaySuffixTreeName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Minimum length of MUM cannot be less than 1..
        /// </summary>
        internal static string MUMLengthTooSmall
        {
            get
            {
                return ResourceManager.GetString("MUMLengthTooSmall");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Pairwise global alignment.
        /// </summary>
        internal static string MUMmerAlignerDescription
        {
            get
            {
                return ResourceManager.GetString("MUMmerAlignerDescription");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to MUMmer.
        /// </summary>
        internal static string MUMmerAlignerName
        {
            get
            {
                return ResourceManager.GetString("MUMmerAlignerName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to MUMmer is a system for rapidly aligning entire genomes. Gets the exact matches between the reference and query sequences..
        /// </summary>
        internal static string MUMmerDescription
        {
            get
            {
                return ResourceManager.GetString("MUMmerDescription");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to MUMmer.
        /// </summary>
        internal static string MUMmerName
        {
            get
            {
                return ResourceManager.GetString("MUMmerName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to NcbiBlastParameters: Invalid parameter value {0} for parameter {0}..
        /// </summary>
        internal static string NcbiBlastInvalidValue
        {
            get
            {
                return ResourceManager.GetString("NcbiBlastInvalidValue");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to NcbiBlastParameters: Unknown parameter name {0}..
        /// </summary>
        internal static string NcbiBlastUnknownParam
        {
            get
            {
                return ResourceManager.GetString("NcbiBlastUnknownParam");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to NCBI QBLAST.
        /// </summary>
        internal static string NCBIQBLAST_NAME
        {
            get
            {
                return ResourceManager.GetString("NCBIQBLAST_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Pairwise global alignment.
        /// </summary>
        internal static string NEEDLEMAN_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("NEEDLEMAN_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Needleman-Wunsch.
        /// </summary>
        internal static string NEEDLEMAN_NAME
        {
            get
            {
                return ResourceManager.GetString("NEEDLEMAN_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .txt, .tre, .newick.
        /// </summary>
        internal static string NEWICK_FILE_EXTENSION
        {
            get
            {
                return ResourceManager.GetString("NEWICK_FILE_EXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Writes a PhylogeneticTree to a particular location, usually a file. The output is formatted
        ///according to the Newick format..
        /// </summary>
        internal static string NEWICK_FORMATTER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("NEWICK_FORMATTER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Newick.
        /// </summary>
        internal static string NEWICK_NAME
        {
            get
            {
                return ResourceManager.GetString("NEWICK_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Reads from a source of text that is formatted according to the Newick flat
        ///file specification, and converts the data to in-memory PhylogeneticTree object..
        /// </summary>
        internal static string NEWICK_PARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("NEWICK_PARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .nxs,.nex.
        /// </summary>
        internal static string NEXUS_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("NEXUS_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Nexus.
        /// </summary>
        internal static string NEXUS_NAME
        {
            get
            {
                return ResourceManager.GetString("NEXUS_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A NexusParser reads from a source of text that is formatted according to the Nexus flat file specification, and converts the data to in-memory ISequenceAlignment objects.  For advanced users, the ability to select an encoding for the internal memory representation is provided. There is also a default encoding for each alphabet that may be encountered..
        /// </summary>
        internal static string NEXUSPARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("NEXUSPARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Location with None operator can not contain sub locations..
        /// </summary>
        internal static string NoneWithSubLocs
        {
            get
            {
                return ResourceManager.GetString("NoneWithSubLocs");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Not supported in VirtualSequence.
        /// </summary>
        internal static string NotSupportedInVirtualSequence
        {
            get
            {
                return ResourceManager.GetString("NotSupportedInVirtualSequence");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Not supported in ReadOnlyCollection..
        /// </summary>
        internal static string NotSupportedReadOnlyCollection
        {
            get
            {
                return ResourceManager.GetString("NotSupportedReadOnlyCollection");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to ntax does not match the number of IDs..
        /// </summary>
        internal static string NtaxMismatch
        {
            get
            {
                return ResourceManager.GetString("NtaxMismatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to NUCmer.
        /// </summary>
        internal static string NUCMER
        {
            get
            {
                return ResourceManager.GetString("NUCMER");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Pairwise local alignment.
        /// </summary>
        internal static string NUCMERDESC
        {
            get
            {
                return ResourceManager.GetString("NUCMERDESC");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to LocationBuilder can not be null.
        /// </summary>
        internal static string NullLocationBuild
        {
            get
            {
                return ResourceManager.GetString("NullLocationBuild");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Resolver can not be null.
        /// </summary>
        internal static string NullResolver
        {
            get
            {
                return ResourceManager.GetString("NullResolver");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Offset cannot be greater than the sequence count..
        /// </summary>
        internal static string OffsetInvalid
        {
            get
            {
                return ResourceManager.GetString("OffsetInvalid");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Offset is greater than the number of elements in the sequence..
        /// </summary>
        internal static string OffsetOverflow
        {
            get
            {
                return ResourceManager.GetString("OffsetOverflow");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Only ambiguous RNA can contain ambiguous symbols on translation..
        /// </summary>
        internal static string OnlyAmbiguousRnaCanContainAmbiguousSymbolsOnTranslation
        {
            get
            {
                return ResourceManager.GetString("OnlyAmbiguousRnaCanContainAmbiguousSymbolsOnTranslation");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Only DNA &amp; RNA sequences can be passed as input to {0}..
        /// </summary>
        internal static string OnlyDNAOrRNAInput
        {
            get
            {
                return ResourceManager.GetString("OnlyDNAOrRNAInput");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Only Sequence class is supported..
        /// </summary>
        internal static string OnlySequenceClassSupported
        {
            get
            {
                return ResourceManager.GetString("OnlySequenceClassSupported");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to out-of-spec SOURCE.
        /// </summary>
        internal static string OutOfSpec
        {
            get
            {
                return ResourceManager.GetString("OutOfSpec");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Pairwise global alignment.
        /// </summary>
        internal static string PAIRWISE_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("PAIRWISE_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Pairwise-Overlap.
        /// </summary>
        internal static string PAIRWISE_NAME
        {
            get
            {
                return ResourceManager.GetString("PAIRWISE_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Pairwise Alignment expected 2 input sequences, received {0}..
        /// </summary>
        internal static string PairwiseAlignerWrongArgumentCount
        {
            get
            {
                return ResourceManager.GetString("PairwiseAlignerWrongArgumentCount");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to ch must be less than 256.
        /// </summary>
        internal static string ParamCHmustbeLessThan256
        {
            get
            {
                return ResourceManager.GetString("ParamCHmustbeLessThan256");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unknown parameter name {0}..
        /// </summary>
        internal static string PARAMETER_UNKNOWN
        {
            get
            {
                return ResourceManager.GetString("PARAMETER_UNKNOWN");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid parameter value {0} for parameter {0}..
        /// </summary>
        internal static string PARAMETER_VALUE_INVALID
        {
            get
            {
                return ResourceManager.GetString("PARAMETER_VALUE_INVALID");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Specified argument was out of the range it must be non negative and less than the count of this sequence..
        /// </summary>
        internal static string ParameterMustLessThanCount
        {
            get
            {
                return ResourceManager.GetString("ParameterMustLessThanCount");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Specified argument was out of the range it must be non negative..
        /// </summary>
        internal static string ParameterMustNonNegative
        {
            get
            {
                return ResourceManager.GetString("ParameterMustNonNegative");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to array.
        /// </summary>
        internal static string ParameterNameArray
        {
            get
            {
                return ResourceManager.GetString("ParameterNameArray");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to endPos.
        /// </summary>
        internal static string ParameterNameEndPos
        {
            get
            {
                return ResourceManager.GetString("ParameterNameEndPos");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to index.
        /// </summary>
        internal static string ParameterNameIndex
        {
            get
            {
                return ResourceManager.GetString("ParameterNameIndex");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to inputSequences.
        /// </summary>
        internal static string ParameterNameInputSequences
        {
            get
            {
                return ResourceManager.GetString("ParameterNameInputSequences");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to location.
        /// </summary>
        internal static string ParameterNameLocation
        {
            get
            {
                return ResourceManager.GetString("ParameterNameLocation");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to position.
        /// </summary>
        internal static string ParameterNamePosition
        {
            get
            {
                return ResourceManager.GetString("ParameterNamePosition");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to query.
        /// </summary>
        internal static string ParameterNameQuery
        {
            get
            {
                return ResourceManager.GetString("ParameterNameQuery");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to sequence.
        /// </summary>
        internal static string ParameterNameSequence
        {
            get
            {
                return ResourceManager.GetString("ParameterNameSequence");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to sequenceAlignment.
        /// </summary>
        internal static string ParameterNameSequenceAlignment
        {
            get
            {
                return ResourceManager.GetString("ParameterNameSequenceAlignment");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to sequenceItems.
        /// </summary>
        internal static string ParameterNameSequenceItems
        {
            get
            {
                return ResourceManager.GetString("ParameterNameSequenceItems");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to sequences.
        /// </summary>
        internal static string ParameterNameSequences
        {
            get
            {
                return ResourceManager.GetString("ParameterNameSequences");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to size.
        /// </summary>
        internal static string ParameterNameSize
        {
            get
            {
                return ResourceManager.GetString("ParameterNameSize");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to source.
        /// </summary>
        internal static string ParameterNameSource
        {
            get
            {
                return ResourceManager.GetString("ParameterNameSource");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to start.
        /// </summary>
        internal static string ParameterNameStart
        {
            get
            {
                return ResourceManager.GetString("ParameterNameStart");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to startPos.
        /// </summary>
        internal static string ParameterNameStartPos
        {
            get
            {
                return ResourceManager.GetString("ParameterNameStartPos");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to value.
        /// </summary>
        internal static string ParameterNameValue
        {
            get
            {
                return ResourceManager.GetString("ParameterNameValue");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to writer.
        /// </summary>
        internal static string ParameterNameWriter
        {
            get
            {
                return ResourceManager.GetString("ParameterNameWriter");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {0} should be {1} type.
        /// </summary>
        internal static string ParameterShouldBeofType
        {
            get
            {
                return ResourceManager.GetString("ParameterShouldBeofType");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to &apos;{0}&apos; is not a valid header..
        /// </summary>
        internal static string ParseHeaderError
        {
            get
            {
                return ResourceManager.GetString("ParseHeaderError");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Could not parse the specified file. File format is invalid..
        /// </summary>
        internal static string Parser_InvalidFileFormat
        {
            get
            {
                return ResourceManager.GetString("Parser_InvalidFileFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to No text to parse..
        /// </summary>
        internal static string Parser_NoTextErrorMessage
        {
            get
            {
                return ResourceManager.GetString("Parser_NoTextErrorMessage");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Incorrect alphabet set by user..
        /// </summary>
        internal static string ParserIncorrectAlphabet
        {
            get
            {
                return ResourceManager.GetString("ParserIncorrectAlphabet");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid date format: {0}..
        /// </summary>
        internal static string ParserInvalidDate
        {
            get
            {
                return ResourceManager.GetString("ParserInvalidDate");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid reference field name: {0}..
        /// </summary>
        internal static string ParserInvalidReferenceField
        {
            get
            {
                return ResourceManager.GetString("ParserInvalidReferenceField");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid source field name: {0}..
        /// </summary>
        internal static string ParserInvalidSourceField
        {
            get
            {
                return ResourceManager.GetString("ParserInvalidSourceField");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Error in PRIMARY line: {0}..
        /// </summary>
        internal static string ParserPrimaryLineError
        {
            get
            {
                return ResourceManager.GetString("ParserPrimaryLineError");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Data after REFERENCE should start with reference number: {0}..
        /// </summary>
        internal static string ParserReferenceError
        {
            get
            {
                return ResourceManager.GetString("ParserReferenceError");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Second locus encountered {0}..
        /// </summary>
        internal static string ParserSecondLocus
        {
            get
            {
                return ResourceManager.GetString("ParserSecondLocus");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unexpected line within sequence data: {0}..
        /// </summary>
        internal static string ParserUnexpectedLineInSequence
        {
            get
            {
                return ResourceManager.GetString("ParserUnexpectedLineInSequence");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Error parsing {0}:.
        /// </summary>
        internal static string ParsingError
        {
            get
            {
                return ResourceManager.GetString("ParsingError");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .phy,.ph.
        /// </summary>
        internal static string PHYLIP_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("PHYLIP_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Phylip.
        /// </summary>
        internal static string PHYLIP_NAME
        {
            get
            {
                return ResourceManager.GetString("PHYLIP_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A PhylipParser reads from a source of text that is formatted according to the Phylip flat file specification, and converts the data to in-memory ISequenceAlignment objects..
        /// </summary>
        internal static string PHYLIPPARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("PHYLIPPARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to PoolItem.Contig: Not a contig item..
        /// </summary>
        internal static string PoolItemNotContig
        {
            get
            {
                return ResourceManager.GetString("PoolItemNotContig");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to PoolItem.Contig: Item is contig, not sequence..
        /// </summary>
        internal static string PoolItemNotSequence
        {
            get
            {
                return ResourceManager.GetString("PoolItemNotSequence");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Reading {0}.
        /// </summary>
        internal static string ProgressStatus_Reading
        {
            get
            {
                return ResourceManager.GetString("ProgressStatus_Reading");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Protein.
        /// </summary>
        internal static string ProteinAlphabetName
        {
            get
            {
                return ResourceManager.GetString("ProteinAlphabetName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {0}...[{1}]
        ///{2}...[{3}].
        /// </summary>
        internal static string QualitativeSequenceToStringFormatForLongSequence
        {
            get
            {
                return ResourceManager.GetString("QualitativeSequenceToStringFormatForLongSequence");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {0}
        ///{1}.
        /// </summary>
        internal static string QualitativeSequenceToStringFormatForSmallSequence
        {
            get
            {
                return ResourceManager.GetString("QualitativeSequenceToStringFormatForSmallSequence");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Query sequence list cannot be null.
        /// </summary>
        internal static string QueryListCannotBeNull
        {
            get
            {
                return ResourceManager.GetString("QueryListCannotBeNull");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Query sequence cannot be null..
        /// </summary>
        internal static string QuerySequenceCannotBeNull
        {
            get
            {
                return ResourceManager.GetString("QuerySequenceCannotBeNull");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to RangeCollection is empty..
        /// </summary>
        internal static string RangeCollectionIsEmpty
        {
            get
            {
                return ResourceManager.GetString("RangeCollectionIsEmpty");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Cannot modify a read-only collection..
        /// </summary>
        internal static string READ_ONLY_COLLECTION_MESSAGE
        {
            get
            {
                return ResourceManager.GetString("READ_ONLY_COLLECTION_MESSAGE");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to One of the reads in input list is null.
        /// </summary>
        internal static string ReadCannotBeNull
        {
            get
            {
                return ResourceManager.GetString("ReadCannotBeNull");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to real assert.
        /// </summary>
        internal static string RealAssert
        {
            get
            {
                return ResourceManager.GetString("RealAssert");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Reference sequence list cannot be null..
        /// </summary>
        internal static string ReferenceListCannotBeNull
        {
            get
            {
                return ResourceManager.GetString("ReferenceListCannotBeNull");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Reference sequence cannot be null.
        /// </summary>
        internal static string ReferenceSequenceCannotBeNull
        {
            get
            {
                return ResourceManager.GetString("ReferenceSequenceCannotBeNull");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Can&apos;t parse sequences which contains &apos;=&apos; symbol without the reference sequence..
        /// </summary>
        internal static string RefSequenceNofFound
        {
            get
            {
                return ResourceManager.GetString("RefSequenceNofFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to REGISTRATION_LOADING_ERROR.
        /// </summary>
        internal static string RegistrationLoadingError
        {
            get
            {
                return ResourceManager.GetString("RegistrationLoadingError");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Flag {0} occurs multiple times..
        /// </summary>
        internal static string RepeatedFlags
        {
            get
            {
                return ResourceManager.GetString("RepeatedFlags");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Reverse Read is empty.
        /// </summary>
        internal static string ReverseReadCount
        {
            get
            {
                return ResourceManager.GetString("ReverseReadCount");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Rna.
        /// </summary>
        internal static string RnaAlphabetName
        {
            get
            {
                return ResourceManager.GetString("RnaAlphabetName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to RowKeyIndex seems to refer to a file of the wrong format..
        /// </summary>
        internal static string RowKeyIndexSeemsToReferToAFileOfTheWrongFormat
        {
            get
            {
                return ResourceManager.GetString("RowKeyIndexSeemsToReferToAFileOfTheWrongFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Header is missing in one of the aligned sequence in specified sequenceAlignment object..
        /// </summary>
        internal static string SAM_AlignedSequenceHeaderMissing
        {
            get
            {
                return ResourceManager.GetString("SAM_AlignedSequenceHeaderMissing");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .sam.
        /// </summary>
        internal static string SAM_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("SAM_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SAM format does not supports writing multiple ISequenceAlignment objects to a file..
        /// </summary>
        internal static string SAM_FormatMultipleAlignmentsNotSupported
        {
            get
            {
                return ResourceManager.GetString("SAM_FormatMultipleAlignmentsNotSupported");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Invalid SAM File..
        /// </summary>
        internal static string SAM_InvalidInputFile
        {
            get
            {
                return ResourceManager.GetString("SAM_InvalidInputFile");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SAM.
        /// </summary>
        internal static string SAM_NAME
        {
            get
            {
                return ResourceManager.GetString("SAM_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to *.
        /// </summary>
        internal static string SAM_NO_REFERENCE_DEFINED_INDICATOR
        {
            get
            {
                return ResourceManager.GetString("SAM_NO_REFERENCE_DEFINED_INDICATOR");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SAMAlignedSequenceHeader not found.
        /// </summary>
        internal static string SAMAlignedSequenceHeaderNotFound
        {
            get
            {
                return ResourceManager.GetString("SAMAlignedSequenceHeaderNotFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SAMAlignmentHeader not found.
        /// </summary>
        internal static string SAMAlignmentHeaderNotFound
        {
            get
            {
                return ResourceManager.GetString("SAMAlignmentHeaderNotFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Writes a SequenceAlignmentMap to a particular location, usually a file. The output is formatted
        ///according to the SAM file format..
        /// </summary>
        internal static string SAMFORMATTER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("SAMFORMATTER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SAM only supports DNA aplhabet..
        /// </summary>
        internal static string SAMFormatterSupportsDNAOnly
        {
            get
            {
                return ResourceManager.GetString("SAMFormatterSupportsDNAOnly");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A SAMParser reads from a source of text that is formatted according to the SAM 
        ///file specification, and converts the data to in-memory SequenceAlignmentMap objects..
        /// </summary>
        internal static string SAMPARSER_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("SAMPARSER_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Alphabet can&apos;t be set as SAM supports only SAMDNA alphabet..
        /// </summary>
        internal static string SAMParserAlphabetCantBeSet
        {
            get
            {
                return ResourceManager.GetString("SAMParserAlphabetCantBeSet");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SearchParameter: Only int, double, and string supported..
        /// </summary>
        internal static string SearchParamInvalidArgs
        {
            get
            {
                return ResourceManager.GetString("SearchParamInvalidArgs");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Second input sequence alphabet does not match similarity matrix alphabet..
        /// </summary>
        internal static string SecondInputSequenceMismatchSimilarityMatrix
        {
            get
            {
                return ResourceManager.GetString("SecondInputSequenceMismatchSimilarityMatrix");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The number of bytes must be evenly divisible by the count.
        /// </summary>
        internal static string SegmentByteArrayInvalidCount
        {
            get
            {
                return ResourceManager.GetString("SegmentByteArrayInvalidCount");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Separation factor.
        /// </summary>
        internal static string SEPARATION_FACTOR_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("SEPARATION_FACTOR_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Separation Factor.
        /// </summary>
        internal static string SEPARATION_FACTOR_NAME
        {
            get
            {
                return ResourceManager.GetString("SEPARATION_FACTOR_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Sequences are of different alphabet type in the alignment..
        /// </summary>
        internal static string SequenceAlphabetMismatch
        {
            get
            {
                return ResourceManager.GetString("SequenceAlphabetMismatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Sequence should not be null.
        /// </summary>
        internal static string SequenceCannotBeNull
        {
            get
            {
                return ResourceManager.GetString("SequenceCannotBeNull");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Number of sequence in alignment do not match the actual count..
        /// </summary>
        internal static string SequenceCountMismatch
        {
            get
            {
                return ResourceManager.GetString("SequenceCountMismatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Sequence {0} contains more than 2GB data.
        /// </summary>
        internal static string SequenceDataGreaterthan2GB
        {
            get
            {
                return ResourceManager.GetString("SequenceDataGreaterthan2GB");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Cross product of input sequences length ({0}, {1}) exceeds integer maximum value {2}..
        /// </summary>
        internal static string SequenceLengthExceedsLimit
        {
            get
            {
                return ResourceManager.GetString("SequenceLengthExceedsLimit");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Sequence length does not match..
        /// </summary>
        internal static string SequenceLengthMismatch
        {
            get
            {
                return ResourceManager.GetString("SequenceLengthMismatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Sequence length in alignment do not match the actual length..
        /// </summary>
        internal static string SequenceLengthsMismatch
        {
            get
            {
                return ResourceManager.GetString("SequenceLengthsMismatch");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to End index of SequenceRange cannot be lesser than start index.
        /// </summary>
        internal static string SequenceRangeEndError
        {
            get
            {
                return ResourceManager.GetString("SequenceRangeEndError");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SequenceRange start and end cannot be set to negative numbers.
        /// </summary>
        internal static string SequenceRangeNonNegative
        {
            get
            {
                return ResourceManager.GetString("SequenceRangeNonNegative");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Start index of SequenceRange cannot be greater than end index.
        /// </summary>
        internal static string SequenceRangeStartError
        {
            get
            {
                return ResourceManager.GetString("SequenceRangeStartError");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to ID={0} Start={1} End={2}.
        /// </summary>
        internal static string SequenceRangeToStringFormat
        {
            get
            {
                return ResourceManager.GetString("SequenceRangeToStringFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {0} - {1}.
        /// </summary>
        internal static string SequenceStatisticsToStringFormat
        {
            get
            {
                return ResourceManager.GetString("SequenceStatisticsToStringFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Bio.WebServiceHandlers.dll.
        /// </summary>
        internal static string SERVICE_HANDLER_ASSEMBLY
        {
            get
            {
                return ResourceManager.GetString("SERVICE_HANDLER_ASSEMBLY");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to The complete size should not be smaller than the current size.
        /// </summary>
        internal static string ShouldNotBeSmaller
        {
            get
            {
                return ResourceManager.GetString("ShouldNotBeSmaller");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Describes matrix that determines the score for any possible pair of symbols.
        /// </summary>
        internal static string SIMILARITY_MATRIX_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("SIMILARITY_MATRIX_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Similarity Matrix.
        /// </summary>
        internal static string SIMILARITY_MATRIX_NAME
        {
            get
            {
                return ResourceManager.GetString("SIMILARITY_MATRIX_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SimilarityMatrix from file or stream. Bad or missing value in line {0}, exception {1}..
        /// </summary>
        internal static string SimilarityMatrix_BadOrMissingValue
        {
            get
            {
                return ResourceManager.GetString("SimilarityMatrix_BadOrMissingValue");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Diagonal (Match x Mismatch).
        /// </summary>
        internal static string SimilarityMatrix_DiagonalSM
        {
            get
            {
                return ResourceManager.GetString("SimilarityMatrix_DiagonalSM");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SimilarityMatrix from file or stream. Fewer matrix line than needed..
        /// </summary>
        internal static string SimilarityMatrix_FewerMatrixLines
        {
            get
            {
                return ResourceManager.GetString("SimilarityMatrix_FewerMatrixLines");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SimilarityMatrix from file or stream. Invalid molecule type {0} in similarity matrix file..
        /// </summary>
        internal static string SimilarityMatrix_InvalidMoleculeType
        {
            get
            {
                return ResourceManager.GetString("SimilarityMatrix_InvalidMoleculeType");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SimilarityMatrix from file or stream. Missing name (first line)..
        /// </summary>
        internal static string SimilarityMatrix_NameMissing
        {
            get
            {
                return ResourceManager.GetString("SimilarityMatrix_NameMissing");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SimilarityMatrix from file or stream. Missing second line..
        /// </summary>
        internal static string SimilarityMatrix_SecondLineMissing
        {
            get
            {
                return ResourceManager.GetString("SimilarityMatrix_SecondLineMissing");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Similarity Matrix cannot be null..
        /// </summary>
        internal static string SimilarityMatrixCannotBeNull
        {
            get
            {
                return ResourceManager.GetString("SimilarityMatrixCannotBeNull");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Implements a simple greedy assembly algorithm for DNA..
        /// </summary>
        internal static string SIMPLE_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("SIMPLE_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Simple-Sequence.
        /// </summary>
        internal static string SIMPLE_NAME
        {
            get
            {
                return ResourceManager.GetString("SIMPLE_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Basic SNP Parser that uses XSV format.
        /// </summary>
        internal static string SIMPLE_SNP_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("SIMPLE_SNP_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .tsv.
        /// </summary>
        internal static string SIMPLE_SNP_FILEEXTENSION
        {
            get
            {
                return ResourceManager.GetString("SIMPLE_SNP_FILEEXTENSION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Basic SNP.
        /// </summary>
        internal static string SIMPLE_SNP_NAME
        {
            get
            {
                return ResourceManager.GetString("SIMPLE_SNP_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Pairwise local alignment.
        /// </summary>
        internal static string SMITH_DESCRIPTION
        {
            get
            {
                return ResourceManager.GetString("SMITH_DESCRIPTION");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Smith-Waterman.
        /// </summary>
        internal static string SMITH_NAME
        {
            get
            {
                return ResourceManager.GetString("SMITH_NAME");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Text reader to read SNP sequences from cannot be null.
        /// </summary>
        internal static string snpTextReaderNull
        {
            get
            {
                return ResourceManager.GetString("snpTextReaderNull");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Index was out of range. Must be non-negative and less than the maximum value of an integer..
        /// </summary>
        internal static string SparseSequenceConstructorIndexOutofRange
        {
            get
            {
                return ResourceManager.GetString("SparseSequenceConstructorIndexOutofRange");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to SQ header is missing for {0}..
        /// </summary>
        internal static string SQHeaderMissing
        {
            get
            {
                return ResourceManager.GetString("SQHeaderMissing");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Start cannot be less than zero.
        /// </summary>
        internal static string StartCannotBeLessThanZero
        {
            get
            {
                return ResourceManager.GetString("StartCannotBeLessThanZero");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to StartData can not be null or empty..
        /// </summary>
        internal static string StartDataCannotBeNull
        {
            get
            {
                return ResourceManager.GetString("StartDataCannotBeNull");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Zero nucleotides in input..
        /// </summary>
        internal static string SymbolCountZero
        {
            get
            {
                return ResourceManager.GetString("SymbolCountZero");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Symbol already exists in alphabet..
        /// </summary>
        internal static string SymbolExistsInAlphabet
        {
            get
            {
                return ResourceManager.GetString("SymbolExistsInAlphabet");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to There are duplicate rows which do not have identical values..
        /// </summary>
        internal static string ThereAreDuplicateRowsWhichDoNotHDupRowsNonIdenticalValues
        {
            get
            {
                return ResourceManager.GetString("ThereAreDuplicateRowsWhichDoNotHDupRowsNonIdenticalValues");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {0}... +[{1}].
        /// </summary>
        internal static string ToStringFormat
        {
            get
            {
                return ResourceManager.GetString("ToStringFormat");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {0} : Bad source in Traceback..
        /// </summary>
        internal static string TracebackBadSource
        {
            get
            {
                return ResourceManager.GetString("TracebackBadSource");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unbalanced paranthesis.
        /// </summary>
        internal static string UnbalancedParanthesis
        {
            get
            {
                return ResourceManager.GetString("UnbalancedParanthesis");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Unexpected second sequence name encountered: {0}..
        /// </summary>
        internal static string UnexpectedSecondSequenceName
        {
            get
            {
                return ResourceManager.GetString("UnexpectedSecondSequenceName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {0}: Don&apos;t know element &apos;{1}&apos;..
        /// </summary>
        internal static string UnknownElement
        {
            get
            {
                return ResourceManager.GetString("UnknownElement");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to {1}Unknown option found: {0}.
        /// </summary>
        internal static string UnknownOption
        {
            get
            {
                return ResourceManager.GetString("UnknownOption");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to .wig.
        /// </summary>
        internal static string Wiggle_FileExtension
        {
            get
            {
                return ResourceManager.GetString("Wiggle_FileExtension");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Parsing failed. Bad input in file..
        /// </summary>
        internal static string WiggleBadInputInFile
        {
            get
            {
                return ResourceManager.GetString("WiggleBadInputInFile");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Writes a WiggleAnnotation to a particular location, usually a file. The output is formatted according to the Wiggle file format..
        /// </summary>
        internal static string WiggleFormatterDescription
        {
            get
            {
                return ResourceManager.GetString("WiggleFormatterDescription");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Failed to parse wiggle header..
        /// </summary>
        internal static string WiggleInvalidHeader
        {
            get
            {
                return ResourceManager.GetString("WiggleInvalidHeader");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Wiggle.
        /// </summary>
        internal static string WiggleName
        {
            get
            {
                return ResourceManager.GetString("WiggleName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to This operation is not supported on variable step wiggle files..
        /// </summary>
        internal static string WiggleNotSupportedOnVariableStep
        {
            get
            {
                return ResourceManager.GetString("WiggleNotSupportedOnVariableStep");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A Wiggle parser reads from a source of text that is formatted according to the Wiggle file specification (only fixed and variable step files), and converts the data to in-memory WiggleAnnotation objects..
        /// </summary>
        internal static string WiggleParserDescription
        {
            get
            {
                return ResourceManager.GetString("WiggleParserDescription");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Could not find a comment line with the offset, sequence ID.
        /// </summary>
        internal static string XsvOffsetNotFound
        {
            get
            {
                return ResourceManager.GetString("XsvOffsetNotFound");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Sparse Sequence formatter to character separated value file.
        /// </summary>
        internal static string XsvSparseFormatterDesc
        {
            get
            {
                return ResourceManager.GetString("XsvSparseFormatterDesc");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to XsvSparseFormatter.
        /// </summary>
        internal static string XsvSparseFormatterName
        {
            get
            {
                return ResourceManager.GetString("XsvSparseFormatterName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Parses sparse sequences from character separated value reader.
        /// </summary>
        internal static string XsvSparseParserDesc
        {
            get
            {
                return ResourceManager.GetString("XsvSparseParserDesc");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to csv,tsv.
        /// </summary>
        internal static string XsvSparseParserFileTypes
        {
            get
            {
                return ResourceManager.GetString("XsvSparseParserFileTypes");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to XsvSparseParser.
        /// </summary>
        internal static string XsvSparseParserName
        {
            get
            {
                return ResourceManager.GetString("XsvSparseParserName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Zipped Fasta.
        /// </summary>
        internal static string ZippedFASTAName
        {
            get
            {
                return ResourceManager.GetString("ZippedFASTAName");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to A FastaParser reads from a source of text that is formatted according to the FASTA flat
        ///file specification, and converts the data to in-memory ISequence objects.  For advanced
        ///users, the ability to select an encoding for the internal memory representation is
        ///provided. There is also a default encoding for each alphabet that may be encountered..
        /// </summary>
        internal static string ZippedFASTAParserDescription
        {
            get
            {
                return ResourceManager.GetString("ZippedFASTAParserDescription");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Writes an QualitativeSequence to a particular location, usually a file. The output is formatted according to the FASTQ file format..
        /// </summary>
        internal static string ZippedFASTQDescription
        {
            get
            {
                return ResourceManager.GetString("ZippedFASTQDescription");
            }
        }

        /// <summary>
        ///   Looks up a localized string similar to Zipped Fastq.
        /// </summary>
        internal static string ZippedFASTQName
        {
            get
            {
                return ResourceManager.GetString("ZippedFASTQName");
            }
        }
    }
}
