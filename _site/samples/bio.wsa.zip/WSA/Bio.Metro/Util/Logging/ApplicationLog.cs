﻿namespace Bio.Util.Logging
{
    // use this when you want a single, static logger for the whole
    // application (the usual case)

    /// <summary>
    /// log is a class that implements straightforward logging to a text file, 
    /// and tries to minimize clutter of the code that uses it.
    /// </summary>
    public static class ApplicationLog
    {
        /// <summary>
        /// Write a plain string to the output, then a newline.
        /// </summary>
        /// <param name="output">the string</param>
        /// <returns>the string</returns>
        public static string WriteLine(string output, params object[] args)
        {
            System.Diagnostics.Debug.WriteLine(output);
            return "";
        }
    }
}