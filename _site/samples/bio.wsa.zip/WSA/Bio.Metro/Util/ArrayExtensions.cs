﻿using System;

namespace Bio
{
    /// <summary>
    /// Extension methods on Arrays
    /// </summary>
    public static class ArrayExtensions
    {
        /// <summary>
        /// Returns the LongLength property of an array.
        /// </summary>
        /// <param name="arr">Array of which the length has to be found.</param>
        /// <returns>Length of the array.</returns>
        public static long LongLength(this Array arr)
        {
            if (arr == null)
            {
                throw new ArgumentNullException("arr");
            }

            return arr.Length; 
        }
    }
}
