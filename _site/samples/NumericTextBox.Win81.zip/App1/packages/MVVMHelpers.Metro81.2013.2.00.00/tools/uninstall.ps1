param($installPath, $toolsPath, $package, $project)
Write-Host "MVVMHelpers was removed, however Blend SDK (XAML) is still being referenced, if you do not need it you can manually remove it."