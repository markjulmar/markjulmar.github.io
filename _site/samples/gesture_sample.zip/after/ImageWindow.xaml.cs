﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Windows7.Interop;

namespace ImageViewer
{
    /// <summary>
    /// Interaction logic for ImageWindow.xaml
    /// </summary>
    public partial class ImageWindow
    {
        private IntPtr _hwnd;
        private uint _panID;
        private Point _ptStart;
        private int _currImage;
        private readonly List<string> _images = new List<string>();
        private Storyboard _sbSlideLeft;
        private Storyboard _sbSlideRight;
        private double _startingAngle;

        public ImageWindow()
        {
            Loaded += Window_Loaded;
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetImageDirectories();

            _currImage = 0;
            LoadImage(_images[0]);

            _sbSlideLeft = (Storyboard) LayoutRoot.FindResource("slideLeft");
            _sbSlideRight = (Storyboard) LayoutRoot.FindResource("slideRight");

            SetupGestures();
        }

        private void GetImageDirectories()
        {
            var library = NativeMethods.SHLoadLibraryFromKnownFolder(KnownFolders.FOLDERID_PicturesLibrary, (int) STGM.STGM_READ);

            object ppv;
            library.GetFolders(LIBRARYFOLDERFILTER.LFF_ALLITEMS, Marshal.GenerateGuidForType(typeof(IShellItemArray)), out ppv);
            var itemArray = (IShellItemArray) ppv;

            uint numItems;
            itemArray.GetCount(out numItems);
            for (uint i = 0; i < numItems; i++)
            {
                IShellItem item;
                itemArray.GetItemAt(i, out item);

                IntPtr displayName;
                item.GetDisplayName(SIGDN.SIGDN_FILESYSPATH, out displayName);
                string dirName = Marshal.PtrToStringUni(displayName);
                if (!string.IsNullOrEmpty(dirName))
                    _images.AddRange(Directory.GetFiles(dirName, "*.jpg"));
            }
        }

        private void LoadImage(string imageFile)
        {
            bottomImage.Source = (ImageSource)new ImageSourceConverter().ConvertFromString(imageFile);
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Left)
            {
                PreviousImage();
            }
            else if (e.Key == Key.Right)
            {
                NextImage();
            }
            else if (e.Key == Key.Space)
            {
                ResetImage();
            }
        }

        private void ResetImage()
        {
            topImageRotate.Angle = 0;
            topImageScale.ScaleX = topImageScale.ScaleY = 1;
        }

        private void PreviousImage()
        {
            if (--_currImage < 0)
                _currImage = _images.Count - 1;
            LoadImage(_images[_currImage]);
            _sbSlideRight.Begin(LayoutRoot);
        }

        private void NextImage()
        {
            if (++_currImage > _images.Count - 1)
                _currImage = 0;
            LoadImage(_images[_currImage]);
            _sbSlideLeft.Begin(LayoutRoot);
        }

        private void OnSlideCompleted(object sender, EventArgs e)
        {
            topImage.Source = bottomImage.Source;
        }

        private void SetupGestures()
        {
            _hwnd = new WindowInteropHelper(this).Handle;
            HwndSource src = HwndSource.FromHwnd(_hwnd);
            if (src != null)
                src.AddHook(WndProc);

            if (NativeMethods.RegisterTouchWindow(_hwnd, 0))
                NativeMethods.UnregisterTouchWindow(_hwnd);
            else
                MessageBox.Show("Could not register for touch events -- multitouch likely not supported.");

            // Setup the gestures
            var gConfig = new[] {
                new GESTURECONFIG
                    {
                        dwID = GestureID.GID_PAN,
                        dwBlock = WantGestures.GC_PAN_WITH_SINGLE_FINGER_VERTICALLY | WantGestures.GC_PAN_WITH_INERTIA | WantGestures.GC_PAN_WITH_GUTTER,
                        dwWant = WantGestures.GC_PAN_WITH_SINGLE_FINGER_HORIZONTALLY
                    },
                new GESTURECONFIG
                    {
                        dwID = GestureID.GID_ROTATE,
                        dwWant = WantGestures.GC_ANY
                    },
                new GESTURECONFIG
                    {
                        dwID = GestureID.GID_ZOOM,
                        dwWant = WantGestures.GC_ANY
                    },
                new GESTURECONFIG
                    {
                        dwID = GestureID.GID_TWOFINGERTAP,
                        dwWant = WantGestures.GC_ANY
                    },
            };
            NativeMethods.SetGestureConfig(_hwnd, 0, gConfig.Length,
                                           gConfig, Marshal.SizeOf(gConfig[0]));
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            switch (msg)
            {
                case NativeMessages.WM_GESTURE:
                    OnGesture(lParam);
                    handled = true;
                    break;
                case NativeMessages.WM_TABLET_QUERYSYSTEMGESTURESTATUS:
                    handled = true;
                    return new IntPtr((int) (TabletSettings.TABLET_ENABLE_ROTATEGESTURE | TabletSettings.TABLET_ENABLE_MULTITOUCHDATA));
                default:
                    break;                    
            }

            return IntPtr.Zero;
        }

        private void OnGesture(IntPtr gestureMsg)
        {
            var gesture = new GESTUREINFO();
            gesture.cbSize = Marshal.SizeOf(gesture);
            if (NativeMethods.GetGestureInfo(gestureMsg, out gesture))
            {
                switch (gesture.dwID)
                {
                    case GestureID.GID_PAN:
                        OnPan(gesture.dwInstanceID, ConvertPoint(gesture.ptsLocation), gesture.dwFlags);
                        break;
                    case GestureID.GID_ROTATE:
                        OnRotate(gesture.ullArguments, gesture.dwFlags);
                        break;
                    case GestureID.GID_TWOFINGERTAP:
                        ResetImage();
                        break;
                    case GestureID.GID_ZOOM:
                        OnZoom(ConvertPoint(gesture.ptsLocation), gesture.ullArguments, gesture.dwFlags);
                        break;
                    default:
                        break;
                }
            }
            NativeMethods.CloseGestureInfoHandle(gestureMsg);
        }

        private long _startingScale;

        private void OnZoom(Point ptCenter, long scale, GestureFlags gestureFlags)
        {
            if ((gestureFlags & GestureFlags.GF_BEGIN) > 0)
            {
                _startingScale = scale;
            }
            else
            {
                double ratio = ((double)scale / (double)_startingScale);
                ratio = Math.Min(Math.Max(ratio, .1), 5);

                topImageScale.ScaleX = topImageScale.ScaleY = ratio;
            }
        }

        private Point ConvertPoint(POINTS pts)
        {
            var pt = new POINT { X = pts.X, Y = pts.Y };
            NativeMethods.ScreenToClient(_hwnd, ref pt);
            return new Point(pt.X, pt.Y);
        }

        private void OnPan(uint id, Point point, GestureFlags gestureFlags)
        {
            if ((gestureFlags & GestureFlags.GF_BEGIN) > 0)
            {
                _ptStart = point;
                _panID = id;
            }
            else if (id == _panID && (gestureFlags & GestureFlags.GF_END) > 0)
            {
                _panID = 0;
                if (_ptStart.X > point.X)
                    NextImage();
                else if (_ptStart.X < point.X)
                    PreviousImage();
            }
        }

        private void OnRotate(double radians, GestureFlags gestureFlags)
        {
            double angle = NativeMethods.ROTATE_ANGLE_FROM_ARGUMENT(radians) * (180.0 / Math.PI);
            if ((gestureFlags & GestureFlags.GF_BEGIN) > 0)
                _startingAngle = angle;
            else 
                topImageRotate.Angle = _startingAngle - angle;
        }
    }
}
