﻿namespace FocusTest
{
    /// <summary>
    /// Interaction logic for Page2.xaml
    /// </summary>
    public partial class Page2
    {
        public Page2()
        {
            InitializeComponent();
            clickMeButton.Focus();
        }
    }
}
