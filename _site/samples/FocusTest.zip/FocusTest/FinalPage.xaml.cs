﻿namespace FocusTest
{
    /// <summary>
    /// Interaction logic for FinalPage.xaml
    /// </summary>
    public partial class FinalPage
    {
        public FinalPage()
        {
            InitializeComponent();
        }
    }
}
