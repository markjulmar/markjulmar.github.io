﻿using System.Windows.Input;

namespace FocusTest
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void OnNextPage(object sender, ExecutedRoutedEventArgs e)
        {
            if (Pages.SelectedIndex < Pages.Items.Count)
                Pages.SelectedIndex++;
            else
                Pages.SelectedIndex = 0;
        }

        private void OnPreviousPage(object sender, ExecutedRoutedEventArgs e)
        {
            if (Pages.SelectedIndex < Pages.Items.Count)
                Pages.SelectedIndex--;
            else
                Pages.SelectedIndex = Pages.Items.Count - 1;
        }

        private void OnCloseApp(object sender, ExecutedRoutedEventArgs e)
        {
            Close();
        }
    }
}
