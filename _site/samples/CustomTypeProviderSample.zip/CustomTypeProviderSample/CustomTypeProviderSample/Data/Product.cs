using CustomHelper;

namespace CustomTypeProviderSample.Data
{
    /// <summary>
    /// This approach shows the easiest way to implement
    /// the custom type provider - where we simply derive
    /// directly from the helper.  We get all the support
    /// to add dynamic properties directly.
    /// </summary>
    public class Product : CustomTypeHelper<Product>
    {
        private string _name;
        private int _price;

        // Existing known properties.
        public string Name
        {
            get { return _name; }
            set { _name = value; RaisePropertyChanged(); }
        }

        public int Price
        {
            get { return _price; }
            set { _price = value; RaisePropertyChanged(); }
        }
    }
}