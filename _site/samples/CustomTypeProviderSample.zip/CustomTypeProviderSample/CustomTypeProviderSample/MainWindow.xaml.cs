﻿using System.Collections.ObjectModel;
using System.Windows;
using CustomTypeProviderSample.Data;

namespace CustomTypeProviderSample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Customer> Customers = new ObservableCollection<Customer>();
        public ObservableCollection<Product> Products = new ObservableCollection<Product>();

        public MainWindow()
        {
            Loaded += OnLoaded;
            InitializeComponent();
        }

        private void OnLoaded(object sender, RoutedEventArgs routedEventArgs)
        {
            customersGrid.ItemsSource = Customers;
            productsGrid.ItemsSource = Products;
            customersGrid2.ItemsSource = Customers;
            productsGrid2.ItemsSource = Products;
        }

        private void OnGetData(object sender, RoutedEventArgs e)
        {
            if (button1.IsEnabled == true)
            {
                Customer.AddProperty("Age", typeof(int));
                Customer.AddProperty("Married", typeof(bool));

                Customer customer1 = new Customer { FirstName = "Julie", LastName = "Smith" };
                customer1.SetPropertyValue("Age", 38);
                customer1.SetPropertyValue("Married", true);

                Customer customer2 = new Customer { FirstName = "Mark", LastName = "Smith" };
                customer2.SetPropertyValue("Age", 43);
                customer2.SetPropertyValue("Married", true);

                Customers.Add(customer1);
                Customers.Add(customer2);

                Product.AddProperty("Available", typeof(bool));
                Product product1 = new Product { Name = "Soap", Price = 2 };
                product1.SetPropertyValue("Available", true);

                Products.Add(product1);
                button1.IsEnabled = false;
            }            
        }
    }
}
