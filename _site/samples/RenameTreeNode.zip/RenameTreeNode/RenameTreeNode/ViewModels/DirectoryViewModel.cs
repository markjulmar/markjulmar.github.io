﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using JulMar.Windows.Extensions;
using JulMar.Windows.Interfaces;
using JulMar.Windows.Mvvm;
using System.IO;
using System.Collections.Generic;

namespace RenameTreeNode.ViewModels
{
    /// <summary>
    /// Sample ViewModel that wraps a Directory.
    /// </summary>
    public class DirectoryViewModel : ViewModel
    {
        /// <summary>
        /// String used to send message to main view model about directory selection.
        /// </summary>
        internal const string SelectedDirectoryChangedMessage = @"SelectedDirectoryChanged";

        /// <summary>
        /// Marker directory that signals expansion of the tree.
        /// </summary>
        internal static DirectoryViewModel MarkerDirectory = new DirectoryViewModel();

        #region Internal Data
        private bool _isSelected, _isExpanded, _isEditingName;
        private readonly DirectoryInfo _data;
        private readonly ObservableCollection<FileViewModel> _files;
        private readonly ObservableCollection<DirectoryViewModel> _subdirs;
        #endregion

        /// <summary>
        /// Name of the directory
        /// </summary>
        public string Name
        {
            get { return _data.Name; }

            // Code to rename directory
            set
            {
                string newValue = value;
                if (!string.IsNullOrEmpty(newValue))
                {
                    // Remove any trailing backslash.
                    string fullName = _data.FullName.TrimEnd(Path.DirectorySeparatorChar);

                    // Determine the new directory name
                    string directoryPath = fullName.Substring(0, fullName.Length - _data.Name.Length);
                    if (!string.IsNullOrEmpty(directoryPath) && directoryPath != fullName)
                    {
                        string newFullName = Path.Combine(directoryPath, newValue);
                        try
                        {
                            _data.MoveTo(newFullName);
                        }
                        catch (IOException ex)
                        {
                            var errorVisualizer = Resolve<IErrorVisualizer>();
                            if (errorVisualizer != null)
                            {
                                errorVisualizer.Show("Cannot rename directory", ex.Message);
                            }
                        }
                    }
                }

                // Tell WPF the name has changed.  Note if the same control is being used to display vs. edit then the
                // binding will need to force WPF3x to re-read the property value.  This is done by using a RefreshValueConverter; 
                // under .NET4 this won't be necessary.
                OnPropertyChanged("Name");

                // Flip off the editing bit
                IsEditingName = false;
            }
        }

        /// <summary>
        /// True/False whether we are changing the name of the directory
        /// </summary>
        public bool IsEditingName
        {
            get { return _isEditingName; }
            set { _isEditingName = value; OnPropertyChanged("IsEditingName"); }
        }

        /// <summary>
        /// Full path + name of the directory
        /// </summary>
        public string FullName
        {
            get { return _data.FullName; }
        }

        /// <summary>
        /// True/False whether the directory is selected (i.e. current).
        /// Selecting the directory causes it to populate it's file collection.
        /// </summary>
        public bool IsSelected
        {
            get { return _isSelected; }
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;

                    if (_isSelected)
                    {
                        if (_files.Count == 1 && _files[0] == FileViewModel.MarkerFile)
                        {
                            _files.Clear();
                            try
                            {
                                _data.GetFiles()
                                    .Where(f => (f.Attributes & (FileAttributes.Hidden | FileAttributes.System)) == 0)
                                    .ForEach(f => _files.Add(new FileViewModel(f)));
                            }
                            catch
                            {
                                // Ignore file/security exceptions
                            }
                            OnPropertyChanged("TotalFiles", "TotalFileSize");
                        }
                        SendMessage(SelectedDirectoryChangedMessage, this);
                    }
                    else
                    {
                        _files.Clear();
                        _files.Add(FileViewModel.MarkerFile);
                    }

                    OnPropertyChanged("IsSelected");
                }
            }
        }

        /// <summary>
        /// True/False if the directory is expanded. Expanding the directory causes it
        /// to fill it's subdirectory collection.
        /// </summary>
        public bool IsExpanded
        {
            get { return _isExpanded; }
            set
            {
                if (_isExpanded != value)
                {
                    _isExpanded = value;
                    if (_isExpanded)
                    {
                        if (_subdirs.Count == 1 && _subdirs[0] == DirectoryViewModel.MarkerDirectory)
                        {
                            _subdirs.Clear();
                            try
                            {
                                _data.GetDirectories()
                                    .Where(d => (d.Attributes & (FileAttributes.Hidden | FileAttributes.System)) == 0)
                                    .ForEach(d => _subdirs.Add(new DirectoryViewModel(d)));
                            }
                            catch
                            {
                                // Ignore security/access errors
                            }
                        }
                    }
                    // Throw them away to recollect later - implements a refresh.
                    else
                    {
                        _subdirs.Clear();
                        _subdirs.Add(DirectoryViewModel.MarkerDirectory);
                    }
                }

                OnPropertyChanged("IsExpanded");
            }
        }

        /// <summary>
        /// Command used to switch to editing mode
        /// </summary>
        public ICommand SwitchToEditingMode { get; private set; }

        /// <summary>
        /// List of files in this directory.
        /// </summary>
        public IList<FileViewModel> Files { get { return _files; } }

        /// <summary>
        /// List of subdirectories in this directory.
        /// </summary>
        public IList<DirectoryViewModel> Subdirectories { get { return _subdirs; } }

        /// <summary>
        /// Count of files in this directory.
        /// </summary>
        public int TotalFiles { get { return _files.Count; } }

        /// <summary>
        /// Total size of all files in this directory.
        /// </summary>
        public long TotalFileSize { get { return _files.Sum(file => file.Size); } }

        /// <summary>
        /// Constructor for the marker directory.  This is used to detect an expansion.
        /// </summary>
        private DirectoryViewModel()
        {
            // Command that switches us into editing mode.
            SwitchToEditingMode = new DelegatingCommand(() => IsEditingName = !IsEditingName, () => _data.FullName != _data.Name);
        }

        /// <summary>
        /// Public constructor
        /// </summary>
        /// <param name="di">DirectoryInfo to pull information from</param>
        public DirectoryViewModel(DirectoryInfo di) : this()
        {
            if (di == null)
                throw new ArgumentNullException("di");

            _data = di;
            _files = new ObservableCollection<FileViewModel> { FileViewModel.MarkerFile };
            _subdirs = new ObservableCollection<DirectoryViewModel> { DirectoryViewModel.MarkerDirectory };
        }
    }
}
