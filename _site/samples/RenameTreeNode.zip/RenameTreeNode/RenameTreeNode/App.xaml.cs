﻿using JulMar.Windows.Mvvm;

namespace RenameTreeNode
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        public App()
        {
            // Register standard service types with the service mediator.
            ViewModel.RegisterKnownServiceTypes();
        }
    }
}
