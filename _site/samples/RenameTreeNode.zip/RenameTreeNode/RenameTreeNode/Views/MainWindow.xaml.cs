﻿using System.Windows.Controls;
using System.Windows.Input;

namespace RenameTreeNode.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This selects all the text and pushes focus to the TextBox when it 
        /// is shown.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnTextBoxVisible(object sender, System.EventArgs e)
        {
            TextBox tb = (TextBox) sender;
            if (tb.IsLoaded &&
                tb.Visibility == System.Windows.Visibility.Visible &&
                FocusManager.GetFocusedElement(this) != tb)
            {
                tb.Focus();
                tb.SelectAll();
            }
        }
    }
}
