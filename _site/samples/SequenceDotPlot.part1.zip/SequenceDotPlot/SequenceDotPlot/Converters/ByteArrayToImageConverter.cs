﻿using System;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using JulMar.Windows.Extensions;

namespace SequenceDotPlot.Converters
{
    /// <summary>
    /// Value converter to take a byte[row,col] and produce a dotplot image.
    /// </summary>
    public class ByteArrayToImageConverter : IValueConverter
    {
        /// <summary>
        /// Converts a value. 
        /// </summary>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (Designer.InDesignMode)
                return null;

            byte[,] values = value as byte[,];
            if (values == null)
                return null;

            int height = values.GetLength(0);
            int width = values.GetLength(1);

            byte[] buffer = new byte[height*width];

            int i = 0;
            for (int row = 0; row < height; row++)
            {
                for (int col = 0; col < width; col++)
                {
                    buffer[i++] = values[row, col];
                }
            }

            return BitmapSource.Create(width, height, 96, 96, PixelFormats.Gray8, null, buffer, width);
        }

        /// <summary>
        /// Converts a value. 
        /// </summary>
        /// <returns>
        /// A converted value. If the method returns null, the valid null value is used.
        /// </returns>
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
