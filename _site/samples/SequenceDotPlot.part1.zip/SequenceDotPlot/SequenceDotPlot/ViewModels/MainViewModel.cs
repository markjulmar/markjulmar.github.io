﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Input;
using Bio;
using Bio.IO;
using JulMar.Windows.Mvvm;
using Microsoft.Win32;
using JulMar.Windows.Interfaces;
using System.Threading.Tasks;

namespace SequenceDotPlot.ViewModels
{
    /// <summary>
    /// Primary view model holding the data.
    /// </summary>
    public class MainViewModel : ViewModel
    {
        // Sequences we have loaded.
        private readonly ISequence[] _sequences = new ISequence[2];
        // Filenames which produced sequences
        private readonly string[] _sequenceFiles = new string[2];
        // Dot-Plot data
        private byte[,] _plotData;

        /// <summary>
        /// The first sequence filename
        /// </summary>
        public string FirstSequence { get { return _sequenceFiles[0]; } }

        /// <summary>
        /// The second sequence filename
        /// </summary>
        public string SecondSequence { get { return _sequenceFiles[1]; } }

        /// <summary>
        /// Commands
        /// </summary>
        public ICommand SelectFirstSequence { get; private set; }
        public ICommand SelectSecondSequence { get; private set; }

        /// <summary>
        /// Plot data
        /// </summary>
        public byte[,] PlotData { get { return _plotData; } }

        /// <summary>
        /// Constructor
        /// </summary>
        public MainViewModel()
        {
            SelectFirstSequence = new DelegatingCommand(() => SelectSequence(0, "FirstSequence"));
            SelectSecondSequence = new DelegatingCommand(() => SelectSequence(1, "SecondSequence"));
        }

        /// <summary>
        /// This selects a sequence from a filename.
        /// </summary>
        /// <param name="index"></param>
        /// <param name="propertyName"></param>
        private void SelectSequence(int index, string propertyName)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "All Files (*.*)|*.*|" + 
                string.Join("|", SequenceParsers.All.Select(sp => string.Format("{0}|{1}", sp.Name, 
                    sp.SupportedFileTypes.Replace(',',';').Replace(".","*."))));

            if (ofd.ShowDialog() == true)
            {
                string fileExtension = Path.GetExtension(ofd.FileName);
                if (!string.IsNullOrEmpty(fileExtension))
                {
                    ISequenceParser parser = SequenceParsers.FindParserByFileName(ofd.FileName) ??
                                             SequenceParsers.All.FirstOrDefault(sp => sp.SupportedFileTypes.Contains(fileExtension));

                    if (parser != null)
                    {
                        _sequenceFiles[index] = Path.GetFileName(ofd.FileName);
                        OnPropertyChanged(propertyName);

                        try
                        {
                            _sequences[index] = parser.Parse().First();
                        }
                        catch (Exception ex)
                        {
                            IErrorVisualizer errorVisualizer = Resolve<IErrorVisualizer>();
                            errorVisualizer.Show("Failed to load sequence", ex.Message);
                        }

                        if (_sequences[0] != null && _sequences[1] != null)
                        {
                            CalculateDataPlot();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// This creates our dot-plot from the two loaded sequences.
        /// </summary>
        private void CalculateDataPlot()
        {
            const byte ON = 0xff;
            const byte OFF = 0x00;

            long width = _sequences[0].Count;
            long height = _sequences[1].Count;
            
            _plotData = new byte[height,width];

            Parallel.For(0, height, row =>
            {
                for (long column = 0; column < width; column++)
                {
                    _plotData[row,column] = _sequences[0][column] == _sequences[1][row] ? ON : OFF;
                }
            });

            OnPropertyChanged(() => PlotData);
        }

        }
}
