using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using MonoTouch.Dialog;

namespace CourseViewerJson
{
    public partial class CourseViewerJsonViewController : DialogViewController
    {
        public CourseViewerJsonViewController () : base (UITableViewStyle.Grouped, null)
        {
            Root = JsonElement.FromFile ("offline.txt");
        }
    }
}

