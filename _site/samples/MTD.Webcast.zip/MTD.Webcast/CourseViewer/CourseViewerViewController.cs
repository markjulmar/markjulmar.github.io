using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using MonoTouch.Dialog;
using DM.Courses.Data;
using System.Threading.Tasks;
using System.Linq;

namespace CourseViewer
{
    public partial class CourseViewerViewController : DialogViewController
    {
        const string Header = "Developmentor Courses";

        public CourseViewerViewController () 
            : base (GenerateAnimatingElement())
        {
            EnableSearch = true;
            //AutoHideSearch = true;
            SearchPlaceholder = "Search for Courses";
            RefreshRequested += OnReloadData;
            LoadData ();
        }

        private static RootElement GenerateAnimatingElement()
        {
            return new RootElement (Header) {
                new Section()
                {
                    new ActivityElement()
                    {
                        Animating = true,
                        Caption = "Loading Data...",
                        Flags = UIViewElement.CellFlags.Transparent
                    }
                }
            };
        }

        async void OnReloadData (object sender, EventArgs e)
        {
            await LoadData();
            this.ReloadComplete ();
        }

        private async Task LoadData()
        {
            var courseReader = new JsonCourseReader();
            var courses = await courseReader.GetCourses ();

            RootElement root = new RootElement (Header) {
                courses.GroupBy (c => c.PrimaryCourseGroup == null ? "(empty)" : c.PrimaryCourseGroup.Name)
                    .Select (cg => new Section (cg.Key) {
                    Footer = cg.Count () + " courses",
                    Elements = cg.Select (c => 
                                new StyledStringElement (c.Name, () => OnSelectCourse (c)) {
                        Accessory = UITableViewCellAccessory.DisclosureIndicator,
                        Image = (c.IsFavorite) ? UIImage.FromBundle ("Favorite") : UIImage.FromBundle ("NotFavorite"),
                        Font = UIFont.SystemFontOfSize (12)
                    }).Cast<Element> ().ToList ()
                })
            };

            this.Root = root;
        }

        void OnSelectCourse (CourseDto course)
        {
            FinishSearch ();
            NavigationController.PushViewController (
                new CourseDetailsViewController (course), true);
        }
    }

    public class InlineHtmlView : UIWebView
    {
        public InlineHtmlView (string htmlData, RectangleF frame)
            :base(frame)
        {
            this.LoadHtmlString (htmlData, null);
        }
    }

    public class UIWebViewController : UIViewController
    {
        string htmlText;
        UIWebView _webView;

        public UIWebViewController (string htmlText)
        {
            this.htmlText = htmlText;
            Title = "Course Details";
        }

        public override void ViewDidLoad ()
        {
            base.ViewDidLoad ();
            Add(_webView = new UIWebView (View.Bounds));
            _webView.LoadHtmlString (htmlText, null);
        }
    }

    public class CourseDetailsViewController : DialogViewController
    {
        CourseDto course;

        public CourseDetailsViewController (CourseDto course)
            : base(UITableViewStyle.Grouped, null, true)
        {
            Title = course.Name;
            this.course = course;
            GenerateCourseDetails ();            
        }

        async Task GenerateCourseDetails ()
        {
            var root = new RootElement (course.Name) {
                new Section()
                {
                    new StringElement("Name", course.Name),
                    new StringElement("Details", () =>
                        {
                            NavigationController.PushViewController(
                                new UIWebViewController(course.Details), true);
                        }),
                    new HtmlElement("More Info", course.Url),
                },
                new Section("Upcoming Classes"),
                new Section("Description") {
                    new UIViewElement("",
                        new InlineHtmlView(course.Description,
                            new RectangleF(0, 0, View.Bounds.Width, 200)), false),
                }

            };

            this.Root = root;

            JsonCourseReader courseReader = new JsonCourseReader ();
            var courses = (from cd in await courseReader.GetEngagementsForCourse (course.Id)
                                    select new StringElement (cd.StartDate.ToShortDateString (),
                                            string.Format ("{0} {1} - {2} days", 
                        cd.City, cd.Country, cd.LengthInDays))).Cast<Element>().ToList();
            if (courses.Count > 0) {
                root [1].AddAll (courses);
            } else {
                root [1].Add (new StringElement ("None"));
            }

            root [1].Add (new StringElement ("Call for onsite",
                () => UIApplication.SharedApplication.OpenUrl (
                    NSUrl.FromString ("tel://8006991932"))));
        }
    }
}

