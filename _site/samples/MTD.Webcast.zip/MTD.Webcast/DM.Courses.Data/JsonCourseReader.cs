using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace DM.Courses.Data
{
    /// <summary>
    /// This class reads the online course calendar and details from
    /// Developmentor's website.
    /// </summary>
    public sealed class JsonCourseReader
    {
        private const string AllCourses = "http://www.develop.com/api/course/all";
        private const string Engagements = "http://www.develop.com/api/course/engagements/";

        private async Task<string> GetJsonStream(string url)
        {
            return await new HttpClient().GetStringAsync (url);
        }

        private async Task<T> GetObject<T>(string url)
        {
            var deserializer = new DataContractJsonSerializer(typeof(T), new[] { typeof(CourseGroupDto) });
            using (var stream = new MemoryStream(Encoding.Unicode.GetBytes(await this.GetJsonStream(url))))
            {
                return (T) deserializer.ReadObject(stream);
            }
        }

        /// <summary>
        /// This method returns all the courses
        /// </summary>
        /// <returns>CourseDto list</returns>
        public async Task<IEnumerable<CourseDto>> GetCourses()
        {
            var courses = (await this.GetObject<CourseDto[]>(AllCourses)).ToList();
            foreach (var c in courses) {
                c.IsFavorite |= (c.Name.Contains("4.5") || 
                    c.Name.Contains("Guerrilla") || c.Name.Contains("5.0")
                    || c.Name.Contains("WPF") || c.Name.Contains("ioS"));
            }

            return courses;
        }

        /// <summary>
        /// Returns a specific engagement for a given course id.
        /// </summary>
        /// <param name="courseId">Course to retrieve</param>
        /// <returns>Engagement</returns>
        public async Task<IEnumerable<EngagementDto>> GetEngagementsForCourse(string courseId)
        {
            return await this.GetObject<EngagementDto[]>(Engagements + courseId);
        }
    }
}
