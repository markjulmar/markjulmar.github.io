namespace DM.Courses.Data
{
    /// <summary>
    /// This represents a single course on the site.
    /// </summary>
    public class CourseDto
    {
        /// <summary>
        /// Unique course Id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Name of the course
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// True if this is a favorite course
        /// </summary>
        /// <value><c>true</c> if this instance is favorite; otherwise, <c>false</c>.</value>
        public bool IsFavorite { get; set; }

        /// <summary>
        /// Description (HTML)
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Details for the course (HTML)
        /// </summary>
        public string Details { get; set; }

        /// <summary>
        /// URL on the website to show the course.
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// Primary group for this course.
        /// </summary>
        public CourseGroupDto PrimaryCourseGroup { get; set; }
    }
}