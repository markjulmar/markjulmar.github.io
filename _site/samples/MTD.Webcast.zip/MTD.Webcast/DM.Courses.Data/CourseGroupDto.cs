namespace DM.Courses.Data
{
    /// <summary>
    /// Grouping for courses
    /// </summary>
    public class CourseGroupDto
    {
        // Changed to complex object in latest schema
        //public object Id { get; set; }
        public string Name { get; set; }
    }
}