using System;

namespace DM.Courses.Data
{
    /// <summary>
    /// Represents a single Developmentor engagement
    /// </summary>
    public class EngagementDto
    {
        /// <summary>
        /// True if this is a featured engagement (shown on the main page)
        /// </summary>
        public bool IsFeatured { get; set; }

        /// <summary>
        /// Start date
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Course length in days
        /// </summary>
        public int LengthInDays { get; set; }

        /// <summary>
        /// Name of the course
        /// </summary>
        public string CourseName { get; set; }

        /// <summary>
        /// Course number
        /// </summary>
        public string CourseNumber { get; set; }

        /// <summary>
        /// Address of the course
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// City of the course
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Country for the course
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        /// Phone (often blank)
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// Short start date
        /// </summary>
        public string ShortDate { get; set; }

        /// <summary>
        /// URL for course details
        /// </summary>
        public string CourseUrl { get; set; }

        /// <summary>
        /// Short name
        /// </summary>
        public string ShortName { get; set; }
    }
}