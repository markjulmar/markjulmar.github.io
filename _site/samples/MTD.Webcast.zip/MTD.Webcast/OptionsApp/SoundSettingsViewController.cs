using System;
using MonoTouch.Dialog;

namespace OptionsApp
{
    public class SoundSettingsViewController : DialogViewController
    {
        SoundSettings _settings;
        BindingContext _bindingContext;

        public SoundSettingsViewController (SoundSettings settings, object context)
            : base(null)
        {
            _settings = settings;
            _bindingContext = new BindingContext (context, settings, "Sound Settings");

            this.Root = _bindingContext.Root;
        }

        public override void ViewWillDisappear (bool animated)
        {
            base.ViewWillDisappear (animated);
            _bindingContext.Fetch ();
        }
    }
}

