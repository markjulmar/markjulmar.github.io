using MonoTouch.Dialog;
using MonoTouch.UIKit;

namespace OptionsApp
{
    public enum SafetyLevel
    {
        Minimum,
        Normal, 
        Maximim
    }

    public class SoundSettings
    {
        [Entry("Enter Settings Name", KeyboardType = UIKeyboardType.Default)]
        public string Name { get; set; }

        public SafetyLevel SafetyLevel { get; set; }

        [Section("Advanced")]
        public bool BackgroundMusicDetection { get; set; }
        public bool Use3DSoundDetection { get; set; }

        [Section("Max Decibels Allowed", "Adjust the sensitivity of the test.")]
        [Range(10,100)]
        public float MaxDecibelsAllowed { get; set; }

        [Section]
        [Alignment(UITextAlignment.Center)]
        [OnTap("OnDismiss")]
        public string Finished;

        public SoundSettings ()
        {
            Name = "Sample Settings";
            SafetyLevel = SafetyLevel.Normal;
            BackgroundMusicDetection = false;
            Use3DSoundDetection = false;
            MaxDecibelsAllowed = 60;
        }
    }
}

