// WARNING
//
// This file has been generated automatically by Xamarin Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;
using System.CodeDom.Compiler;

namespace OptionsApp
{
	[Register ("OptionsAppViewController")]
	partial class OptionsAppViewController
	{
		[Outlet]
		MonoTouch.UIKit.UILabel BackgroundDetectLabel { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel MaxLevelLabel { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel NameLabel { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel SettingLabel { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel ThreeDSoundLabel { get; set; }

		[Action ("OnChangeOptions:")]
		partial void OnChangeOptions (MonoTouch.Foundation.NSObject sender);
		
		void ReleaseDesignerOutlets ()
		{
			if (NameLabel != null) {
				NameLabel.Dispose ();
				NameLabel = null;
			}

			if (SettingLabel != null) {
				SettingLabel.Dispose ();
				SettingLabel = null;
			}

			if (BackgroundDetectLabel != null) {
				BackgroundDetectLabel.Dispose ();
				BackgroundDetectLabel = null;
			}

			if (ThreeDSoundLabel != null) {
				ThreeDSoundLabel.Dispose ();
				ThreeDSoundLabel = null;
			}

			if (MaxLevelLabel != null) {
				MaxLevelLabel.Dispose ();
				MaxLevelLabel = null;
			}
		}
	}
}
