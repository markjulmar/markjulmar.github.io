using System;
using System.Drawing;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace OptionsApp
{
    public partial class OptionsAppViewController : UIViewController
    {
        SoundSettings settings = new SoundSettings();

        public OptionsAppViewController () : base ("OptionsAppViewController", null)
        {
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear (animated);
            LoadViewData ();
        }

        void LoadViewData ()
        {
            this.NameLabel.Text = settings.Name;

            switch (settings.SafetyLevel) {
            case SafetyLevel.Minimum:
                this.SettingLabel.Text = "Minimum Noise Filter";
                this.SettingLabel.TextColor = UIColor.Red;
                break;
            case SafetyLevel.Normal:
                this.SettingLabel.Text = "Normal Noise Filter";
                this.SettingLabel.TextColor = UIColor.Brown;
                break;
            case SafetyLevel.Maximim:
                this.SettingLabel.Text = "Max Noise Filter";
                this.SettingLabel.TextColor = UIColor.Green;
                break;
            }

            this.MaxLevelLabel.Text = settings.MaxDecibelsAllowed.ToString ();
            this.BackgroundDetectLabel.Text = settings.BackgroundMusicDetection ? "ON" : "OFF";
            this.BackgroundDetectLabel.TextColor = settings.BackgroundMusicDetection ? UIColor.Green : UIColor.Red;
            this.ThreeDSoundLabel.Text = settings.Use3DSoundDetection ? "ON" : "OFF";
            this.ThreeDSoundLabel.TextColor = settings.Use3DSoundDetection ? UIColor.Green : UIColor.Red;
        }

        partial void OnChangeOptions (NSObject sender)
        {
            SoundSettingsViewController vc = new SoundSettingsViewController(settings, this);

            UIView.Animate(.75, () =>
                {
                    UIView.SetAnimationCurve(UIViewAnimationCurve.EaseInOut);
                    NavigationController.PushViewController(vc, false);
                    UIView.SetAnimationTransition(UIViewAnimationTransition.FlipFromLeft,
                        NavigationController.View, false);
                });
        }

        public void OnDismiss()
        {
            UIView.Animate(.75, () =>
                {
                    UIView.SetAnimationCurve(UIViewAnimationCurve.EaseInOut);
                    NavigationController.PopViewControllerAnimated(false);
                    UIView.SetAnimationTransition(UIViewAnimationTransition.FlipFromRight,
                        NavigationController.View, false);
                });
        }
    }
}

