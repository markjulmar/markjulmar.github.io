using System;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;

using DM.Courses.Data;

using Newtonsoft.Json;
using System.Collections.Generic;

namespace GenerateOfflineCourses
{
    class Program
    {
        static void Main(string[] args)
        {
            var result = Run().Result;
            var json = JsonConvert.SerializeObject(result, Formatting.Indented);
            Console.WriteLine(json);
        }

        static async Task<dynamic> Run()
        {
            dynamic root = new ExpandoObject();

            var courseReader = new JsonCourseReader();
            var allCourses = (from course in await courseReader.GetCourses() 
                              where course.PrimaryCourseGroup != null && course.Name.ToLower().Contains("test") == false
                              group course by course.PrimaryCourseGroup.Name).ToList();

            root.title = "Developmentor Courses";
            root.sections = new dynamic[allCourses.Count];
            for (int index = 0; index < allCourses.Count; index++)
            {
                var courseGroup = allCourses[index];
                var courses = courseGroup.ToList();
                dynamic cg = new ExpandoObject();
                root.sections[index] = cg;

                cg.header = courseGroup.Key;
                cg.footer = courses.Count + " courses";
                cg.id = "course-group" + index;
                cg.elements = new dynamic[courses.Count];
                for (int courseIndex = 0; courseIndex < courses.Count; courseIndex++)
                {
                    var course = courses[courseIndex];
                    var engagements = (await courseReader.GetEngagementsForCourse (course.Id)).ToList();

                    dynamic c = new ExpandoObject();
                    cg.elements[courseIndex] = c;

                    c.type = "root";
                    c.title = course.Name;
                    c.sections = GenerateCourseDetails(course, engagements);
                }
            }

            return root;
        }

        private static dynamic[] GenerateCourseDetails(CourseDto courseDto, IEnumerable<EngagementDto> engagements)
        {
            return new dynamic[]
            {
                new
                {
                    elements = new dynamic[]
                    {
                        new { type = "string", caption = "Course Name", value = courseDto.Name },
                        new { type = "html", caption = "More Information", url = courseDto.Url },
                        new { type = "html", caption = "Contact Us", url = "tel://18006991932" },                           
                    }
                },

                new
                {
                    header = "Upcoming Classes",
                    elements = engagements.Any() 
                      ? engagements.Select (e => 
                        new 
                        { 
                            type = "string", 
                            caption = e.StartDate.ToShortDateString (),
                            value = string.Format ("{0} {1} {2} days", e.City, e.Country, e.LengthInDays)
                        }).ToArray<dynamic>()
                     : new dynamic[] { new { type = "string", caption = "None" } }
                                                      
                }
            };
        }
    }
}
