﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MBF;
using MBF.IO.Fasta;
using MBF.Util.Logging;

namespace MBFStarterApp
{
    class Program
    {
        static void Main(string[] args)
        {
            IList<ISequence> sequences = ParseFastA(@"c:\users\mark\desktop\test\5S.A.fasta");
            ISequence firstSequence = sequences.First();
            //firstSequence[0] = firstSequence.Alphabet[0];

            firstSequence = firstSequence.Reverse;

            ExportFastA(firstSequence, @"c:\users\mark\desktop\out.fasta");
        }

        /// <summary>
        /// Exports a given sequence to a file in FastA format
        /// </summary>
        /// <param name="sequence">Sequence to be exported.</param>
        /// <param name="filename">Target filename.</param>
        static void ExportFastA(ISequence sequence, string filename)
        {
            // A formatter to export the output
            FastaFormatter formatter = new FastaFormatter();

            // Exports the sequence to a file
            formatter.Format(sequence, filename);
        }

        /// <summary>
        /// Parses a FastA file which has one or more sequences.
        /// </summary>
        /// <param name="filename">Path to the file to be parsed.</param>
        /// <returns>List of ISequence objects</returns>
        static IList<ISequence> ParseFastA(string filename)
        {
            // A new parser to import a file
            FastaParser parser = new FastaParser();
            return parser.Parse(filename, false);
        }

        /// <summary>
        /// Write a given string to the application log.
        /// </summary>
        /// <param name="matter">String to write to the log.</param>
        static void WriteLog(string matter)
        {
            // Open log if not already opened.
            if (!ApplicationLog.Ready)
            {
                ApplicationLog.Open("mbf.log");
            }

            // Write to log.
            ApplicationLog.WriteLine(matter);
        }
    }
}
