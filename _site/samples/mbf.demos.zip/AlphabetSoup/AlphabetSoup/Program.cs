﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using MBF;
using MBF.IO.Fasta;
using MBF.IO;

namespace AlphabetSoup
{
    class Program
    {
        static void Main(string[] args)
        {
            CommonSequenceParser cParser = new CommonSequenceParser();
            string sequenceChars = "ACT";
            IAlphabet alphabet = cParser.IdentifyAlphabet(Alphabets.RNA, sequenceChars);
            Console.WriteLine("{0} = {1}", sequenceChars, alphabet.Name);

            FastaParser parser = new FastaParser();
            parser.Alphabet = RnaAlphabet.Instance;
            ISequence sequence = parser.ParseOne(@"c:\users\mark\desktop\test\5S.A.fasta");


            //IList<ISequence> sequences = 
            //    parser.Parse(
            //        @"c:\users\mark\desktop\test\5S.A.fasta");

            //foreach (ISequence sequence in sequences)
            //{
            Console.WriteLine("{0}: {1}", sequence.DisplayID, sequence.Alphabet.Name);
            foreach (ISequenceItem symbol in sequence)
            {
                Console.Write(symbol.Symbol);
            }
            //}
        }

        static void CreateSequence()
        {
            //Sequence sequence =
            ISequence sequence =
                new Sequence(
                    Alphabets.RNA, "ACGU")
                    {
                        IsReadOnly = false
                    };

            //sequence.IsReadOnly = false;
            sequence.RemoveAt(1); // Removes 2nd character

            Console.WriteLine(sequence);
        }

        static void ShowAlphabets()
        {
            //DumpAlphabet(DnaAlphabet.Instance);
            //Console.WriteLine(new string('-', 25));
            //DumpAlphabet(RnaAlphabet.Instance);

            foreach (IAlphabet alphabet in
                Alphabets.All)
            {
                Console.WriteLine(new string('-', 25));
                DumpAlphabet(alphabet);
            }
        }

        private static void DumpAlphabet(IAlphabet alphabet)
        {
            Console.WriteLine(alphabet.Name);

            foreach (ISequenceItem item in alphabet)
            {
                Console.WriteLine(
                    "\t{0}: {1}, IsAmbiguous={2}, " +
                    "IsGap={3}, IsTerminator={4}",
                    item.Name,
                    item.Symbol,
                    item.IsAmbiguous,
                    item.IsGap,
                    item.IsTermination);
            }
        }
    }
}
