﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MBF.IO;
using MBF;

namespace ImageVisualization
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            Loaded += new RoutedEventHandler(MainWindow_Loaded);
            InitializeComponent();
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            string filename = @"5s.a.fasta";

            ISequenceParser parser = SequenceParsers.FindParserByFile(filename);
            if (parser == null)
                return;

            IList<ISequence> sequences = parser.Parse(filename);

            int maxNucleotideCount = sequences.Max(s => s.Count);
            int sequenceCount = sequences.Count;

            WriteableBitmap bitmap = new WriteableBitmap(
                maxNucleotideCount, sequenceCount, 96, 96,
                PixelFormats.Bgra32, null);

            int currentColor = 0;
            Color[] colorsToUse = 
            {
                Colors.Red,
                Colors.Blue,
                Colors.Green,
                Colors.Yellow,
                Colors.ForestGreen,
            };
            Dictionary<ISequenceItem, Color> colorMap = new Dictionary<ISequenceItem, Color>();

            bitmap.Lock();

            for (int row = 0; row < sequenceCount; row++)
            {
                for (int col = 0; col < maxNucleotideCount; col++)
                {
                    ISequenceItem item = sequences[row][col];
                    Color color;
                    if (item.IsGap)
                        color = Colors.White;
                    else
                    {
                        if (!colorMap.TryGetValue(item, out color))
                        {
                            color = colorsToUse[currentColor++ % colorsToUse.Length];
                            colorMap.Add(item, color);
                        }
                    }

                    bitmap.SetPixel(col, row, color);

                }                
            }

            bitmap.Unlock();
            image.Source = bitmap;
        }
    }
}
