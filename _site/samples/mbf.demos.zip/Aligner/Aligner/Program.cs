﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MBF.IO;
using MBF;
using MBF.Algorithms.Alignment;
using MBF.SimilarityMatrices;

namespace Aligner
{
    class Program
    {
        static void Main(string[] args)
        {
            IList<ISequence> sequences = SequenceParsers.Fasta.Parse(@"C:\users\mark\desktop\test\5s.a.fasta");

            ISequence sequence1 = sequences[0];
            ISequence sequence2 = sequences[5];

            var alignmentAlgorithm = new SmithWatermanAligner();

            //alignmentAlgorithm.SimilarityMatrix = new SimilarityMatrix(SimilarityMatrix.StandardSimilarityMatrix.DiagonalScoreMatrix);
            alignmentAlgorithm.GapOpenCost = -8;
            alignmentAlgorithm.GapExtensionCost = -5;
            var alignedSequences = alignmentAlgorithm.Align(sequence1, sequence2);

            Console.WriteLine(sequence1);

            Console.WriteLine(sequence2);

            var pairwiseAlignment = alignedSequences[0].PairwiseAlignedSequences[0];
            Console.WriteLine("Alignment score: {0}", pairwiseAlignment.Score);

            Console.WriteLine(pairwiseAlignment.Consensus);
            
        }
    }
}
