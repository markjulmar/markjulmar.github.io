﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.IO;
using MBF;
using MBF.Web;
using MBF.Web.Blast;

namespace BlastRequest
{
    class BlastRequest
    {
        static void Main(string[] args)
        {
            // [2] Prepare data
            string seq = @"GACGCCGCCGCCACCACCGCCACCGCCGCAGCAGAAGCAGCGCACCGCAGGAGGGAAG" +
                "ATGCCGGCGGGGCACGGGCTGCGGGCGCGGACGGCGACCTCTTCGCGCGGCCGTTCCGCAAGAAGGGTTA" +
                "CATCCCGCTCACCACCTACCTGAGGACGTACAAGATCGGCGATTACGTNGACGTCAAGGTGAACGGTG";
            Sequence sequence = new Sequence(Alphabets.DNA, seq);

            // [3] Create and configure service handler
            EbiWuBlastHandler blastService = new EbiWuBlastHandler();

            ConfigParameters configParams = new ConfigParameters();
            configParams.UseBrowserProxy = true;
            blastService.Configuration = configParams;

            // [4] Define query.
            BlastParameters searchParams = new BlastParameters();
            searchParams.Add("Program", "blastn");

            searchParams.Add("Database", "em_rel");
            searchParams.Add("Expect", "1e-10");
            searchParams.Add("Email", "mark@julmar.com");

            // [5] create and submit request
            string jobID;
            try
            {
                jobID = blastService.SubmitRequest(sequence, searchParams);
            }
            catch
            {
                Console.WriteLine("Service is not available.");
                return;
            }

            // [6] Wait for Ready status
            ServiceRequestInformation info = blastService.GetRequestStatus(jobID);

            if (info.Status != ServiceRequestStatus.Waiting
                   && info.Status != ServiceRequestStatus.Ready)
            {
                Console.WriteLine("Service is not ready or waiting.");
                return;
            }

            int maxAttempts = 10;
            int attempt = 1;
            while (attempt <= maxAttempts
                    && info.Status != ServiceRequestStatus.Error
                    && info.Status != ServiceRequestStatus.Ready)
            {
                ++attempt;
                info = blastService.GetRequestStatus(jobID);
                Thread.Sleep(
                    info.Status == ServiceRequestStatus.Waiting
                    || info.Status == ServiceRequestStatus.Queued
                    ? 20000 * attempt
                    : 0);
            }

            // [7] Get results
            IList<BlastResult> results2 =
                  blastService.FetchResultsSync(jobID, searchParams) as List<BlastResult>;
        }
    }
}
