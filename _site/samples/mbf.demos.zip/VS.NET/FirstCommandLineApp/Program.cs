﻿using System;
using Math;

namespace FirstCommandLineApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello there");
            Calculator calc = new Calculator();

            Console.Write("Please enter the first number: ");
            String input = Console.ReadLine();

            int x;
            if (Int32.TryParse(input, out x))
            {
                Console.WriteLine("Please enter the second number: ");
                input = Console.ReadLine();
                int y = Int32.Parse(input);

                int z = calc.Add(x, y);

                Console.WriteLine("{0} + {1} = {2}", x, y, z);
            }

        }
    }
}
