﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Math
{
    public class Calculator
    {
        public int Add(int x, int y)
        {
            return x + y;
        }
    }
}
