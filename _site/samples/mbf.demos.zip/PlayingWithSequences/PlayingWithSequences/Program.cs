﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MBF.IO;
using MBF;

namespace PlayingWithSequences
{
    class Program
    {
        static void Main(string[] args)
        {
            DumpStats();
            //FindByIndex();
        }

        static void DumpStats()
        {
            IList<ISequence> sequences = SequenceParsers.Fasta.Parse(@"c:\users\mark\desktop\test\5s.a.fasta");

            // Find largest # of items in all sequences
            int maxNucleotideCount = sequences.Min(s => s.Count);
            Console.WriteLine("Min={0}, Max={1}",
                sequences.Min(s => s.Count),
                sequences.Max(s => s.Count));

            IAlphabet alphabet = sequences.First().Alphabet;

            for (int col = 0; col < maxNucleotideCount; col++)
            {
                Sequence newSequence = new Sequence(alphabet, 
                             new string(sequences
                                 .Select(s => s[col].Symbol).ToArray()));
                var mostDominant = alphabet.Select(symbol => 
                    new { Symbol = symbol, 
                          Fraction = newSequence.Statistics.GetFraction(symbol) })
                          .OrderByDescending(t => t.Fraction)
                          .First();

                Console.WriteLine("{0}: {1} = {2:P}", col, mostDominant.Symbol.Symbol, mostDominant.Fraction);
            }
        }

        static void FindByIndex()
        {
            ISequence sequence = SequenceParsers.Fasta.ParseOne(@"c:\users\mark\desktop\test\5s.a.fasta", false);

            int firstNonGap = sequence.IndexOfNonGap();
            int nextGap = sequence.IndexOfGap(firstNonGap);
            Console.WriteLine("First non gap is at: {0}, next gap is at {1}", firstNonGap, nextGap);

            //string symbols = sequence.ToString();
            //Console.WriteLine(symbols.Substring(firstNonGap - 1, 
            //                            nextGap - firstNonGap + 2));

            ISequence subSequence = sequence.Range(firstNonGap, nextGap - firstNonGap);
            Console.WriteLine(subSequence);

            sequence.InsertRange(0, "ACGG--");
            Console.WriteLine(sequence);
        }
    }

    static class SequenceExtensions
    {
        public static int IndexOfGap(this ISequence sequence, int startPos)
        {
            return Enumerable.Range(startPos, (sequence.Count - startPos) - 1)
                .First(i => sequence[i].IsGap);

            //for (int i = startPos; i < sequence.Count; i++)
            //{
            //    if (sequence[i].IsGap)
            //        return i;
            //}

            //return -1;
        }
    }
}
