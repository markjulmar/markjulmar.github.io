﻿using System.Windows;
using JulMar.Windows.UI;

namespace WpfMvvmApplication1.Views
{
    /// <summary>
    /// Interaction logic for ChildWindow.xaml
    /// </summary>
    [ExportUIVisualizer("ChildWindow")]
    public partial class ChildWindow : Window
    {
        public ChildWindow()
        {
            InitializeComponent();
        }
    }
}
