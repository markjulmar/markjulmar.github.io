﻿using JulMar.Windows.Mvvm;
using System.Media;
using System.ComponentModel.Composition;

namespace WpfMvvmApplication1
{
    /// <summary>
    /// Service that plays sounds.
    /// </summary>
    [Export, ExportServiceProvider(typeof(PlaySoundService))]
    public class PlaySoundService
    {
        public void Beep()
        {
            new SoundPlayer(@"./media/ding.wav").Play();
        }
    }
}
