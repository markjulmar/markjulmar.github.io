﻿using System.ComponentModel.Composition;
using JulMar.Windows.Mvvm;
using System.Windows.Input;
using JulMar.Windows.Interfaces;

namespace WpfMvvmApplication1.ViewModels
{
    /// <summary>
    /// This is the main view model - created and associated to the MainView window.
    /// </summary>
    [ExportViewModel("MainWindow")]
    public class MainViewModel : ViewModel
    {
        [Import] private PlaySoundService _playSoundService;

        public ICommand BeepCommand { get; private set; }
        public ICommand ShowChild { get; private set; }

        public MainViewModel()
        {
            BeepCommand = new DelegatingCommand(() => _playSoundService.Beep());
            ShowChild = new DelegatingCommand(() => Resolve<IUIVisualizer>().ShowDialog("ChildWindow"));
        }

    }
}
