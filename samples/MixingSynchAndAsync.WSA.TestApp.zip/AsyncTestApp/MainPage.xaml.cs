﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Windows.Networking;
using Windows.Networking.Sockets;
using Windows.UI.Xaml;

namespace AsyncTestApp
{
    public sealed partial class MainPage
    {
        private readonly IList<string> _log = new ObservableCollection<string>();
        
        public MainPage()
        {
            DataContext = _log;
            this.InitializeComponent();
        }

        private void Log(string data, params object[] args)
        {
            _log.Add(string.Format(data, args));
        }

        private void OnButtonClick(object sender, RoutedEventArgs e)
        {
            Log("Starting test..");

            string result = PleaseWaitForMe();

            Log(result);
        }

        private string PleaseWaitForMe()
        {
            bool available = IsWebsiteAvailable("www.microsoft.com").Result;
            return (available) ? "Online" : "Offline";
        }

        //public async Task<bool> IsWebsiteAvailable(string address)
        //{
        //    using (var tcpClient = new StreamSocket())
        //    {
        //        await tcpClient.ConnectAsync(new HostName(address), "http");
        //        return true;
        //    }
        //}

        public Task<bool> IsWebsiteAvailable(string address)
        {
            return Task.Run(async () =>
            {
                using (var tcpClient = new StreamSocket())
                {
                    await tcpClient.ConnectAsync(new HostName(address), "http");
                    return true;
                }
            });
        }
    }
}
