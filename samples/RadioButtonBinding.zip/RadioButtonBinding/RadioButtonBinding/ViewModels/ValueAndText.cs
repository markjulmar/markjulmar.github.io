﻿namespace RadioButtonBinding.ViewModels
{
    /// <summary>
    /// This class wraps a value and string together.
    /// </summary>
    /// <typeparam name="T">Type of value</typeparam>
    public class ValueAndText<T>
    {
        /// <summary>
        /// Value to bind to
        /// </summary>
        public T Value { get; private set; }

        /// <summary>
        /// Text string to present
        /// </summary>
        public string Text { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="value"></param>
        /// <param name="text"></param>
        public ValueAndText(T value, string text)
        {
            Value = value;
            Text = text;
        }
    }
}