﻿using System;
using JulMar.Windows.Mvvm;

namespace RadioButtonBinding.ViewModels
{
    /// <summary>
    /// Gender flag
    /// </summary>
    public enum Gender
    {
        Male, Female, Unknown
    }

    /// <summary>
    /// Game types
    /// </summary>
    public enum GameType
    {
        Webkinz,
        Playdoh,
        PbsKids,
        Wii
    }

    /// <summary>
    /// ViewModel to represent a single child.
    /// </summary>
    public class ChildViewModel : SimpleViewModel
    {
        #region Private Data
        private string _name;
        private Gender _gender;
        private DateTime _dob;
        private GameType _favoriteGame;
        #endregion

        /// <summary>
        /// Name
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; OnPropertyChanged("Name", "Details"); }
        }

        /// <summary>
        /// Gender of child
        /// </summary>
        public Gender Gender
        {
            get { return _gender; }
            set { _gender = value; OnPropertyChanged("Gender", "Details"); }
        }

        /// <summary>
        /// Date of birth
        /// </summary>
        public DateTime Dob
        {
            get { return _dob; }
            set { _dob = value; OnPropertyChanged("Dob", "Details"); }
        }

        /// <summary>
        /// Game they like to play
        /// </summary>
        public GameType FavoriteGame
        {
            get { return _favoriteGame; }
            set { _favoriteGame = value; OnPropertyChanged("FavoriteGame", "Details"); }
        }

        /// <summary>
        /// Returns textual representation of child.
        /// </summary>
        /// <returns></returns>
        public string Details
        {
            get
            {
                return string.Format("{0} is a {1}, was born on {2:D} and loves to play {3}", 
                    Name, Gender, Dob,FavoriteGame);
            }
        }
    }
}