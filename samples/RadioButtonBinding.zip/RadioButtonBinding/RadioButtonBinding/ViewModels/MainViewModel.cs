﻿using System;
using System.Collections.Generic;
using JulMar.Windows.Mvvm;

namespace RadioButtonBinding.ViewModels
{
    /// <summary>
    /// Main View Model that connects it all together.
    /// </summary>
    public class MainViewModel : SimpleViewModel
    {
        /// <summary>
        /// Gets the gender values
        /// </summary>
        public IEnumerable<ValueAndText<Gender>> GenderValues
        {
            get
            {
                yield return new ValueAndText<Gender>(Gender.Male, "Boy");
                yield return new ValueAndText<Gender>(Gender.Female, "Girl");
            }
        }

        /// <summary>
        /// Gets the game types
        /// </summary>
        public IEnumerable<ValueAndText<GameType>> GameTypes
        {
            get
            {
                yield return new ValueAndText<GameType>(GameType.Webkinz, "WebKinz (http://www.webkinz.com)");
                yield return new ValueAndText<GameType>(GameType.Playdoh, "Loves Playdoh");
                yield return new ValueAndText<GameType>(GameType.PbsKids, "PBS Kids (http://www.pbskids.com)");
                yield return new ValueAndText<GameType>(GameType.Wii, "Wii and other console");
            }
        }

        /// <summary>
        /// Collection of children
        /// </summary>
        public IList<ChildViewModel> Children { get; private set; }

        private ChildViewModel _currentChild;

        /// <summary>
        /// The current (and only for now) child
        /// </summary>
        public ChildViewModel CurrentChild
        {
            get { return _currentChild; }
            set
            {
                if (_currentChild != value)
                {
                    _currentChild = value;
                    OnPropertyChanged("CurrentChild");
                }
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public MainViewModel()
        {
            // Fill with sample data.
            Children = new List<ChildViewModel>
               {
                   new ChildViewModel
                   {
                       Name = "Jonathan",
                       Dob = new DateTime(2006, 3, 14),
                       FavoriteGame = GameType.PbsKids,
                       Gender = Gender.Male
                   },
                   new ChildViewModel
                   {
                       Name = "Amanda",
                       Dob = new DateTime(1999, 9, 8),
                       FavoriteGame = GameType.Wii,
                       Gender = Gender.Female
                   },
                   new ChildViewModel
                   {
                       Name = "Cassidy",
                       Dob = new DateTime(2004, 1, 14),
                       FavoriteGame = GameType.Wii,
                       Gender = Gender.Female
                   },
                   new ChildViewModel
                   {
                       Name = "Jack",
                       Dob = new DateTime(2001, 10, 24),
                       FavoriteGame = GameType.Playdoh,
                       Gender = Gender.Male
                   },
               };

            // Set the first child as selected.
            CurrentChild = Children[0];
        }
    }
}
