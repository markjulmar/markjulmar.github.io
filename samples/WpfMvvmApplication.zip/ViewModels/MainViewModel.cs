﻿using JulMar.Windows.Mvvm;
using System.Windows.Input;
using JulMar.Windows.Interfaces;
using System.IO;

namespace $safeprojectname$.ViewModels
{
    /// <summary>
    /// This is the main view model - created and associated to the MainView window.
    /// </summary>
    public class MainViewModel : ViewModel
    {
        #region Internal Data
        private DirectoryViewModel _selectedDirectory;
        #endregion

        /// <summary>
        /// Root directory - can be bound to an ItemsControl on the UI.
        /// </summary>
        public DirectoryViewModel[] RootDirectory { get; private set; }

        /// <summary>
        /// Selected (active) directory
        /// </summary>
        public DirectoryViewModel SelectedDirectory
        {
            get { return _selectedDirectory; }
            set { _selectedDirectory = value; OnPropertyChanged("SelectedDirectory"); }
        }

        /// <summary>
        /// Command to display the About Box.
        /// </summary>
        public ICommand DisplayAboutCommand { get; private set; }

        /// <summary>
        /// Command to end the application
        /// </summary>
        public ICommand CloseAppCommand { get; private set; }

        /// <summary>
        /// Main constructor
        /// </summary>
        public MainViewModel()
        {
            // Register this instance with the message mediator so it can receive
            // messages from other views/viewmodels.
            RegisterWithMessageMediator();

            // Create our commands
            DisplayAboutCommand = new DelegatingCommand(OnShowAbout);
            CloseAppCommand = new DelegatingCommand(OnCloseApp);

            // Fill in the root directory from C:
            RootDirectory = new[] { new DirectoryViewModel(new DirectoryInfo(@"C:\")) { IsSelected = true } };
        }

        /// <summary>
        /// This method closes the application window.
        /// </summary>
        private void OnCloseApp()
        {
            // Ask the view to close.
            RaiseCloseRequest();
        }

        /// <summary>
        /// This method displays the About Box.
        /// </summary>
        private void OnShowAbout()
        {
            // Get the message visualizer service from the service resolver.
            // All services can be replaced, so make sure to check if we have something
            // registered.
            IMessageVisualizer messageVisualizer = Resolve<IMessageVisualizer>();
            if (messageVisualizer != null)
            {
                // Show a message box.
                messageVisualizer.Show("About File Explorer Sample", "File Explorer Sample 1.0", MessageButtons.OK);
            }
        }

        /// <summary>
        /// This method is invoked by the message mediator when a DirectoryViewModel is selected.
        /// </summary>
        /// <param name="newDirectory">DirectoryViewModel that is now active</param>
        [MessageMediatorTarget(DirectoryViewModel.SelectedDirectoryChangedMessage)]
        private void OnCurrentDirectoryChanged(DirectoryViewModel newDirectory)
        {
            SelectedDirectory = newDirectory;   
        }
    }
}
