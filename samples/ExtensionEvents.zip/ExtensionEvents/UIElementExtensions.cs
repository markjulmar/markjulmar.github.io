﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Linq;

namespace ExtensionEvents
{
    internal static class UIElementExtensions
    {
        public static IObservable<Event<MouseButtonEventArgs>> GetMouseLeftButtonDown(this UIElement that)
        {
            return Observable.FromEvent<MouseButtonEventArgs>(that, "MouseLeftButtonDown");
        }

        public static IObservable<Event<MouseButtonEventArgs>> GetMouseLeftButtonUp(this UIElement that)
        {
            return Observable.FromEvent<MouseButtonEventArgs>(that, "MouseLeftButtonUp");
        }

        public static IObservable<Event<MouseEventArgs>> GetMouseLeave(this UIElement that)
        {
            return Observable.FromEvent<MouseEventArgs>(that, "MouseLeave");
        }

        public static IObservable<Event<MouseEventArgs>> GetMouseEnter(this UIElement that)
        {
            return Observable.FromEvent<MouseEventArgs>(that, "MouseEnter");
        }

        public static IObservable<Event<MouseButtonEventArgs>> GetClick(this UIElement that)
        {
            return
                that
                // wait for any mouse left down event
                    .GetMouseLeftButtonDown()
                    .SelectMany(
                        mouseLeftButtonDownEvent =>
                            // then wait for a single mouse left up event
                            that
                                .GetMouseLeftButtonUp()
                                .Take(1)
                                .Until(
                            // We want to merge two different stop conditions...
                                    Observable.Merge(
                            // stop listening if the mouse goes outside
                            // the window
                                        Application.Current.MainWindow.GetMouseLeave()
                            // We return unit so that we have the
                            // same type as the other observable
                            // we want to merge with
                                            .Select(_ => new Unit()),
                                        that
                                            .GetMouseLeave()
                                            .SelectMany(
                                                mouseLeaveEvent =>
                                                    // stop waiting for a mouse left up event
                                                    // if the mouse leaves the element and the
                                                    // button is released.
                                                    // By listening for the event at the Root
                                                    // Visual we ensure that we will get all
                                                    // MouseLeftButtonUp events because this
                                                    // event bubbles up.
                                                    Application.Current.MainWindow
                                                        .GetMouseLeftButtonUp()
                                                        .Take(1)
                                                    // Return unit so that we can merge
                                                        .Select(_ => new Unit())
                                                    // don't cancel if the mouse enters
                                                    // the element over which the mouse
                                                    // was depressed.
                                                        .Until(that.GetMouseEnter())))));
        }
    }
}
