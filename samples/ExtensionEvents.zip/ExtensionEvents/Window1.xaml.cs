﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;

namespace ExtensionEvents.Wpf
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1
    {
        public Window1()
        {
            InitializeComponent();

            rect.GetMouseEnter().Subscribe(() => rect.Fill = Brushes.Blue);
            rect.GetMouseLeave().Subscribe(() => rect.Fill = Brushes.Red);
            rect.GetClick().Subscribe(() => MessageBox.Show("The Rectangle was clicked!"));
        }
    }
}
