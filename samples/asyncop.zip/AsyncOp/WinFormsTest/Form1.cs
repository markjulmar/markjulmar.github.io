using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace WinFormsTest
{
    public partial class CalcPiTestForm : Form
    {
        ArrayList _pendingTasks = new ArrayList();

        public CalcPiTestForm()
        {
            InitializeComponent();
        }

        private void CalcPiTestForm_Load(object sender, EventArgs e)
        {
            piCalculator1.CalculationComplete += new UserMath.PiCalculationCompletedEventHandler(piCalculator1_CalculationComplete);
        }

        void piCalculator1_CalculationComplete(object sender, UserMath.PiCalculationEventArgs e)
        {
            lock(_pendingTasks)
            {
                _pendingTasks.Remove(e.TaskId);
            }

            // No need to do BeginInvoke here..
            listBox1.Items.Add(string.Format("[{0}] {1} = {2}, Canceled = {3}",
                System.Threading.Thread.CurrentThread.ManagedThreadId, e.Digits, e.Result, e.Canceled));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (maskedTextBox1.Text.Length > 0)
            {
                lock(_pendingTasks)
                    _pendingTasks.Add(piCalculator1.CalculatePi(Convert.ToInt32(maskedTextBox1.Text)));
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lock(_pendingTasks)
            {
                foreach (object task in _pendingTasks)
                    piCalculator1.CancelAsync(task);
            }
        }
    }
}