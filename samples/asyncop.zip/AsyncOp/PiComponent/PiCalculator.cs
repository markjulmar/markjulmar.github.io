using System;
using System.Collections.Generic;
using System.Threading;
using System.ComponentModel;

namespace UserMath
{
    public class PiCalculator : Component
    {
        class AsyncStateData 
        {
            public AsyncOperation asyncOperation;
            public volatile bool canceled = false;
            public volatile bool running = true;
            public AsyncStateData(object stateData) 
            { 
                asyncOperation = AsyncOperationManager.CreateOperation(stateData);  
            }
        };

        private SendOrPostCallback completionMethodDelegate;
        public event PiCalculationCompletedEventHandler CalculationComplete;

        public PiCalculator()
        {
            completionMethodDelegate = delegate(object evt)
            {
                // Called on the synchronization thread.
                if (CalculationComplete != null)
                    CalculationComplete(this, (PiCalculationEventArgs)evt);
            };
        }

        public object CalculatePi(int digits)
        {
            return CalculatePi(digits, null);
        }

        public object CalculatePi(int digits, object stateData)
        {
            PiDelegate piDel = InternalCalculatePi;
            AsyncStateData asyncData = new AsyncStateData(stateData);
            piDel.BeginInvoke(digits, asyncData, delegate(IAsyncResult ar) { piDel.EndInvoke(ar); }, null);
            return asyncData;
        }

        public void CancelAsync(object asyncTask)
        {
            AsyncStateData asyncData = asyncTask as AsyncStateData;
            if (asyncData != null && asyncData.running == true)
                asyncData.canceled = true;
        }

        private delegate void PiDelegate(int digits, AsyncStateData asyncData);
        private void InternalCalculatePi(int digits, AsyncStateData asyncData)
        {
            string PI_DIGITS = "3.141592637309238932482438234724782347234";
            if (digits > PI_DIGITS.Length - 2)
                digits = PI_DIGITS.Length - 2;

            // This would be a real calculator here..
            int completedDigits = 0;
            for (; !asyncData.canceled && completedDigits < digits; completedDigits++)
            {
                Thread.Sleep(1000);
            }

            asyncData.running = false;
            string data = PI_DIGITS.Substring(0, completedDigits + 2);
            asyncData.asyncOperation.PostOperationCompleted(
                    completionMethodDelegate,
                    new PiCalculationEventArgs(asyncData, digits, data, asyncData.asyncOperation.UserSuppliedState, asyncData.canceled));
        }
    }

    // Stupid designer -- requires Component be first class.
    public delegate void PiCalculationCompletedEventHandler(object sender, PiCalculationEventArgs e);

    public class PiCalculationEventArgs : EventArgs
    {
        private int _digits;
        private string _value;
        private bool _canceled;
        private object _stateData;
        private object _taskId;

        public object TaskId
        {
            get { return _taskId; }
            set { _taskId = value; }
        }

        public object State
        {
            get { return _stateData; }
            set { _stateData = value; }
        }

        public bool Canceled
        {
            get { return _canceled; }
            set { _canceled = value; }
        }

        public int Digits
        {
            get { return _digits; }
            set { _digits = value; }
        }

        public string Result
        {
            get { return _value; }
            set { _value = value; }
        }

        internal PiCalculationEventArgs(object taskId, int digits, string value, object stateData, bool canceled)
        {
            _digits = digits;
            _value = value;
            _canceled = canceled;
            _stateData = stateData;
            _taskId = taskId;
        }
    }
}