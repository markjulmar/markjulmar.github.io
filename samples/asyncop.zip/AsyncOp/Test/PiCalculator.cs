using System;
using System.Collections.Generic;
using System.Threading;
using System.ComponentModel;

namespace UserMath
{
    public delegate void PiCalculationCompletedEventHandler(object sender, PiCalculationEventArgs e);

    public class PiCalculationEventArgs : EventArgs
    {
        private int _digits;
        private string _value;
        private bool _canceled;
        private object _stateData;

        public object State
        {
            get { return _stateData; }
            set { _stateData = value; }
        }

        public bool Canceled
        {
            get { return _canceled; }
            set { _canceled = value; }
        }

        public int Digits
        {
            get { return _digits; }
            set { _digits = value; }
        }

        public string Result
        {
            get { return _value; }
            set { _value = value; }
        }

        public PiCalculationEventArgs(int digits, string value, object stateData, bool canceled)
        {
            _digits = digits;
            _value = value;
            _canceled = canceled;
            _stateData = stateData;
        }
    };

    public class PiCalculator : Component
    {
        private Dictionary<object, AsyncOperation> _pendingRequests = new Dictionary<object, AsyncOperation>();
        private SendOrPostCallback completionMethodDelegate;
        public event PiCalculationCompletedEventHandler CalculationComplete;

        public PiCalculator()
        {
            completionMethodDelegate = delegate(object evt)
            {
                // Called on the synchronization thread.
                if (CalculationComplete != null)
                    CalculationComplete(this, (PiCalculationEventArgs)evt);
            };
        }

        public void CalculatePi(int digits, object stateData)
        {
            if (stateData == null)
                throw new ArgumentNullException("stateData");

            PiDelegate piDel = InternalCalculatePi;
            AsyncOperation asyncOp = AsyncOperationManager.CreateOperation(stateData);

            lock (_pendingRequests)
            {
                if (_pendingRequests.ContainsKey(stateData))
                    throw new ArgumentException("stateData must be unique");
                _pendingRequests[stateData] = asyncOp;
            }

            piDel.BeginInvoke(digits, asyncOp, delegate(IAsyncResult ar) { piDel.EndInvoke(ar); }, null);
        }

        public void CancelAsync(object stateData)
        {
            lock (_pendingRequests)
            {
                if (_pendingRequests.ContainsKey(stateData))
                {
                    AsyncOperation asyncOp = _pendingRequests[stateData];
                    _pendingRequests.Remove(stateData);
                    asyncOp.PostOperationCompleted(completionMethodDelegate,
                            new PiCalculationEventArgs(0, string.Empty, stateData, true));
                }
            }
        }

        private delegate void PiDelegate(int digits, AsyncOperation asyncOp);
        private void InternalCalculatePi(int digits, AsyncOperation asyncOp)
        {
            string PI_DIGITS = "3.141592637309238932482438234724782347234";
            if (digits > PI_DIGITS.Length - 2)
                digits = PI_DIGITS.Length - 2;

            // Could check here for cancelation (i.e. request not in _pendingRequests anymore).
            Thread.Sleep(digits * 1000);

            string data = null;
            lock (_pendingRequests)
            {
                if (_pendingRequests.Remove(asyncOp.UserSuppliedState))
                {
                    data = PI_DIGITS.Substring(0, digits + 2);
                }
            }

            if (data != null)
            {
                asyncOp.PostOperationCompleted(completionMethodDelegate,
                    new PiCalculationEventArgs(digits, data, asyncOp.UserSuppliedState, false));
            }
        }
    }
}