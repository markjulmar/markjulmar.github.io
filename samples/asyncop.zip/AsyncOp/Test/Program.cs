using System;
using System.Collections.Generic;
using System.Text;
using UserMath;
using System.Threading;
using System.Collections;

class Program
{
    static void Main(string[] args)
    {
        ArrayList taskIds = new ArrayList();
        PiCalculator piCalc = new PiCalculator();
        piCalc.CalculationComplete += new PiCalculationCompletedEventHandler(piCalc_CalculationComplete);

        foreach (string s in args)
        {
            taskIds.Add(piCalc.CalculatePi(Convert.ToInt32(s), s));
        }

        Console.WriteLine("Waiting for results .. press ENTER to cancel.");
        Console.ReadLine();

        foreach (object task in taskIds)
        {
            piCalc.CancelAsync(task);
        }

        Console.WriteLine("Press ENTER to terminate");
        Console.ReadLine();
    }

    static void piCalc_CalculationComplete(object sender, PiCalculationEventArgs e)
    {
        Console.WriteLine("[{0}] {1} = {2}, Canceled = {3}", 
            Thread.CurrentThread.ManagedThreadId, e.Digits, e.Result, e.Canceled);
    }
};