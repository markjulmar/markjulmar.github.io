﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;

namespace Windows7.Interop
{
    [Serializable, StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct WIN32_FIND_DATAW
    {
        public uint dwFileAttributes;
        public System.Runtime.InteropServices.ComTypes.FILETIME ftCreationTime;
        public System.Runtime.InteropServices.ComTypes.FILETIME ftLastAccessTime;
        public System.Runtime.InteropServices.ComTypes.FILETIME ftLastWriteTime;
        public uint nFileSizeHigh;
        public uint nFileSizeLow;
        public uint dwReserved0;
        public uint dwReserved1;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string cFileName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)] public string cAlternateFileName;
    }

    /// <summary>
    /// IShellLink.GetPath fFlags: Flags that specify the type of path information to retrieve
    /// </summary>
    [Serializable, Flags]
    public enum SLGP_FLAGS
    {
        /// <summary>
        /// Retrieves the standard short (8.3 format) file name
        /// </summary>
        SLGP_SHORTPATH = 0x1,
        /// <summary>
        /// Retrieves the Universal Naming Convention (UNC) path name of the file
        /// </summary>
        SLGP_UNCPRIORITY = 0x2,
        /// <summary>
        /// Retrieves the raw path name. A raw path is something that might not exist and may include environment variables that need to be expanded
        /// </summary>
        SLGP_RAWPATH = 0x4
    }

    /// <summary>
    /// IShellLink.Resolve fFlags
    /// </summary>
    [Serializable, Flags]
    public enum SLR_FLAGS
    {
        /// <summary>
        /// Do not display a dialog box if the link cannot be resolved. When SLR_NO_UI is set,
        /// the high-order word of fFlags can be set to a time-out value that specifies the 
        /// maximum amount of time to be spent resolving the link. The function returns if the
        /// link cannot be resolved within the time-out duration. If the high-order word is set
        /// to zero, the time-out duration will be set to the default value of 3,000 milliseconds
        /// (3 seconds). To specify a value, set the high word of fFlags to the desired time-out
        /// duration, in milliseconds.
        /// </summary>
        SLR_NO_UI = 0x1,
        /// <summary>Obsolete and no longer used</summary>
        SLR_ANY_MATCH = 0x2,
        /// <summary>If the link object has changed, update its path and list of identifiers. 
        /// If SLR_UPDATE is set, you do not need to call IPersistFile::IsDirty to determine 
        /// whether or not the link object has changed.</summary>
        SLR_UPDATE = 0x4,
        /// <summary>Do not update the link information</summary>
        SLR_NOUPDATE = 0x8,
        /// <summary>Do not execute the search heuristics</summary>
        SLR_NOSEARCH = 0x10,
        /// <summary>Do not use distributed link tracking</summary>
        SLR_NOTRACK = 0x20,
        /// <summary>Disable distributed link tracking. By default, distributed link tracking tracks
        /// removable media across multiple devices based on the volume name. It also uses the
        /// Universal Naming Convention (UNC) path to track remote file systems whose drive letter
        /// has changed. Setting SLR_NOLINKINFO disables both types of tracking.</summary>
        SLR_NOLINKINFO = 0x40,
        /// <summary>Call the Microsoft Windows Installer</summary>
        SLR_INVOKE_MSI = 0x80
    }

    [Serializable]
    public enum SIGDN : uint
    {	
        SIGDN_NORMALDISPLAY	= 0,
	    SIGDN_PARENTRELATIVEPARSING	= 0x80018001,
	    SIGDN_DESKTOPABSOLUTEPARSING = 0x80028000,
	    SIGDN_PARENTRELATIVEEDITING	= 0x80031001,
	    SIGDN_DESKTOPABSOLUTEEDITING = 0x8004c000,
	    SIGDN_FILESYSPATH = 0x80058000,
	    SIGDN_URL = 0x80068000,
	    SIGDN_PARENTRELATIVEFORADDRESSBAR = 0x8007c001,
	    SIGDN_PARENTRELATIVE = 0x80080001
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("43826d1e-e718-42ee-bc55-a1e261c37bfe")]
    public interface IShellItem
    {
        void BindToHandler(IntPtr pbc, Guid bhid, Guid riid, [Out, MarshalAs(UnmanagedType.Interface)] out object ppv);
        void GetParent([Out, MarshalAs(UnmanagedType.Interface)] out IShellItem ppsi);
        void GetDisplayName([MarshalAs(UnmanagedType.U4)] SIGDN sigdnName, out IntPtr ppszName);
        void GetAttributes(uint sfgaoMask, out uint psfgaoAttribs);
        void Compare([MarshalAs(UnmanagedType.Interface)] IShellItem psi, uint hint, out int piOrder);
    };

    /// <summary>
    /// The IShellLink interface allows Shell links to be created, modified, and resolved
    /// </summary>
    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("000214F9-0000-0000-C000-000000000046")]
    public interface IShellLinkW
    {
        /// <summary>Retrieves the path and file name of a Shell link object</summary>
        void GetPath([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszFile, int cchMaxPath, out WIN32_FIND_DATAW pfd, SLGP_FLAGS fFlags);
        /// <summary>Retrieves the list of item identifiers for a Shell link object</summary>
        void GetIDList(out IntPtr ppidl);
        /// <summary>Sets the pointer to an item identifier list (PIDL) for a Shell link object.</summary>
        void SetIDList(IntPtr pidl);
        /// <summary>Retrieves the description string for a Shell link object</summary>
        void GetDescription([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszName, int cchMaxName);
        /// <summary>Sets the description for a Shell link object. The description can be any application-defined string</summary>
        void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string pszName);
        /// <summary>Retrieves the name of the working directory for a Shell link object</summary>
        void GetWorkingDirectory([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszDir, int cchMaxPath);
        /// <summary>Sets the name of the working directory for a Shell link object</summary>
        void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string pszDir);
        /// <summary>Retrieves the command-line arguments associated with a Shell link object</summary>
        void GetArguments([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszArgs, int cchMaxPath);
        /// <summary>Sets the command-line arguments for a Shell link object</summary>
        void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string pszArgs);
        /// <summary>Retrieves the hot key for a Shell link object</summary>
        void GetHotkey(out short pwHotkey);
        /// <summary>Sets a hot key for a Shell link object</summary>
        void SetHotkey(short wHotkey);
        /// <summary>Retrieves the show command for a Shell link object</summary>
        void GetShowCmd(out int piShowCmd);
        /// <summary>Sets the show command for a Shell link object. The show command sets the initial show state of the window.</summary>
        void SetShowCmd(int iShowCmd);
        /// <summary>Retrieves the location (path and index) of the icon for a Shell link object</summary>
        void GetIconLocation([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszIconPath,
            int cchIconPath, out int piIcon);
        /// <summary>Sets the location (path and index) of the icon for a Shell link object</summary>
        void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string pszIconPath, int iIcon);
        /// <summary>Sets the relative path to the Shell link object</summary>
        void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string pszPathRel, int dwReserved);
        /// <summary>Attempts to find the target of a Shell link, even if it has been moved or renamed</summary>
        void Resolve(IntPtr hwnd, SLR_FLAGS fFlags);
        /// <summary>Sets the path and file name of a Shell link object</summary>
        void SetPath([MarshalAs(UnmanagedType.LPWStr)] string pszFile);
    }

    [Guid("00021401-0000-0000-C000-000000000046")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComImport]
    public class ShellLink
    {
    }

    [ComImport]
    [Guid("92CA9DCD-5622-4bba-A805-5E9F541BD8C9")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IObjectArray
    {
        void GetCount(out uint cObjects);
        void GetAt(uint iIndex, ref Guid rrid, [Out, MarshalAs(UnmanagedType.Interface)] out object ppvObject);
    }

    [ComImport]
    [Guid("5632b1a4-e38a-400a-928a-d4cd63230295")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IObjectCollection
    {
        // IObjectArray
        void GetCount(out uint cObjects);
        void GetAt(uint iIndex, ref Guid rrid, [Out, MarshalAs(UnmanagedType.Interface)] out object ppvObject);
        //IObjectCollection
        void AddObject([MarshalAs(UnmanagedType.Interface)] object pvObject);
        void AddFromArray([MarshalAs(UnmanagedType.Interface)] IObjectArray poaSource);
        void RemoveObject(uint uiIndex);
        void Clear();
    }

    [Serializable, StructLayout(LayoutKind.Sequential,Pack=4)]
    public struct PROPERTYKEY
    {
        // Define common property keys from propkey.h
        public static PROPERTYKEY PKEY_Title = new PROPERTYKEY { fmtid = new Guid("F29F85E0-4FF9-1068-AB91-08002B27B3D9"), pid = 2 };
        public static PROPERTYKEY PKEY_AppUserModel_ID = new PROPERTYKEY { fmtid = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"), pid = 5 };
        public static PROPERTYKEY PKEY_AppUserModel_IsDestListSeparator = new PROPERTYKEY { fmtid = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"), pid = 6 };
        public static PROPERTYKEY PKEY_AppUserModel_RelaunchCommand = new PROPERTYKEY { fmtid = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"), pid = 2 };
        public static PROPERTYKEY PKEY_AppUserModel_RelaunchDisplayNameResource = new PROPERTYKEY { fmtid = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"), pid = 4 };
        public static PROPERTYKEY PKEY_AppUserModel_RelaunchIconResource = new PROPERTYKEY { fmtid = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"), pid = 3 };

        public Guid fmtid;
        public uint pid;
    }

    [Serializable, StructLayout(LayoutKind.Explicit)]
    public struct CALPWSTR
    {
        [FieldOffset(0)] public uint cElems;
        [FieldOffset(4)] public IntPtr pElems;
    }

    [Serializable, StructLayout(LayoutKind.Explicit, Pack=4)]
    public struct PROPVARIANT
    {
        [FieldOffset(0)]
        private ushort vt;
        [FieldOffset(8)]
        private IntPtr pointerValue;
        [FieldOffset(8)]
        private byte byteValue;
        [FieldOffset(8)]
        private long longValue;
        [FieldOffset(8)]
        private int intValue;
        [FieldOffset(8)]
        private double dblValue;
        [FieldOffset(8)] 
        private float fltValue;
        [FieldOffset(8), MarshalAs(UnmanagedType.Struct)]
        private CALPWSTR calpwstr;

        [DllImport("ole32.dll")]
        private static extern int PropVariantClear(ref PROPVARIANT pvar);

        public VarEnum VarType
        {
            get { return (VarEnum)vt; }
        }

        public void Clear()
        {
            PropVariantClear(ref this);
        }

        public void SetValue(string val)
        {
            Clear();
            vt = (ushort)VarEnum.VT_LPWSTR;
            pointerValue = Marshal.StringToCoTaskMemUni(val);
        }

        public void SetValue(int val)
        {
            Clear();
            vt = (ushort)VarEnum.VT_I4;
            intValue = val;
        }

        public void SetValue(long val)
        {
            Clear();
            vt = (ushort)VarEnum.VT_I8;
            longValue = val;
        }

        public void SetValue(double val)
        {
            Clear();
            vt = (ushort)VarEnum.VT_R8;
            dblValue = val;
        }

        public void SetValue(float val)
        {
            Clear();
            vt = (ushort)VarEnum.VT_R4;
            fltValue = val;
        }

        public void SetValue(byte val)
        {
            Clear();
            vt = (ushort)VarEnum.VT_I1;
            byteValue = val;
        }

        public int AsInt32() { return intValue; }
        public byte AsByte() { return byteValue; }
        public long AsInt64() { return longValue; }
        public double AsDouble() { return dblValue; }

        public string AsString()
        {
            if (vt == ((uint)VarEnum.VT_LPWSTR | (uint)VarEnum.VT_VECTOR))
                return Marshal.PtrToStringUni(calpwstr.pElems, (int) calpwstr.cElems);

            switch ((VarEnum)vt)
            {
                case VarEnum.VT_LPWSTR:
                    return Marshal.PtrToStringUni(pointerValue);
                case VarEnum.VT_LPSTR:
                    return Marshal.PtrToStringAnsi(pointerValue);
                case VarEnum.VT_BSTR:
                    return Marshal.PtrToStringBSTR(pointerValue);
                default:
                    return String.Empty;
            }
        }
        public IntPtr AsIntPtr() { return pointerValue; }
        public float AsFloat() { return fltValue; }

        public object Value
        {
            get
            {
                switch ((VarEnum) vt)
                {
                    case VarEnum.VT_UI1:
                    case VarEnum.VT_UI2:
                    case VarEnum.VT_UI4:
                    case VarEnum.VT_I1:
                    case VarEnum.VT_I2:
                    case VarEnum.VT_I4:
                        return AsInt32();
                    case VarEnum.VT_UI8:
                    case VarEnum.VT_I8:
                        return AsInt64();
                    case VarEnum.VT_BSTR:
                    case VarEnum.VT_LPSTR:
                    case VarEnum.VT_LPWSTR:
                        return AsString();
                    case VarEnum.VT_CY:
                    case VarEnum.VT_R8:
                        return AsDouble();
                    case VarEnum.VT_R4:
                        return AsFloat();
                    default:
                        return AsIntPtr();
                }
            }
        }
    }

    [ComImport]
    [Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IPropertyStore
    {
        void GetCount(out uint cProps);
        void GetAt(uint iProp, out PROPERTYKEY pkey);
        void GetValue(ref PROPERTYKEY key, out PROPVARIANT pv);
        void SetValue(ref PROPERTYKEY key, ref PROPVARIANT pv);
        void Commit();
    }

    [ComImport]
    [ClassInterface(ClassInterfaceType.None)]
    [Guid("2d3468c1-36a7-43b6-ac24-d3f02fd9607a")]
    public class EnumerableObjectCollection
    {
    }

    [Serializable]
    public enum KNOWNDESTCATEGORY
    {
        KDC_FREQUENT = 1,
        KDC_RECENT
    }

    [ComImport]
    [Guid("6332debf-87b5-4670-90c0-5e57b408a49e")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface ICustomDestinationList
    {
        void SetAppID([MarshalAs(UnmanagedType.LPWStr)] string pszAppID);
        void BeginList(out uint cMaxSlots, ref Guid riid, [Out, MarshalAs(UnmanagedType.Interface)] out object ppvObject);
        void AppendCategory([MarshalAs(UnmanagedType.LPWStr)] string pszCategory, [MarshalAs(UnmanagedType.Interface)] IObjectCollection poc);
        void AppendKnownCategory([MarshalAs(UnmanagedType.I4)] KNOWNDESTCATEGORY category);
        void AddUserTasks([MarshalAs(UnmanagedType.Interface)] IObjectCollection poc);
        void CommitList();
        void GetRemovedDestinations(ref Guid riid, [Out, MarshalAs(UnmanagedType.Interface)] out object ppvObject);
        void DeleteList([MarshalAs(UnmanagedType.LPWStr)] string pszAppID);
        void AbortList();
    }

    [ComImport]
    [ClassInterface(ClassInterfaceType.None)]
    [Guid("77f10cf0-3db5-4966-b520-b7c54fd35ed6")]
    public class DestinationList
    {
    }

    [ComImport]
    [Guid("12337d35-94c6-48a0-bce7-6a9c69d4d600")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IApplicationDestinations
    {
        // Set the App User Model ID for the application removing destinations from its list.  If an AppID is not provided 
        // via this method, the system will use a heuristically determined ID.  This method must be called before
        // RemoveDestination or RemoveAllDestinations.
        void SetAppID([MarshalAs(UnmanagedType.LPWStr)] string pszAppID);
        // Remove an IShellItem or an IShellLink from the automatic destination list
        void RemoveDestination([MarshalAs(UnmanagedType.Interface)] object pvObject);
        // Clear the frequent and recent destination lists for this application.
        void RemoveAllDestinations();
    }

    [ComImport]
    [Guid("86c14003-4d6b-4ef3-a7b4-0506663b2e68")]
    [ClassInterface(ClassInterfaceType.None)]
    public class ApplicationDestinations
    {
    }

    [Serializable]
    public enum APPDOCLISTTYPE
    {
        ADLT_RECENT = 0,
        ADLT_FREQUENT
    }

    [ComImport]
    [Guid("3c594f9f-9f30-47a1-979a-c9e83d3d0a06")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IApplicationDocumentLists
    {
        // Set the App User Model ID for the application retrieving this list.  If an AppID is not provided via this method,
        // the system will use a heuristically determined ID.  This method must be called before GetList.
        void SetAppID([MarshalAs(UnmanagedType.LPWStr)] string pszAppID);
        // Retrieve an IEnumObjects or IObjectArray for IShellItems and/or IShellLinks. 
        // Items may appear in both the frequent and recent lists. 
        void GetList([MarshalAs(UnmanagedType.I4)] APPDOCLISTTYPE listtype, 
            uint cItemsDesired, ref Guid riid, [Out, MarshalAs(UnmanagedType.Interface)] out object ppvObject);
    }

    [ComImport]
    [Guid("86bec222-30f2-47e0-9f25-60d11cd75c28")]
    [ClassInterface(ClassInterfaceType.None)]
    public class ApplicationDocumentLists
    {
    }

    [Serializable, StructLayout(LayoutKind.Sequential, Pack=4)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    // Flags for Setting Taskbar Progress state
    [Serializable, Flags]
    public enum TBPFLAG
    {
        TBPF_NOPROGRESS = 0x00000000,
        TBPF_INDETERMINATE = 0x00000001,
        TBPF_NORMAL = 0x00000002,
        TBPF_ERROR = 0x00000004,
        TBPF_PAUSED = 0x00000008,
    }

    // Flags for SetTabActive
    [Serializable, Flags]
    public enum TBATFLAG
    {
        TBATF_USEMDITHUMBNAIL   = 0x00000001,
        TBATF_USEMDILIVEPREVIEW = 0x00000002,
    }

    [Serializable, Flags]
    public enum THBFLAGS
    {
        THBF_ENABLED = 0x0,
        THBF_DISABLED = 0x01,
        THBF_DISMISSONCLICK = 0x02,
        THBF_NOBACKGROUND = 0x04,
        THBF_HIDDEN = 0x08
    }

    [Serializable, Flags]
    public enum THBMASK
    {
        THB_BITMAP = 0x01,
        THB_ICON = 0x02,
        THB_TOOLTIP = 0x4,
        THB_FLAGS = 0x08
    }

    [Serializable, StructLayout(LayoutKind.Sequential, Pack=4, CharSet=CharSet.Unicode)]
    public struct THUMBBUTTON
    {
        [MarshalAs(UnmanagedType.U4)] public THBMASK dwMask;
        public uint iId;                        // Unique button ID
        public uint iBitmap;                    // ImageList ID
        public IntPtr hIcon;                    // ... or an hIcon
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=260)] public string szTip;  // Tooltip string
        [MarshalAs(UnmanagedType.U4)] public THBFLAGS dwFlags;  // Enable/Disable/Hide/etc.
    }

    [ComImport]
    [Guid("ea1afb91-9e28-4b86-90e9-9e9f8a5eefaf")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface ITaskbarList3
    {
        // ITaskbarList
        void HrInit();
        void AddTab(IntPtr hwnd);
        void DeleteTab(IntPtr hwnd);
        void ActivateTab(IntPtr hwnd);
        void SetActiveAlt(IntPtr hwnd);

        // ITaskbarList2
        void MarkFullscreenWindow(IntPtr hwnd, [MarshalAs(UnmanagedType.Bool)] bool fullscreen);

        // ITaskbarList3
        void SetProgressValue(IntPtr hwnd, UInt64 ullCompleted, UInt64 ullTotal);
        void SetProgressState(IntPtr hwnd, TBPFLAG tbpFlags);
        void RegisterTab(IntPtr hwndTab, IntPtr hwndFrame);
        void UnregisterTab(IntPtr hwndTab);
        void SetTabOrder(IntPtr hwndTab, IntPtr hwndInsertBefore);
        void SetTabActive(IntPtr hwndTab, TBATFLAG tbatFlags);
        void ThumbBarAddButtons(IntPtr hwnd, [MarshalAs(UnmanagedType.U4)] int cButtons, [MarshalAs(UnmanagedType.LPArray)] THUMBBUTTON[] pButtons);
        void ThumbBarUpdateButtons(IntPtr hwnd, [MarshalAs(UnmanagedType.U4)] int cButtons, [MarshalAs(UnmanagedType.LPArray)] THUMBBUTTON[] pButtons);
        void ThumbBarSetImageList(IntPtr hwnd, IntPtr himl);
        void SetOverlayIcon(IntPtr hwnd, IntPtr hIcon, [MarshalAs(UnmanagedType.LPWStr)] string unknown); // NULL icon means none
        void SetThumbnailTooltip(IntPtr hwnd, [MarshalAs(UnmanagedType.LPWStr)] string pszTip);
        void SetThumbnailClip(IntPtr hwnd, RECT rcClip);
    }

    [ComImport]
    [Guid("56FDF344-FD6D-11d0-958A-006097C9A090")]
    [ClassInterface(ClassInterfaceType.None)]
    public class TaskbarList
    {
    }

    [StructLayout(LayoutKind.Sequential, Pack=4)]
    public struct SHARDAPPIDINFO
    {
        [MarshalAs(UnmanagedType.Interface)] public IShellItem psi;        // The namespace location of the the item that should be added to the recent docs folder.
        [MarshalAs(UnmanagedType.LPWStr)] public string pszAppID;        // The id of the application that should be associated with this recent doc.
    }

    [StructLayout(LayoutKind.Sequential, Pack=4)]
    public struct SHARDAPPIDINFOIDLIST
    {
        public IntPtr pidl;        // The idlist for the shell item that should be added to the recent docs folder.
        [MarshalAs(UnmanagedType.LPWStr)] public string  pszAppID;        // The id of the application that should be associated with this recent doc.
    }

    [StructLayout(LayoutKind.Sequential, Pack=4)]
    public struct SHARDAPPIDINFOLINK
    {
        public IntPtr psl;      // A IShellLink instance that when launched opens a recently used item in the specified 
                                // application. This link is not added to the recent docs folder, but will be added to the
                                // specified application's destination list.
        [MarshalAs(UnmanagedType.LPWStr)] public string  pszAppID;        // The id of the application that should be associated with this recent doc.
    }

    /// <summary>
    /// System icon types
    /// </summary>
    [Serializable]
    public enum SystemIcon
    {
        IDI_APPLICATION     = 32512,
        IDI_HAND            = 32513,
        IDI_QUESTION        = 32514,
        IDI_EXCLAMATION     = 32515,
        IDI_ASTERISK        = 32516,
        IDI_WINLOGO         = 32517,
        IDI_SHIELD          = 32518
    }

    [Serializable]
    public enum SHARD
    {
        SHARD_PIDL            = 0x00000001,
        SHARD_PATHA           = 0x00000002,
        SHARD_PATHW           = 0x00000003,
        SHARD_APPIDINFO       = 0x00000004, // indicates the data type is a pointer to a SHARDAPPIDINFO structure
        SHARD_APPIDINFOIDLIST = 0x00000005, // indicates the data type is a pointer to a SHARDAPPIDINFOIDLIST structure
        SHARD_LINK            = 0x00000006, // indicates the data type is a pointer to an IShellLink instance
        SHARD_APPIDINFOLINK   = 0x00000007, // indicates the data type is a pointer to a SHARDAPPIDINFOLINK structure 

    }

    [Serializable]
    public enum LIBRARYFOLDERFILTER
    {	
        LFF_FORCEFILESYSTEM	= 1,
        LFF_STORAGEITEMS	= 2,
        LFF_ALLITEMS	    = 3
    }

    [Serializable, Flags]
    public enum LIBRARYOPTIONFLAGS
    {	
        LOF_DEFAULT	        = 0,
	    LOF_PINNEDTONAVPANE	= 0x1,
	    LOF_MASK_ALL	    = 0x1
    }

    [Serializable]
    public enum DEFAULTSAVEFOLDERTYPE
    {	
        DSFT_DETECT	    = 1,
	    DSFT_PRIVATE	= ( DSFT_DETECT + 1 ) ,
	    DSFT_PUBLIC	    = ( DSFT_PRIVATE + 1 ) 
    }

    [Serializable, Flags]
    public enum LIBRARYSAVEFLAGS
    {	
        LSF_FAILIFTHERE	= 0,
	    LSF_OVERRIDEEXISTING	= 0x1,
	    LSF_MAKEUNIQUENAME	= 0x2
    }

    [ComImport]
    [Guid("11a66efa-382e-451a-9234-1e0e12ef3085")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IShellLibrary 
    {
        void LoadLibraryFromItem(IShellItem psiLibrary, uint grfMode);
        void LoadLibraryFromKnownFolder([MarshalAs(UnmanagedType.LPStruct)] Guid knownfidLibrary, uint grfMode);
        void AddFolder(IShellItem psiLocation);
        void RemoveFolder(IShellItem psiLocation);
        void GetFolders(LIBRARYFOLDERFILTER lff, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, [MarshalAs(UnmanagedType.IUnknown)] out object ppv);
        void ResolveFolder(IShellItem psiFolderToResolve, int dwTimeout, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, [MarshalAs(UnmanagedType.IUnknown)] out object ppv);
        void GetDefaultSaveFolder(DEFAULTSAVEFOLDERTYPE dsft, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, [MarshalAs(UnmanagedType.IUnknown)] out object ppv);
        void SetDefaultSaveFolder(DEFAULTSAVEFOLDERTYPE dsft, IShellItem psi);
        void GetOptions([MarshalAs(UnmanagedType.U4)] out LIBRARYOPTIONFLAGS plofOptions);
        void SetOptions(LIBRARYOPTIONFLAGS lofMask, LIBRARYOPTIONFLAGS lofOptions);
        void GetFolderType(out Guid pfolderTypeID);
        void SetFolderType([MarshalAs(UnmanagedType.LPStruct)] Guid folderTypeID);
        void GetIcon(out string ppszIcon);
        void SetIcon(string pszIcon); 
        void Commit();
        void Save(IShellItem psiFolderToSaveIn, string pszLibraryName, LIBRARYSAVEFLAGS lsf, out IShellItem ppsiSavedTo);
        void SaveInKnownFolder([MarshalAs(UnmanagedType.LPStruct)] Guid kfidToSaveIn, string pszLibraryName, LIBRARYSAVEFLAGS lsf, out IShellItem ppsiSavedTo);
    };

    [ComImport]
    [Guid("d9b3211d-e57f-4426-aaef-30a806add397")]
    [ClassInterface(ClassInterfaceType.None)]
    public class ShellLibrary
    {
    }

    /// <summary>
    /// A small list of known folders taken from knownfolders.h
    /// There are a lot more you can add.
    /// </summary>
    public static class KnownFolders
    {
        // New for Windows 7
        public static Guid FOLDERID_DocumentsLibrary = new Guid("7B0DB17D-9CD2-4A93-9733-46CC89022E7C");
        public static Guid FOLDERID_MusicLibrary = new Guid("2112AB0A-C86A-4ffe-A368-0DE96E47012E");
        public static Guid FOLDERID_PicturesLibrary = new Guid("A990AE9F-A03B-4e80-94BC-9912D7504104");
        public static Guid FOLDERID_VideosLibrary = new Guid("491E922F-5643-4af4-A7EB-4E7A138D8174");
        public static Guid FOLDERID_RecordedTVLibrary = new Guid("1A6FDBA2-F42D-4358-A798-B74D745926C5");
    }

    [Serializable, Flags]
    public enum STGM
    {
        // Access
        STGM_READ = 0x00000000,
        STGM_WRITE = 0x00000001,
        STGM_READWRITE = 0x00000002,
        // Sharing
        STGM_SHARE_DENY_NONE = 0x00000040,
        STGM_SHARE_DENY_READ = 0x00000030,
        STGM_SHARE_DENY_WRITE = 0x00000020,
        STGM_SHARE_EXCLUSIVE = 0x00000010,
        STGM_PRIORITY = 0x00040000,
        STGM_CREATE = 0x00001000,
        STGM_CONVERT = 0x00020000,
    }

    [Serializable, Flags]
    public enum GETPROPERTYSTOREFLAGS
    {	
        GPS_DEFAULT	                = 0,
	    GPS_HANDLERPROPERTIESONLY	= 0x1,
	    GPS_READWRITE	            = 0x2,
	    GPS_TEMPORARY	            = 0x4,
	    GPS_FASTPROPERTIESONLY	    = 0x8,
	    GPS_OPENSLOWITEM	        = 0x10,
	    GPS_DELAYCREATION	        = 0x20,
	    GPS_BESTEFFORT	            = 0x40,
	    GPS_NO_OPLOCK	            = 0x80,
	    GPS_MASK_VALID	            = 0xff
    }

    [Serializable, Flags]
    public enum SIATTRIBFLAGS
    {	
        SIATTRIBFLAGS_AND	= 0x1,
	    SIATTRIBFLAGS_OR	= 0x2,
	    SIATTRIBFLAGS_APPCOMPAT	= 0x3,
	    SIATTRIBFLAGS_MASK	= 0x3,
	    SIATTRIBFLAGS_ALLITEMS	= 0x4000
    }

    [Serializable, Flags]
    public enum SFGAOF : uint
    {
        SFGAO_CANCOPY           = 0x00000001, // Objects can be copied    (0x1)
        SFGAO_CANMOVE           = 0x00000002, // Objects can be moved     (0x2)
        SFGAO_CANLINK           = 0x00000004, // Objects can be linked    (0x4)
        SFGAO_STORAGE           = 0x00000008,     // supports BindToObject(IID_IStorage)
        SFGAO_CANRENAME         = 0x00000010,     // Objects can be renamed
        SFGAO_CANDELETE         = 0x00000020,     // Objects can be deleted
        SFGAO_HASPROPSHEET      = 0x00000040,     // Objects have property sheets
        SFGAO_DROPTARGET        = 0x00000100,     // Objects are drop target
        SFGAO_CAPABILITYMASK    = 0x00000177,
        SFGAO_SYSTEM            = 0x00001000,     // System object
        SFGAO_ENCRYPTED         = 0x00002000,     // Object is encrypted (use alt color)
        SFGAO_ISSLOW            = 0x00004000,     // 'Slow' object
        SFGAO_GHOSTED           = 0x00008000,     // Ghosted icon
        SFGAO_LINK              = 0x00010000,     // Shortcut (link)
        SFGAO_SHARE             = 0x00020000,     // Shared
        SFGAO_READONLY          = 0x00040000,     // Read-only
        SFGAO_HIDDEN            = 0x00080000,     // Hidden object
        SFGAO_DISPLAYATTRMASK   = 0x000FC000,
        SFGAO_FILESYSANCESTOR   = 0x10000000,     // May contain children with SFGAO_FILESYSTEM
        SFGAO_FOLDER            = 0x20000000,     // Support BindToObject(IID_IShellFolder)
        SFGAO_FILESYSTEM        = 0x40000000,     // Is a win32 file system object (file/folder/root)
        SFGAO_HASSUBFOLDER      = 0x80000000,     // May contain children with SFGAO_FOLDER (may be slow)
        SFGAO_CONTENTSMASK      = 0x80000000,
        SFGAO_VALIDATE          = 0x01000000,     // Invalidate cached information (may be slow)
        SFGAO_REMOVABLE         = 0x02000000,     // Is this removeable media?
        SFGAO_COMPRESSED        = 0x04000000,     // Object is compressed (use alt color)
        SFGAO_BROWSABLE         = 0x08000000,     // Supports IShellFolder, but only implements CreateViewObject() (non-folder view)
        SFGAO_NONENUMERATED     = 0x00100000,     // Is a non-enumerated object (should be hidden)
        SFGAO_NEWCONTENT        = 0x00200000,     // Should show bold in explorer tree
        SFGAO_CANMONIKER        = 0x00400000,     // Obsolete
        SFGAO_HASSTORAGE        = 0x00400000,     // Obsolete
        SFGAO_STREAM            = 0x00400000,     // Supports BindToObject(IID_IStream)
        SFGAO_STORAGEANCESTOR   = 0x00800000,     // May contain children with SFGAO_STORAGE or SFGAO_STREAM
        SFGAO_STORAGECAPMASK    = 0x70C50008,     // For determining storage capabilities, ie for open/save semantics
        SFGAO_PKEYSFGAOMASK = 0x81044000,     // Attributes that are masked out for PKEY_SFGAOFlags because they are considered to cause slow calculations or lack context (SFGAO_VALIDATE | SFGAO_ISSLOW | SFGAO_HASSUBFOLDER and others)
    }

    [ComImport]
    [Guid("b63ea76d-1f85-456f-a19c-48159efa858b")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IShellItemArray
    {
        void BindToHandler(IBindCtx pbc, [MarshalAs(UnmanagedType.LPStruct)] Guid bhid, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, [MarshalAs(UnmanagedType.IUnknown)] out object ppvOut);
        void GetPropertyStore(GETPROPERTYSTOREFLAGS flags, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, [MarshalAs(UnmanagedType.IUnknown)] out object ppv);
        void GetPropertyDescriptionList(ref PROPERTYKEY keyType, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, [MarshalAs(UnmanagedType.IUnknown)] out object ppv);
        void GetAttributes(SIATTRIBFLAGS AttribFlags, [MarshalAs(UnmanagedType.U4)] SFGAOF sfgaoMask, out SFGAOF psfgaoAttribs);
        void GetCount(out uint dwNumItems);
        void GetItemAt(uint dwIndex, out IShellItem ppsi); 
        void EnumItems(out IEnumShellItems ppenumShellItems);
        
    }

    [ComImport]
    [Guid("70629033-e363-4a28-a567-0db78006e6d7")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IEnumShellItems
    {
        void Next(uint celt, out IShellItem[] rgelt, out uint pceltFetched);
        void Skip(uint celt);
        void Reset();
        void Clone(out IEnumShellItems ppenum); 
    };
}
