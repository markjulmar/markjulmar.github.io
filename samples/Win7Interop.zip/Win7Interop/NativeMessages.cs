﻿using System;
using System.Runtime.InteropServices;

namespace Windows7.Interop
{
    public static class NativeMessages
    {
        /// <summary>
        /// Exposes methods that enable clients to access items in a collection of objects that support IUnknown
        /// </summary>
        public static Guid IID_IObjectArray = new Guid("92CA9DCD-5622-4bba-A805-5E9F541BD8C9");

        /// <summary>
        /// Extends the IObjectArray interface by providing methods that enable clients to add and remove objects that support IUnknown in a collection.
        /// </summary>
        public static Guid IID_IObjectCollection = new Guid("5632b1a4-e38a-400a-928a-d4cd63230295");

        /// <summary>
        /// Exposes methods for enumerating, getting, and setting property values.
        /// </summary>
        public static Guid IID_IPropertyStore = new Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99");

        /// <summary>
        /// Taskbar button click
        /// </summary>
        public const int THBN_CLICKED = 0x1800;

        /// <summary>
        /// COMMAND from Win32 control
        /// </summary>
        public const int WM_COMMAND = 0x111;

        /// <summary>
        /// Gesture from Win32
        /// </summary>
        public const int WM_GESTURE = 0x0119;

        /// <summary>
        /// Notification of a received gesture from Win32
        /// </summary>
        public const int WM_GESTURENOTIFY = 0x011a;

        /// <summary>
        /// Contact down (Win32)
        /// </summary>
        public const int WM_TOUCHDOWN = 0x241;

        /// <summary>
        /// Contact move (Win32)
        /// </summary>
        public const int WM_TOUCHMOVE = 0x240;

        /// <summary>
        /// Contact up (Win32)
        /// </summary>
        public const int WM_TOUCHUP = 0x242;

        private const int WM_TABLET_DEFBASE = 0x02C0;

        /// <summary>
        /// Flick gesture 
        /// </summary>
        public const int WM_TABLET_FLICK = (WM_TABLET_DEFBASE + 11);

        /// <summary>
        /// Gesture status test
        /// </summary>
        public const int WM_TABLET_QUERYSYSTEMGESTURESTATUS = (WM_TABLET_DEFBASE + 12);

        /// <summary>
        /// Table properties
        /// </summary>
        public const string MICROSOFT_TABLETPENSERVICE_PROPERTY = "MicrosoftTabletPenServiceProperty";

        /// <summary>
        /// Helper to retrieve the HIWORD of an IntPtr
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public static int HIWORD(IntPtr i) { return i.ToInt32() >> 16; }

        /// <summary>
        /// Helper to retrieve the LOWORD of an IntPtr
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public static int LOWORD(IntPtr i) { return i.ToInt32() & 0xffff; }

        private static uint _TB_MSG;
        [DllImport("user32.dll", SetLastError = true)]
        static extern uint RegisterWindowMessage(string lpString);

        /// <summary>
        /// Message sent to window when TaskBarButton creation is possible
        /// </summary>
        public static uint WM_TASKBARBUTTONCREATED
        {
            get
            {
                if (_TB_MSG == 0) 
                    _TB_MSG = RegisterWindowMessage("TaskbarButtonCreated");
                return _TB_MSG;
            }
        }
    }
}
