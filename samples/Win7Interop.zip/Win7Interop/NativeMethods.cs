using System;
using System.Runtime.InteropServices;

namespace Windows7.Interop
{
    /// <summary>
    /// This class holds all the native methods for Windows 7 interop
    /// </summary>
    public static class NativeMethods
    {
        [DllImport("shell32.dll")] static extern void SHAddToRecentDocs(SHARD flag, string path);
        [DllImport("shell32.dll")] static extern void SHAddToRecentDocs(SHARD flag, IntPtr pidl);
        [DllImport("shell32.dll")] static extern void SHAddToRecentDocs(SHARD flag, ref SHARDAPPIDINFO appIDInfo);
        [DllImport("shell32.dll")] static extern void SHAddToRecentDocs(SHARD flag, ref SHARDAPPIDINFOIDLIST appIDInfoList);
        [DllImport("shell32.dll")] static extern void SHAddToRecentDocs(SHARD flag, ref SHARDAPPIDINFOLINK appIDInfoLink);

        /// <summary>
        /// Notifies the system that an item has been accessed, for the purposes of 
        /// tracking items used most recently and most frequently. This function can also be 
        /// used to clear all usage data.
        /// </summary>
        /// <param name="path">Filename to add</param>
        public static void SHAddToRecentDocs(string path) { SHAddToRecentDocs(SHARD.SHARD_PATHW, path); }

        /// <summary>
        /// Notifies the system that an item has been accessed, for the purposes of 
        /// tracking items used most recently and most frequently. This function can also be 
        /// used to clear all usage data.
        /// </summary>
        /// <param name="appIDInfo">Identifies IShellItem to add</param>
        public static void SHAddToRecentDocs(ref SHARDAPPIDINFO appIDInfo) { SHAddToRecentDocs(SHARD.SHARD_APPIDINFO, ref appIDInfo); }

        /// <summary>
        /// Notifies the system that an item has been accessed, for the purposes of 
        /// tracking items used most recently and most frequently. This function can also be 
        /// used to clear all usage data.
        /// </summary>
        /// <param name="appIDInfoList">Identifies PIDL (item identifier list + process) to add</param>
        public static void SHAddToRecentDocs(ref SHARDAPPIDINFOIDLIST appIDInfoList) { SHAddToRecentDocs(SHARD.SHARD_APPIDINFOIDLIST, ref appIDInfoList); }

        /// <summary>
        /// Notifies the system that an item has been accessed, for the purposes of 
        /// tracking items used most recently and most frequently. This function can also be 
        /// used to clear all usage data.
        /// </summary>
        /// <param name="appIDInfoLink">Identifies the IShellLink to add</param>
        public static void SHAddToRecentDocs(ref SHARDAPPIDINFOLINK appIDInfoLink) { SHAddToRecentDocs(SHARD.SHARD_APPIDINFOLINK, ref appIDInfoLink); }

        /// <summary>
        /// Creates and loads an IShellLibrary object from a specified library definition file. 
        /// </summary>
        /// <param name="psiLibrary">An IShellItem object for the library definition file to load.</param>
        /// <param name="grfMode"></param>
        /// <returns></returns>
        public static IShellLibrary SHLoadLibraryFromItem(IShellItem psiLibrary, uint grfMode)
        {
            IShellLibrary shellLib = (IShellLibrary) new ShellLibrary();
            shellLib.LoadLibraryFromItem(psiLibrary, grfMode);

            return shellLib;
        }

        /// <summary>
        /// Creates and loads an IShellLibrary object for a specified known folder ID. 
        /// </summary>
        /// <param name="kfidLibrary"></param>
        /// <param name="grfMode"></param>
        /// <returns></returns>
        public static IShellLibrary SHLoadLibraryFromKnownFolder(Guid kfidLibrary, uint grfMode)
        {
            IShellLibrary shellLib = (IShellLibrary) new ShellLibrary();
            shellLib.LoadLibraryFromKnownFolder(kfidLibrary, grfMode);
            return shellLib;
        }

        /// <summary>
        /// Creates and initializes a Shell item object from a parsing name.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="shellItem"></param>
        [DllImport("shell32.dll")] 
        public static extern void SHCreateItemFromParsingName(string name, out IShellItem shellItem);
        
        /// <summary>
        /// Creates and loads an IShellLibrary object for a specified path. 
        /// </summary>
        /// <param name="pszParsingName"></param>
        /// <param name="grfMode"></param>
        /// <returns></returns>
        public static IShellLibrary SHLoadLibraryFromParsingName(string pszParsingName, uint grfMode)
        {
            IShellItem shellItem;
            SHCreateItemFromParsingName(pszParsingName, out shellItem);
            return SHLoadLibraryFromItem(shellItem, grfMode);
        }

        /// <summary>
        /// Adds a folder to a library. 
        /// </summary>
        /// <param name="plib"></param>
        /// <param name="pszFolderPath"></param>
        public static void SHAddFolderPathToLibrary(IShellLibrary plib, string pszFolderPath)
        {
            IShellItem psiFolder;
            SHCreateItemFromParsingName(pszFolderPath, out psiFolder);
            plib.AddFolder(psiFolder);
        }

        /// <summary>
        /// Removes a folder from a library. 
        /// </summary>
        /// <param name="plib"></param>
        /// <param name="pszFolderPath"></param>
        public static void SHRemoveFolderPathFromLibrary(IShellLibrary plib, string pszFolderPath)
        {
            IShellItem psiFolder;
            SHCreateItemFromParsingName(pszFolderPath, out psiFolder);
            plib.RemoveFolder(psiFolder);
        }

        /// <summary>
        /// Attempts to resovle the target location of a library folder that has been moved or renamed. 
        /// </summary>
        /// <param name="plib"></param>
        /// <param name="pszFolderPath"></param>
        /// <param name="dwTimeout"></param>
        /// <returns></returns>
        public static string SHResolveFolderPathInLibrary(IShellLibrary plib, string pszFolderPath, int dwTimeout)
        {
            IShellItem psiFolder;
            SHCreateItemFromParsingName(pszFolderPath, out psiFolder);

            object ppv;
            plib.ResolveFolder(psiFolder, dwTimeout, Marshal.GenerateGuidForType(typeof(IShellItem)), out ppv);
            IShellItem psiResolved = (IShellItem) ppv;
            
            IntPtr resolvedPath;
            psiResolved.GetDisplayName(SIGDN.SIGDN_DESKTOPABSOLUTEPARSING, out resolvedPath);
            return Marshal.PtrToStringUni(resolvedPath);
        }

        /// <summary>
        /// Saves an IShellLibrary object to disk. 
        /// </summary>
        /// <param name="plib"></param>
        /// <param name="pszFolderPath"></param>
        /// <param name="pszLibraryName"></param>
        /// <param name="lsf"></param>
        /// <returns></returns>
        public static string SHSaveLibraryInFolderPath(IShellLibrary plib, string pszFolderPath, string pszLibraryName, LIBRARYSAVEFLAGS lsf)
        {
            IShellItem psiFolder;
            SHCreateItemFromParsingName(pszFolderPath, out psiFolder);
            IShellItem psiSavedTo;
            plib.Save(psiFolder, pszLibraryName, lsf, out psiSavedTo);

            IntPtr resolvedPath;
            psiSavedTo.GetDisplayName(SIGDN.SIGDN_DESKTOPABSOLUTEPARSING, out resolvedPath);
            return Marshal.PtrToStringUni(resolvedPath);
        }

        /// <summary>
        /// Specifies a unique application-defined Application User Model ID (AppID) 
        /// that identifies the current process to the taskbar. This identifier allows 
        /// an application to group its associated processes and windows under a single 
        /// taskbar button.
        /// </summary>
        /// <param name="AppID">application ID</param>
        [DllImport("shell32.dll")] 
        public static extern void SetCurrentProcessExplicitAppUserModelID(string AppID);

        /// <summary>
        /// Retrieves the application-defined, explicit Application User Model ID (AppID) 
        /// for the current process.
        /// </summary>
        /// <param name="AppID">assigned app id</param>
        [DllImport("shell32.dll")] 
        public static extern void GetCurrentProcessExplicitAppUserModelID([Out] out string AppID);

        /// <summary>
        /// Helper method to create an IShellLink to add to the jump list
        /// </summary>
        /// <param name="title">Title for link</param>
        /// <param name="filename">Filename to execute</param>
        /// <param name="arguments">Parameters to pass</param>
        /// <returns>IShellLink interface</returns>
        public static IShellLinkW CreateUserTask(string title, string filename, string arguments)
        {
            return CreateUserTask(title, filename, arguments, null, -1);
        }

        /// <summary>
        /// Helper method to create an IShellLink to add to the jump list
        /// </summary>
        /// <param name="title">Title for link</param>
        /// <param name="filename">Filename to execute</param>
        /// <param name="arguments">Parameters to pass</param>
        /// <param name="iconFile">File to retrieve icon from</param>
        /// <param name="iconID">Index of icon</param>
        /// <returns>IShellLink interface</returns>
        public static IShellLinkW CreateUserTask(string title, string filename, string arguments, string iconFile, int iconID)
        {
            var sl = (IShellLinkW) new ShellLink();

            // Title is stored in IPropertyStore
            var ps = (IPropertyStore) sl;
            var pvTitle = new PROPVARIANT();
            pvTitle.SetValue(title);
            ps.SetValue(ref PROPERTYKEY.PKEY_Title, ref pvTitle);

            // Set the launch path and arguments
            sl.SetPath(filename);
            sl.SetArguments(arguments);

            // If an icon is supplied, then add that too
            if (iconFile != null)
                sl.SetIconLocation(iconFile, iconID);

            return sl;
        }

        [DllImport("kernel32 .dll", SetLastError = true)] static extern IntPtr LoadLibrary(string lpFileName);
        [DllImport("kernel32 .dll", SetLastError = true)] static extern bool FreeLibrary(IntPtr hInstance);
        [DllImport("kernel32.dll", SetLastError = true)] public static extern IntPtr GetModuleHandle(string lpFileName);
        [DllImport("user32.dll", SetLastError = true)] private static extern IntPtr LoadIcon(IntPtr hInstance, IntPtr lpIconName);
        [DllImport("user32.dll", SetLastError = true)] private static extern IntPtr LoadIcon(IntPtr hInstance, string iconName);

        /// <summary>
        /// Loads a system (Windows) icon
        /// </summary>
        /// <param name="systemIcon">Icon to load</param>
        /// <returns>HICON</returns>
        public static IntPtr LoadSystemIcon(SystemIcon systemIcon)
        {
            return LoadIcon(IntPtr.Zero, new IntPtr((int)systemIcon));
        }

        /// <summary>
        /// Loads an icon from a file
        /// </summary>
        /// <param name="fileName">DLL or EXE to load icon from</param>
        /// <param name="iconName">Name of icon resource</param>
        /// <returns>HICON</returns>
        public static IntPtr LoadIcon(string fileName, string iconName)
        {
            IntPtr icon = IntPtr.Zero;
            IntPtr hLibrary = LoadLibrary(fileName);
            if (hLibrary != IntPtr.Zero)
            {
                icon = LoadIcon(hLibrary, iconName);
                FreeLibrary(hLibrary);
            }
            return icon;
        }

        /// <summary>
        /// This function is used to set up a system-wide default handler HWND for unhandled gestures.
        /// </summary>
        /// <param name="hwnd">HWND</param>
        /// <param name="dwFlags">Flags</param>
        /// <returns>success flags</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool RegisterGestureHandlerWindow(IntPtr hwnd,
                                                  [MarshalAs(UnmanagedType.U4)] RegisterGestureFlags dwFlags);

        /// <summary>
        /// This is used to unregister a the global HWND gesture message handler
        /// </summary>
        /// <param name="hwnd">HWND</param>
        /// <param name="dwFlags">Flags</param>
        /// <returns>success flags</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool UnregisterGestureHandlerWindow(IntPtr hwnd,
                                                  [MarshalAs(UnmanagedType.U4)] RegisterGestureFlags dwFlags);

        /// <summary>
        /// Converts the ullArgument from a ROTATE gesture into an angle
        /// Argument should be an unsigned 16-bit value
        /// Converts from "binary radians" to traditional radians.
        /// </summary>
        /// <param name="arg">agument</param>
        /// <returns>angle</returns>
        public static double ROTATE_ANGLE_FROM_ARGUMENT(double arg)
        {
            return (((arg / 65535.0) * 4.0 * Math.PI) - 2.0 * 3.14159265);
        }

        /// <summary>
        /// Configures the messages that are sent from a window for multitouch gestures. 
        /// </summary>
        /// <param name="hwnd">Window Handle</param>
        /// <param name="dwReserved">Must be zero</param>
        /// <param name="cIDs">Count of GESTURECONFIG structures</param>
        /// <param name="pGestureConfig">Array of GESTURECONFIG structures</param>
        /// <param name="cbSize">sizeof(GESTURECONFIG)</param>
        /// <returns>success/failure</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public extern static bool SetGestureConfig(IntPtr hwnd, int dwReserved, int cIDs, [In] GESTURECONFIG[] pGestureConfig, int cbSize);

        /// <summary>
        /// Retrieves the configuration for which multitouch gesture messages are sent from a window. 
        /// </summary>
        /// <param name="hwnd">Window Handle</param>
        /// <param name="dwReserved">Must be zero</param>
        /// <param name="dwFlags">Configuration flags</param>
        /// <param name="cIDs">Number of expected gesture configuraiton structures</param>
        /// <param name="pGestureConfig">Allocated config structures</param>
        /// <param name="cbSize">sizeof(GESTURECONFIG)</param>
        /// <returns>success/fail</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public extern static bool GetGestureConfig(IntPtr hwnd, int dwReserved,
            [MarshalAs(UnmanagedType.U4)] GestureConfigFlags dwFlags, 
            [In] ref int cIDs, 
            [In, Out] GESTURECONFIG[] pGestureConfig, int cbSize);

        /// <summary>
        /// Retrieves a gesture information structure given a handle to the 
        /// gesture information. 
        /// </summary>
        /// <param name="hGestureInfo">Handle to gesture information</param>
        /// <param name="pGestureInfo">Returning gesture info</param>
        /// <returns>success/fail</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool GetGestureInfo(IntPtr hGestureInfo, out GESTUREINFO pGestureInfo);

        /// <summary>
        /// Gesture extra arguments retrieval
        ///   - HGESTUREINFO is received by a window in the lParam of a WM_GESTURE message.
        ///   - Size, in bytes, of the extra argument data is available in the cbExtraArgs
        ///     field of the GESTUREINFO structure retrieved using the GetGestureInfo function.
        /// </summary>
        /// <param name="hGestureInfo">Handle to the gesture information</param>
        /// <param name="cbExtaArgs">size from GESTUREINFO</param>
        /// <param name="pExtraArgs">Returning data</param>
        /// <returns>success/fail</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool GetGestureExtraArgs(IntPtr hGestureInfo, 
            uint cbExtaArgs, out byte[] pExtraArgs);

        /// <summary>
        /// Gesture information handle management
        ///   - If an application processes the WM_GESTURE message, then once it is done
        ///     with the associated HGESTUREINFO, the application is responsible for
        ///     closing the handle using this function. Failure to do so may result in
        ///     process memory leaks.
        ///   - If the message is instead passed to DefWindowProc, or is forwarded using
        ///     one of the PostMessage or SendMessage class of API functions, the handle
        ///     is transfered with the message and need not be closed by the application.
        /// </summary>
        /// <param name="hGestureInfo">Handle to gesture info</param>
        /// <returns>Success/Fail</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool CloseGestureInfoHandle(IntPtr hGestureInfo);

        /// <summary>
        /// Registers a window as being touch-capable
        /// </summary>
        /// <param name="hwnd">Window Handle</param>
        /// <param name="flags">Touch flags</param>
        /// <returns>Success/Fail</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool RegisterTouchWindow(IntPtr hwnd, [MarshalAs(UnmanagedType.U4)] RegisterTouchFlags flags);
        
        /// <summary>
        /// Unregisters a window as being touch-capable
        /// </summary>
        /// <param name="hwnd">Window Handle</param>
        /// <returns>true/false</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool UnregisterTouchWindow(IntPtr hwnd);
 
        /// <summary>
        /// Retrieves detailed information about touch inputs associated with a given touch input handle.
        /// </summary>
        /// <param name="hTouchInput">Touch handle</param>
        /// <param name="cInputs">Expected TOUCHINPUT structure count</param>
        /// <param name="pInputs">TOUCHINPUT array</param>
        /// <param name="cbSize">sizeof(TOUCHINPUT)</param>
        /// <returns>success/fail</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool GetTouchInputInfo(IntPtr hTouchInput, int cInputs, [Out] TOUCHINPUT[] pInputs, int cbSize);
        
        /// <summary>
        /// Close the given touch handle
        /// </summary>
        /// <param name="hTouchHandle">Touch handle</param>
        /// <returns>success/fail</returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool CloseTouchInputHandle(IntPtr hTouchHandle);
    
        /// <summary>
        /// Converts screen-based coordinates to HWND-client based coordinates
        /// </summary>
        /// <param name="hwnd"></param>
        /// <param name="pt"></param>
        /// <returns></returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool ScreenToClient(IntPtr hwnd, ref POINT pt);

        /// <summary>
        /// This method casts a message WPARAM/LPARAM to a structure
        /// </summary>
        /// <typeparam name="T">Type of structure to return</typeparam>
        /// <param name="param">WPARAM or LPARAM</param>
        /// <returns>Structure</returns>
        public static T CastMessageParam<T>(IntPtr param)
        {
            return (T) Marshal.PtrToStructure(param, typeof (T));
        }

        /// <summary>
        /// This sets a property onto the window - we use it here to enable
        /// multi-touch in WPF applications
        /// </summary>
        /// <param name="hwnd">HWND</param>
        /// <param name="type">ATOM to set</param>
        /// <param name="lpData">Value</param>
        /// <returns>success/fail</returns>
        [DllImport("User32.dll", SetLastError = true)]
        public static extern bool SetProp(IntPtr hwnd, string type, IntPtr lpData);
    }

}