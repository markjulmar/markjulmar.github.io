﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

namespace Windows7.Interop
{
    /// <summary>
    /// Defines the property keys used for the ribbon
    /// </summary>
    public static class RibbonPropertyKeys
    {
        static public PROPERTYKEY UI_PKEY_Enabled = new PROPERTYKEY {pid = (uint) VarEnum.VT_BOOL, fmtid = new Guid("00000001-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_LabelDescription = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("00000002-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_Keytip = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("00000003-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_Label = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("00000004-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_TooltipDescription = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("00000005-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_TooltipTitle = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("00000006-7363-696e-8441-798acf5aebb7") };
        // IUIImage
        static public PROPERTYKEY UI_PKEY_LargeImage = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("00000007-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_LargeHighContrastImage = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("00000008-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_SmallImage = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("00000009-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_SmallHighContrastImage = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("0000000a-7363-696e-8441-798acf5aebb7") };

        // Collections properties
        static public PROPERTYKEY UI_PKEY_CommandId = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000064-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_ItemsSource = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("00000065-7363-696e-8441-798acf5aebb7") }; // IEnumUnknown or IUICollection
        static public PROPERTYKEY UI_PKEY_Categories = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("00000066-7363-696e-8441-798acf5aebb7") }; // IEnumUnknown or IUICollection
        static public PROPERTYKEY UI_PKEY_CategoryId = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000067-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_SelectedItem = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000068-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_CommandType = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000069-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_ItemImage = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("0000006a-7363-696e-8441-798acf5aebb7") }; // IUIImage

        // Control properties
        static public PROPERTYKEY UI_PKEY_BooleanValue = new PROPERTYKEY { pid = (uint)VarEnum.VT_BOOL, fmtid = new Guid("000000c8-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_DecimalValue = new PROPERTYKEY { pid = (uint)VarEnum.VT_DECIMAL, fmtid = new Guid("000000c9-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_StringValue = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("000000ca-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_MaxValue = new PROPERTYKEY { pid = (uint)VarEnum.VT_DECIMAL, fmtid = new Guid("000000cb-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_MinValue = new PROPERTYKEY { pid = (uint)VarEnum.VT_DECIMAL, fmtid = new Guid("000000cc-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_Increment = new PROPERTYKEY { pid = (uint)VarEnum.VT_DECIMAL, fmtid = new Guid("000000cd-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_DecimalPlaces = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("000000ce-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_FormatString = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("000000cf-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_RepresentativeString = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("000000d0-7363-696e-8441-798acf5aebb7") };

        // Font control properties
        static public PROPERTYKEY UI_PKEY_FontProperties = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("0000012c-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_FontProperties_Family = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("0000012d-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_FontProperties_Size = new PROPERTYKEY { pid = (uint)VarEnum.VT_DECIMAL, fmtid = new Guid("0000012e-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_FontProperties_Bold = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("0000012f-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_FontProperties_Italic = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000130-7363-696e-8441-798acf5aebb7") }; // UI_FONTPROPERTIES
        static public PROPERTYKEY UI_PKEY_FontProperties_Underline = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000131-7363-696e-8441-798acf5aebb7") }; // UI_FONTPROPERTIES
        static public PROPERTYKEY UI_PKEY_FontProperties_Strikethrough = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000132-7363-696e-8441-798acf5aebb7") }; // UI_FONTPROPERTIES
        static public PROPERTYKEY UI_PKEY_FontProperties_VerticalPositioning = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000133-7363-696e-8441-798acf5aebb7") }; // UI_FONTVERTICALPOSITION
        static public PROPERTYKEY UI_PKEY_FontProperties_ForegroundColor = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000134-7363-696e-8441-798acf5aebb7") }; // COLORREF
        static public PROPERTYKEY UI_PKEY_FontProperties_BackgroundColor = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000135-7363-696e-8441-798acf5aebb7") }; // COLORREF
        static public PROPERTYKEY UI_PKEY_FontProperties_ForegroundColorType = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000136-7363-696e-8441-798acf5aebb7") }; // UI_SWATCHCOLORTYPE
        static public PROPERTYKEY UI_PKEY_FontProperties_BackgroundColorType = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000137-7363-696e-8441-798acf5aebb7") }; // UI_SWATCHCOLORTYPE
        static public PROPERTYKEY UI_PKEY_FontProperties_ChangedProperties = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("00000138-7363-696e-8441-798acf5aebb7") }; // IPropertyStore
        static public PROPERTYKEY UI_PKEY_FontProperties_DeltaSize = new PROPERTYKEY { pid = (uint)VarEnum.VT_UINT, fmtid = new Guid("00000139-7363-696e-8441-798acf5aebb7") }; // UI_FONTDELTASIZE 

        // Application menu properties
        static public PROPERTYKEY UI_PKEY_RecentItems = new PROPERTYKEY { pid = (uint)VarEnum.VT_ARRAY|(uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("0000015e-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_Pinned = new PROPERTYKEY { pid = (uint)VarEnum.VT_BOOL, fmtid = new Guid("0000015f-7363-696e-8441-798acf5aebb7") };

        // Color picker properties
        static public PROPERTYKEY UI_PKEY_Color = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000190-7363-696e-8441-798acf5aebb7") }; // COLORREF
        static public PROPERTYKEY UI_PKEY_ColorType = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000191-7363-696e-8441-798acf5aebb7") }; // UI_SWATCHCOLORTYPE
        static public PROPERTYKEY UI_PKEY_ColorMode = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("00000192-7363-696e-8441-798acf5aebb7") }; // UI_SWATCHCOLORMODE
        static public PROPERTYKEY UI_PKEY_LargeImageMask = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("00000193-7363-696e-8441-798acf5aebb7") }; // IUIImage
        static public PROPERTYKEY UI_PKEY_SmallImageMask = new PROPERTYKEY { pid = (uint)VarEnum.VT_UNKNOWN, fmtid = new Guid("00000194-7363-696e-8441-798acf5aebb7") }; // IUIImage
        static public PROPERTYKEY UI_PKEY_ThemeColorsCategoryLabel = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("00000195-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_StandardColorsCategoryLabel = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("00000196-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_RecentColorsCategoryLabel = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("00000197-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_AutomaticColorLabel = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("00000198-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_NoColorLabel = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("00000199-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_MoreColorsLabel = new PROPERTYKEY { pid = (uint)VarEnum.VT_LPWSTR, fmtid = new Guid("0000019a-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_ThemeColors = new PROPERTYKEY { pid = (uint)VarEnum.VT_VECTOR|(uint)VarEnum.VT_UI4, fmtid = new Guid("0000019b-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_StandardColors = new PROPERTYKEY { pid = (uint)VarEnum.VT_VECTOR|(uint)VarEnum.VT_UI4, fmtid = new Guid("0000019c-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_ThemeColorsTooltips = new PROPERTYKEY { pid = (uint)VarEnum.VT_VECTOR|(uint)VarEnum.VT_LPWSTR, fmtid = new Guid("0000019d-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_StandardColorsTooltips = new PROPERTYKEY { pid = (uint)VarEnum.VT_VECTOR|(uint)VarEnum.VT_LPWSTR, fmtid = new Guid("0000019e-7363-696e-8441-798acf5aebb7") };


        // Ribbon properties
        static public PROPERTYKEY UI_PKEY_Viewable = new PROPERTYKEY { pid = (uint)VarEnum.VT_BOOL, fmtid = new Guid("000003e8-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_Minimized = new PROPERTYKEY { pid = (uint)VarEnum.VT_BOOL, fmtid = new Guid("000003e9-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_QuickAccessToolbarDock = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("000003ea-7363-696e-8441-798acf5aebb7") };

        // Contextual tabset properties
        static public PROPERTYKEY UI_PKEY_ContextAvailable = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("0000044c-7363-696e-8441-798acf5aebb7") };

        // Global properties
        static public PROPERTYKEY UI_PKEY_GlobalBackgroundColor = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("000007d0-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_GlobalHighlightColor = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("000007d1-7363-696e-8441-798acf5aebb7") };
        static public PROPERTYKEY UI_PKEY_GlobalTextColor = new PROPERTYKEY { pid = (uint)VarEnum.VT_UI4, fmtid = new Guid("000007d2-7363-696e-8441-798acf5aebb7") };
    }



    // Scenic Intent interfaces implemented by the framework
    [Serializable]
    public enum UI_CONTEXTAVAILABILITY
    {
        UI_CONTEXTAVAILABILITY_NOTAVAILABLE = 0,
        UI_CONTEXTAVAILABILITY_AVAILABLE    = 1,
        UI_CONTEXTAVAILABILITY_ACTIVE       = 2,
    }

    [Serializable]
    public enum UI_FONTPROPERTIES
    {
        UI_FONTPROPERTIES_NOTAVAILABLE = 0,
        UI_FONTPROPERTIES_NOTSET       = 1,
        UI_FONTPROPERTIES_SET          = 2,
    }
         
    [Serializable]
    public enum UI_FONTVERTICALPOSITION
    {
        UI_FONTVERTICALPOSITION_NOTAVAILABLE = 0,
        UI_FONTVERTICALPOSITION_NOTSET       = 1,
        UI_FONTVERTICALPOSITION_SUPERSCRIPT  = 2,
        UI_FONTVERTICALPOSITION_SUBSCRIPT    = 3,
    }
       
    [Serializable]
    public enum UI_FONTUNDERLINE
    {
        UI_FONTUNDERLINE_NOTAVAILABLE = 0,
        UI_FONTUNDERLINE_NOTSET       = 1,
        UI_FONTUNDERLINE_SET          = 2,
    }

    [Serializable]
    public enum UI_FONTDELTASIZE
    {
        UI_FONTDELTASIZE_GROW        = 0,
        UI_FONTDELTASIZE_SHRINK      = 1,
    }

    [Serializable]
    public enum UI_CONTROLDOCK
    {
        UI_CONTROLDOCK_TOP    = 1,
        UI_CONTROLDOCK_BOTTOM = 3,
    }

    // Types for the color picker

    // Determines whether a swatch has a color or is inactive.
    [Serializable]
    public enum UI_SWATCHCOLORTYPE
    {
        UI_SWATCHCOLORTYPE_RGB      = 0, // Solid color swatch
        UI_SWATCHCOLORTYPE_INACTIVE = 1, // Inactive swatch
    }

    // If the mode is set to MONOCHROME, the swatch's RGB color value will be interpreted as a 1 bit-per-pixel
    // pattern.
    [Serializable]
    public enum UI_SWATCHCOLORMODE
    {
        UI_SWATCHCOLORMODE_NORMAL     = 0,
        UI_SWATCHCOLORMODE_MONOCHROME = 1, 
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("c205bb48-5b1c-4219-a106-15bd0a5f24e2")]
    public interface IUISimplePropertySet
    {
        // Retrieves the stored value of a given property
        void GetValue([MarshalAs(UnmanagedType.LPStruct)] PROPERTYKEY key, out PROPVARIANT value);
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("7c1632c7-b9e7-460a-9bab-0a22c5b403b1")]
    public interface IUIRibbon
    {
        // Returns the desired Ribbon height based on the cyMax
        void GetDesiredHeight(int cyMax, out int cy);

        // Forces the Ribbon to a given height
        void SetHeight(int cy);

        // Load Ribbon parameters (e.g. QuickAccessToolbar) from a stream
        void LoadSettingsFromStream(IStream pStream);

        // Save Ribbon parameters (e.g. QuickAccessToolbar) to a stream
        void SaveSettingsToStream(IStream pStream);
    };

    [Serializable,Flags]
    public enum UI_INVALIDATIONS
    {
        UI_INVALIDATIONS_STATE         = 0x00000001, // UI_PKEY_Enabled
        UI_INVALIDATIONS_VALUE         = 0x00000002, // Value property
        UI_INVALIDATIONS_PROPERTY      = 0x00000004, // Any property
        UI_INVALIDATIONS_ALLPROPERTIES = 0x00000008  // All properties
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("ec053e6e-b059-4023-ae8b-33ed9f506599")]
    public interface IUIFramework
    {
        // Connects the framework and the application
        void Initialize(IntPtr frameWnd, IUIApplication application);

        // Releases all framework objects
        void Destroy();

        // Loads and instantiates the views and commands specified in markup
        void LoadUI(IntPtr instance, string resourceName);

        // Retrieves a pointer to a view object
        void GetView(int viewId, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, [MarshalAs(UnmanagedType.IUnknown)] out object ppv);

        // Retrieves the current value of a property
        void GetUICommandProperty(int commandId, [MarshalAs(UnmanagedType.LPStruct)] PROPERTYKEY key, out PROPVARIANT value);

        // Immediately sets the value of a property
        void SetUICommandProperty(int commandId, [MarshalAs(UnmanagedType.LPStruct)] PROPERTYKEY key, [MarshalAs(UnmanagedType.LPStruct)] PROPVARIANT value);

        // Asks the framework to retrieve the new value of a property at the next update cycle
        void InvalidateUICommand(int commandId, UI_INVALIDATIONS flags, [MarshalAs(UnmanagedType.LPStruct)] PROPERTYKEY key);

        // Flush all the pending UI command updates
        void FlushPendingInvalidations();

        // Asks the framework to switch to the list of modes specified and adjust visibility of controls accordingly
        void SetModes(int iModes);
    }

    [Guid("926749fa-2615-4987-8845-c33e65f2b957")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComImport]
    public class ScenicIntentUIFramework
    {
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("EEA11F37-7C46-437c-8E55-B52122B29293")]
    public interface IUIContextualUI
    {
        // Sets the desired anchor point where ContextualUI should be displayed.
        // Typically this is the mouse location at the time of right click.
        // x and y are in virtual screen coordinates.
        void ShowAtLocation(int x, int y);
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("DF4F45BF-6F9D-4dd7-9D68-D8F9CD18C4DB")]
    public interface IUICollection
    {
        // Retrieves the count of the collection
        void GetCount(out uint count);

        // Retrieves an item
        void GetItem(uint index, [MarshalAs(UnmanagedType.IUnknown)] out object item);

        // Adds an item to the end
        void Add([MarshalAs(UnmanagedType.IUnknown), In] object item);

        // Inserts an item
        void Insert(uint index, [MarshalAs(UnmanagedType.IUnknown), In] object item);

        // Removes an item at the specified position
        void RemoveAt(uint index);

        // Replaces an item at the specified position
        void Replace(uint indexReplaced, [MarshalAs(UnmanagedType.IUnknown), In] object itemReplaceWith);

        // Clear the collection
        void Clear();
    }

    [Serializable]
    public enum UI_COLLECTIONCHANGE
    {
        UI_COLLECTIONCHANGE_INSERT  = 0,
        UI_COLLECTIONCHANGE_REMOVE  = 1,
        UI_COLLECTIONCHANGE_REPLACE = 2,
        UI_COLLECTIONCHANGE_RESET   = 3,
    };

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("6502AE91-A14D-44b5-BBD0-62AACC581D52")]
    public interface IUICollectionChangedEvent
    {
        void OnChanged(UI_COLLECTIONCHANGE action, uint oldIndex, 
                      [MarshalAs(UnmanagedType.IUnknown), In] object oldItem, uint newIndex, 
                      [MarshalAs(UnmanagedType.IUnknown), In] object newItem);
    }


// Scenic Intent interfaces implemented by the application
    [Serializable]
    public enum UI_EXECUTIONVERB
    {
        UI_EXECUTIONVERB_EXECUTE       = 0,
        UI_EXECUTIONVERB_PREVIEW       = 1,
        UI_EXECUTIONVERB_CANCELPREVIEW = 2
    };

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("75ae0a2d-dc03-4c9f-8883-069660d0beb6")]
    public interface IUICommandHandler
    {
        // User action callback, with transient execution parameters
        void Execute(int commandId,                                                   // the command that has been executed
                     UI_EXECUTIONVERB verb,                                           // the mode of execution
                     [In] ref PROPERTYKEY key,             // the property that has changed
                     [In] ref PROPVARIANT currentValue,    // the new value of the property that has changed
                     IUISimplePropertySet commandExecutionProperties); // additional data for this execution

        // Informs of the current value of a property, and queries for the new one
        void UpdateProperty(int commandId, 
            [In] ref PROPERTYKEY key,
            [In] ref PROPVARIANT currentValue,
            [Out] out PROPVARIANT newValue);
    }

    // Types of UI commands
    [Serializable]
    public enum UI_COMMANDTYPE
    {
        UI_COMMANDTYPE_UNKNOWN                                       = 0,
        UI_COMMANDTYPE_GROUP                                         = 1,
        UI_COMMANDTYPE_ACTION                                        = 2,
        UI_COMMANDTYPE_ANCHOR                                        = 3,
        UI_COMMANDTYPE_CONTEXT                                       = 4,
        UI_COMMANDTYPE_COLLECTION                                    = 5,
        UI_COMMANDTYPE_COMMANDCOLLECTION                             = 6,
        UI_COMMANDTYPE_DECIMAL                                       = 7,
        UI_COMMANDTYPE_BOOLEAN                                       = 8,
        UI_COMMANDTYPE_FONT                                          = 9,
        UI_COMMANDTYPE_RECENTITEMS                                   = 10,
        UI_COMMANDTYPE_COLORANCHOR                                   = 11,
        UI_COMMANDTYPE_COLORCOLLECTION                               = 12,
    }

    // Types of UI Views
    [Serializable]
    public enum UI_VIEWTYPE
    {
        UI_VIEWTYPE_RIBBON   = 1,
    }

    public enum UI_VIEWVERB
    {
        UI_VIEWVERB_CREATE  = 0,
        UI_VIEWVERB_DESTROY = 1,
        UI_VIEWVERB_SIZE    = 2,
        UI_VIEWVERB_ERROR   = 3,
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("70667bb4-74aa-43a5-9dc1-58627007ec80")]
    public interface IUIApplication
    {
        // A view has changed
        void OnViewChanged(uint viewId, UI_VIEWTYPE typeID, 
                          [MarshalAs(UnmanagedType.IUnknown)] object view, 
                          UI_VIEWVERB verb, int uReasonCode);
     
        // Command creation callback
        void OnCreateUICommand(uint commandId, UI_COMMANDTYPE typeID, 
                    [MarshalAs(UnmanagedType.Interface)] out IUICommandHandler commandHandler);

        // Command destroy callback
        void OnDestroyUICommand(uint commandId,  UI_COMMANDTYPE typeID,
                                IUICommandHandler commandHandler);

    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("23c8c838-4de6-436b-ab01-5554bb7c30dd")]
    public interface IUIImage
    {
        void GetBitmap(out IntPtr bitmap);
    };

    [Serializable]
    public enum UI_OWNERSHIP
    {
        UI_OWNERSHIP_TRANSFER = 0, // IUIImage now owns HBITMAP.
        UI_OWNERSHIP_COPY     = 1, // IUIImage creates a copy of HBITMAP. Caller still owns HBITMAP.
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("18aba7f3-4c1c-4ba2-bf6c-f5c3326fa816")]
    public interface IUIImageFromBitmap
    {
        void CreateImage(IntPtr hBitmap, UI_OWNERSHIP options, out IUIImage image);
    }

    [Guid("0F7434B6-59B6-4250-999E-D168D6AE4293")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComImport]
    public class ScenicIntentUIImageFromBitmap
    {
    }
}
