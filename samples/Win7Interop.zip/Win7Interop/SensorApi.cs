﻿//
// Sensor API for Windows 7
//

using System;
using System.Runtime.InteropServices;

namespace Windows7.Interop
{
    public static class SensorProperties
    {
        public static PROPERTYKEY Type = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 2 };    
        public static PROPERTYKEY State = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 3 };    
        public static PROPERTYKEY SamplingRate = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 4 };    
        public static PROPERTYKEY PersistentUniqueID = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 5 };    
        public static PROPERTYKEY Manufacturer = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 6 };    
        public static PROPERTYKEY Model = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 7 };    
        public static PROPERTYKEY SerialNumber = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 8 };    
        public static PROPERTYKEY FriendlyName = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 9 };    
        public static PROPERTYKEY Description = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 10 };    
        public static PROPERTYKEY ConnectionType = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 11 };    
        public static PROPERTYKEY MinReportInterval = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 12 };    
        public static PROPERTYKEY CurrReportInterval = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 13 };    
        public static PROPERTYKEY ChangeSensitivity = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 14 };    
        public static PROPERTYKEY DevicePath = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 15 };    
        public static PROPERTYKEY LightResponseCurve = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 16 };    
        public static PROPERTYKEY Accuracy = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 17 };    
        public static PROPERTYKEY Resolution = new PROPERTYKEY { fmtid = new Guid("7F8383EC-D3EC-495C-A8CF-B8BBE85C2920"), pid = 18 };    
    }

    public static class SensorCategories
    {
        public static Guid All = new Guid("C317C286-C468-4288-9975-D4C4587C442C");
        public static Guid Location = new Guid("BFA794E4-F964-4fdb-90F6-51056BFE4B44");
        public static Guid Environmental = new Guid("323439AA-7F66-492b-BA0C-73E9AA0A65D5");
        public static Guid Motion = new Guid("CD09DAF1-3B2E-4c3d-B598-B5E5FF93FD46");
        public static Guid Orientation = new Guid("9E6C04B6-96FE-4954-B726-68682A473F69");
        public static Guid Mechanical = new Guid("8D131D68-8EF7-4656-80B5-CCCBD93791C5");
        public static Guid Electrical = new Guid("FB73FCD8-FC4A-483C-AC58-27B691C6BEFF");
        public static Guid Biometric = new Guid("CA19690F-A2C7-477D-A99E-99EC6E2B5648");
        public static Guid Light = new Guid("17A665C0-9063-4216-B202-5C7A255E18CE");
        public static Guid Scanner = new Guid("B000E77E-F5B5-420F-815D-0270A726F270");
    }

    public static class SensorTypes
    {
        //
        // Location Sensor Types
        //
        public static Guid Location_GPS = new Guid("ED4CA589-327A-4FF9-A560-91DA4B48275E");
        public static Guid Location_Static = new Guid("095F8184-0FA9-4445-8E6E-B70F320B6B4C");
        public static Guid Location_Lookup = new Guid("3B2EAE4A-72CE-436D-96D2-3C5B8570E987");
        public static Guid Location_Triangulation = new Guid("691C341A-5406-4FE1-942F-2246CBEB39E0");
        public static Guid Location_Other = new Guid("9B2D0566-0368-4F71-B88D-533F132031DE");
        //
        // Environmental Sensor types
        //
        public static Guid Environmental_Temeperature = new Guid("04FD0EC4-D5DA-45FA-95A9-5DB38EE19306");
        public static Guid Environmental_Atmospheric_Pressure = new Guid("0E903829-FF8A-4a93-97DF-3DCBDE402288");
        public static Guid Environmental_Humidity = new Guid("5C72BF67-BD7E-4257-990B-98A3BA3B400A");
        public static Guid Environmental_Wind_Speed = new Guid("DD50607B-A45F-42cd-8EFD-EC61761C4226");
        public static Guid Environmental_Wind_Direction = new Guid("9EF57A35-9306-434d-AF09-37FA5A9C00BD");
        //
        // Motion Sensor Types
        //
        public static Guid Accelerometer_1D = new Guid("C04D2387-7340-4cc2-991E-3B18CB8EF2F4");
        public static Guid Accelerometer_2D = new Guid("B2C517A8-F6B5-4ba6-A423-5DF560B4CC07");
        public static Guid Accelerometer_3D = new Guid("C2FB0F5F-E2D2-4c78-BCD0-352A9582819D");
        public static Guid Accelerometer_Motion_Detector = new Guid("5C7C1A12-30A5-43b9-A4B2-CF09EC5B7BE8");
        public static Guid Accelerometer_Gyrometer_1D = new Guid("FA088734-F552-4584-8324-EDFAF649652C");
        public static Guid Accelerometer_Gyrometer_2D = new Guid("31EF4F83-919B-48bf-8DE0-5D7A9D240556");
        public static Guid Accelerometer_Gyrometer_3D = new Guid("09485F5A-759E-42c2-BD4B-A349B75C8643");
        public static Guid Accelerometer_Speedometer = new Guid("6BD73C1F-0BB4-4310-81B2-DFC18A52BF94");
        //
        // Orientation Sensor Types
        //
        public static Guid Compass_1D = new Guid("A415F6C5-CB50-49d0-8E62-A8270BD7A26C");
        public static Guid Compass_2D = new Guid("15655CC0-997A-4d30-84DB-57CABA3648BB");
        public static Guid Compass_3D = new Guid("76B5CE0D-17DD-414d-93A1-E127F40BDF6E");
        public static Guid Inclinometer_1D = new Guid("B96F98C5-7A75-4ba7-94E9-AC868C966DD8");
        public static Guid Inclinometer_2D = new Guid("AB140F6D-83EB-4264-B70B-B16A5B256A01");
        public static Guid Inclinometer_3D = new Guid("B84919FB-EA85-4976-8444-6F6F5C6D31DB");
        public static Guid Distance_1D = new Guid("5F14AB2F-1407-4306-A93F-B1DBABE4F9C0");
        public static Guid Distance_2D = new Guid("5CF9A46C-A9A2-4e55-B6A1-A04AAFA95A92");
        public static Guid Distance_3D = new Guid("A20CAE31-0E25-4772-9FE5-96608A1354B2");
        //
        // Electrical Sensor Types
        //
        public static Guid Electric_Voltage = new Guid("C5484637-4FB7-4953-98B8-A56D8AA1FB1E");
        public static Guid Electric_Current = new Guid("5ADC9FCE-15A0-4bbe-A1AD-2D38A9AE831C");
        //
        // Mechanical Sensor Types
        //
        public static Guid Mechanical_BooleanSwitch = new Guid("9C7E371F-1041-460b-8D5C-71E4752E350C");
        public static Guid Mechanical_MultivalueSwitch = new Guid("B3EE4D76-37A4-4402-B25E-99C60A775FA1");
        public static Guid Mechanical_Force = new Guid("C2AB2B02-1A1C-4778-A81B-954A1788CC75");
        public static Guid Mechanical_Scale = new Guid("C06DD92C-7FEB-438e-9BF6-82207FFF5BB8");
        public static Guid Mechanical_Pressure = new Guid("26D31F34-6352-41cf-B793-EA0713D53D77");
        public static Guid Mechanical_Strain = new Guid("C6D1EC0E-6803-4361-AD3D-85BCC58C6D29");
        //
        // Biometric Sensor Types
        //
        public static Guid Biometric_Human_Presence = new Guid("C138C12B-AD52-451c-9375-87F518FF10C6");
        public static Guid Biometric_Human_Proximity = new Guid("5220DAE9-3179-4430-9F90-06266D2A34DE");
        public static Guid Biometric_Touch = new Guid("17DB3018-06C4-4f7d-81AF-9274B7599C27");
        //
        // Light Sensor Types
        //
        public static Guid Ambient_Light = new Guid("97F115C8-599A-4153-8894-D2D12899918A");
        //
        // Scanner Sensor Types
        //
        public static Guid RFID_Scanner = new Guid("44328EF5-02DD-4e8d-AD5D-9249832B2ECA");
        public static Guid Barcode_Scanner = new Guid("990B3D8F-85BB-45ff-914D-998C04F372DF");
    }

    public static class SensorDataTypes
    {
        public static PROPERTYKEY TimeStamp = new PROPERTYKEY {fmtid = new Guid("DB5E0CF2-CF1F-4C18-B46C-D86011D62150"), pid = 2};
    }

    public static class LocationSensorDataTypes
    {
        public static PROPERTYKEY Lattitude_Degrees = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 2 };
        public static PROPERTYKEY Longitude_Degrees = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 3 };
        public static PROPERTYKEY Altitude_SeaLevel_Meters = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 4 };
        public static PROPERTYKEY Altitude_Ellipsoid_Meters = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 5 };
        public static PROPERTYKEY Speed_Knots = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 6 };
        public static PROPERTYKEY True_Heading_Degrees = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 7 };
        public static PROPERTYKEY Magnetic_Heading_Degrees = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 8 };
        public static PROPERTYKEY Magnetic_Heading_Variation = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 9 };
        public static PROPERTYKEY Fix_Quality = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 10 };
        public static PROPERTYKEY Fix_Type = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 11 };
        public static PROPERTYKEY Position_Dilution_Of_Precision = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 12 };
        public static PROPERTYKEY Horizontal_Dilution_Of_Precision = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 13 };
        public static PROPERTYKEY Vertical_Dilution_Of_Precision = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 14 };
        public static PROPERTYKEY Satellites_Used_Count = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 15 };
        public static PROPERTYKEY Satellites_Used_PRNS = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 16 };
        public static PROPERTYKEY Satellites_In_View = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 17 };
        public static PROPERTYKEY Satellites_In_View_PRNS = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 18 };
        public static PROPERTYKEY Satellites_In_View_Elevation = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 19 };
        public static PROPERTYKEY Satellites_In_View_Azimuth = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 20 };
        public static PROPERTYKEY Satellites_In_View_STN_Ratio = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 21 };
        public static PROPERTYKEY Error_Radius_Meters = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 22 };
        public static PROPERTYKEY Address1 = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 23 };
        public static PROPERTYKEY Address2 = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 24 };
        public static PROPERTYKEY City = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 25 };
        public static PROPERTYKEY State_Province = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 26 };
        public static PROPERTYKEY PostalCode = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 27 };
        public static PROPERTYKEY Country_Region = new PROPERTYKEY {fmtid = new Guid("055C74D8-CA6F-47D6-95C6-1ED3637A0FF4"), pid = 28 };
    }

    public static class EnvironmentalSensorDataTypes
    {
        public static PROPERTYKEY Temperature_Celsius = new PROPERTYKEY { fmtid = new Guid("8B0AA2F1-2D57-42EE-8CC0-4D27622B46C4"), pid = 2 };
    }

    public static class MotionSensorDataTypes
    {
        // Accelerometer data types
        public static PROPERTYKEY Acceleration_X_G = new PROPERTYKEY { fmtid = new Guid("3F8A69A2-07C5-4e48-A965-CD797AAB56D5"), pid = 2 };
        public static PROPERTYKEY Acceleration_Y_G = new PROPERTYKEY { fmtid = new Guid("3F8A69A2-07C5-4e48-A965-CD797AAB56D5"), pid = 3 };
        public static PROPERTYKEY Acceleration_Z_G = new PROPERTYKEY { fmtid = new Guid("3F8A69A2-07C5-4e48-A965-CD797AAB56D5"), pid = 4 };
        // Gyrometer data types
        public static PROPERTYKEY Angular_Acceleration_X_Degrees_Per_Second = new PROPERTYKEY { fmtid = new Guid("3F8A69A2-07C5-4e48-A965-CD797AAB56D5"), pid = 5 };
        public static PROPERTYKEY Angular_Acceleration_Y_Degrees_Per_Second = new PROPERTYKEY { fmtid = new Guid("3F8A69A2-07C5-4e48-A965-CD797AAB56D5"), pid = 6 };
        public static PROPERTYKEY Angular_Acceleration_Z_Degrees_Per_Second = new PROPERTYKEY { fmtid = new Guid("3F8A69A2-07C5-4e48-A965-CD797AAB56D5"), pid = 7 };
    }

    public static class OrientationSensorDataTypes
    {
        // Inclinometer data types
        public static PROPERTYKEY Angle_X_Degrees = new PROPERTYKEY { fmtid = new Guid("1637D8A2-4248-4275-865D-558DE84AEDFD"), pid = 2 };
        public static PROPERTYKEY Angle_Y_Degrees = new PROPERTYKEY { fmtid = new Guid("1637D8A2-4248-4275-865D-558DE84AEDFD"), pid = 3 };
        public static PROPERTYKEY Angle_Z_Degrees = new PROPERTYKEY { fmtid = new Guid("1637D8A2-4248-4275-865D-558DE84AEDFD"), pid = 4 };
        // Compass data types
        public static PROPERTYKEY Magnetic_Heading_X_Degrees = new PROPERTYKEY { fmtid = new Guid("1637D8A2-4248-4275-865D-558DE84AEDFD"), pid = 5 };
        public static PROPERTYKEY Magnetic_Heading_Y_Degrees = new PROPERTYKEY { fmtid = new Guid("1637D8A2-4248-4275-865D-558DE84AEDFD"), pid = 6 };
        public static PROPERTYKEY Magnetic_Heading_Z_Degrees = new PROPERTYKEY { fmtid = new Guid("1637D8A2-4248-4275-865D-558DE84AEDFD"), pid = 7 };
        // Distance data types
        public static PROPERTYKEY Distance_X_Meters = new PROPERTYKEY { fmtid = new Guid("1637D8A2-4248-4275-865D-558DE84AEDFD"), pid = 8 };
        public static PROPERTYKEY Distance_Y_Meters = new PROPERTYKEY { fmtid = new Guid("1637D8A2-4248-4275-865D-558DE84AEDFD"), pid = 9 };
        public static PROPERTYKEY Distance_Z_Meters = new PROPERTYKEY { fmtid = new Guid("1637D8A2-4248-4275-865D-558DE84AEDFD"), pid = 10 };
    }

    public static class MechanicalSensorDataTypes
    {
        public static PROPERTYKEY Boolean_Switch_State = new PROPERTYKEY { fmtid = new Guid("38564A7C-F2F2-49bb-9B2B-BA60F66A58DF"), pid = 2 };
        public static PROPERTYKEY MultiValue_Switch_State = new PROPERTYKEY { fmtid = new Guid("38564A7C-F2F2-49bb-9B2B-BA60F66A58DF"), pid = 3 };
        public static PROPERTYKEY Force_Newtons = new PROPERTYKEY { fmtid = new Guid("38564A7C-F2F2-49bb-9B2B-BA60F66A58DF"), pid = 4 };
        public static PROPERTYKEY Weight_Kilograms = new PROPERTYKEY { fmtid = new Guid("38564A7C-F2F2-49bb-9B2B-BA60F66A58DF"), pid = 5 };
        public static PROPERTYKEY Pressure_Pascal = new PROPERTYKEY { fmtid = new Guid("38564A7C-F2F2-49bb-9B2B-BA60F66A58DF"), pid = 6 };
        public static PROPERTYKEY Strain = new PROPERTYKEY { fmtid = new Guid("38564A7C-F2F2-49bb-9B2B-BA60F66A58DF"), pid = 7 };
    }

    public static class BiometricSensorDataTypes
    {
        public static PROPERTYKEY Human_Presence = new PROPERTYKEY { fmtid = new Guid("2299288A-6D9E-4b0b-B7EC-3528F89E40AF"), pid = 2 };
        public static PROPERTYKEY Human_Proximity_Meters = new PROPERTYKEY { fmtid = new Guid("2299288A-6D9E-4b0b-B7EC-3528F89E40AF"), pid = 3 };
    }

    public static class LightSensorDataTypes
    {
       // Ambient light in LUX, Lumens per square meter, the ACPI convention for reporting ambient light values
        public static PROPERTYKEY Light_Level_Lux = new PROPERTYKEY { fmtid = new Guid("E4C77CE2-DCB7-46e9-8439-4FEC548833A6"), pid = 2 };
        public static PROPERTYKEY Light_Temperature_Kelvin = new PROPERTYKEY { fmtid = new Guid("E4C77CE2-DCB7-46e9-8439-4FEC548833A6"), pid = 3 };
        public static PROPERTYKEY Light_Chromacity = new PROPERTYKEY { fmtid = new Guid("E4C77CE2-DCB7-46e9-8439-4FEC548833A6"), pid = 4 };
    }

    public static class ScannerSensorDataTypes
    {
        public static PROPERTYKEY RFID_Tag_40bit = new PROPERTYKEY { fmtid = new Guid("D7A59A3C-3421-44ab-8D3A-9DE8AB6C4CAE"), pid = 2 };
    }

    [Serializable]
    public enum SensorState
    {	
        SENSOR_STATE_MIN	= 0,
	    SENSOR_STATE_READY	= SENSOR_STATE_MIN,
	    SENSOR_STATE_NOT_AVAILABLE	= ( SENSOR_STATE_READY + 1 ) ,
	    SENSOR_STATE_NO_DATA	= ( SENSOR_STATE_NOT_AVAILABLE + 1 ) ,
	    SENSOR_STATE_INITIALIZING	= ( SENSOR_STATE_NO_DATA + 1 ) ,
	    SENSOR_STATE_ACCESS_DENIED	= ( SENSOR_STATE_INITIALIZING + 1 ) ,
	    SENSOR_STATE_ERROR	= ( SENSOR_STATE_ACCESS_DENIED + 1 ) ,
	    SENSOR_STATE_MAX	= SENSOR_STATE_ERROR
    }

    [Serializable]
    public enum SensorConnectionType
    {	
        SENSOR_CONNECTION_TYPE_PC_INTEGRATED	= 0,
	    SENSOR_CONNECTION_TYPE_PC_ATTACHED	= ( SENSOR_CONNECTION_TYPE_PC_INTEGRATED + 1 ) ,
	    SENSOR_CONNECTION_TYPE_PC_EXTERNAL	= ( SENSOR_CONNECTION_TYPE_PC_ATTACHED + 1 ) 
    }
   
    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("BD77DB67-45A8-42DC-8D00-6DCF15F8377A")]
    public interface ISensorManager
    {
        void GetSensorsByCategory([MarshalAs(UnmanagedType.LPStruct)] Guid sensorCategory, out ISensorCollection ppSensorsFound);
        void GetSensorsByType([MarshalAs(UnmanagedType.LPStruct)] Guid sensorType, out ISensorCollection ppSensorsFound); 
        void GetSensorByID([MarshalAs(UnmanagedType.LPStruct)] Guid sensorID,  out ISensorCollection ppSensorsFound);
        void SetEventSink(ISensorManagerEvents pEvents);
        void RequestPermissions(IntPtr hwndParent, ISensorCollection pSensors, bool fModal); 
    }

    [Guid("77A1C827-FCD2-4689-8915-9D613CC5FA3E")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComImport]
    public class SensorManager
    {
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("23571E11-E545-4DD8-A337-B89BF44B10DF")]
    public interface ISensorCollection
    {
        void GetAt(uint index, out ISensor ppSensor);
        void GetCount(out uint pCount);
        void Add(ISensor pSensor); 
        void Remove(ISensor pSensor);
        void RemoveByID([MarshalAs(UnmanagedType.LPStruct)] Guid sensorID);
        void Clear();
    }

    [Guid("79C43ADB-A429-469F-AA39-2F2B74B75937")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComImport]
    public class SensorCollection
    {
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("5FA08F80-2657-458E-AF75-46F73FA6AC5C")]
    public interface ISensor
    {
        void GetID(out Guid sensorID);
        void GetCategory(out Guid sensorCategory);
        void GetType(out Guid sensorType); 
        void GetFriendlyName([MarshalAs(UnmanagedType.BStr)] out string friendlyName);
        void GetProperty(ref PROPERTYKEY key, out PROPVARIANT property);
        void GetProperties(IPortableDeviceKeyCollection keys, out IPortableDeviceValues ppValues);
        void GetSupportedDataFields(out IPortableDeviceKeyCollection ppDataFields);
        void SetProperties(IPortableDeviceValues pProperties, out IPortableDeviceValues ppResults);
        void SupportsDataField(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.VariantBool)] out bool isSupported);
        void GetState(out SensorState pState);
        void GetData(out ISensorDataReport ppDataReport);
        void SupportsEvent([MarshalAs(UnmanagedType.LPStruct)] Guid eventGuid, [MarshalAs(UnmanagedType.VariantBool)] out bool isSupported);
        void GetEventInterest([MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 1)] out Guid[] ppValues, out uint count);
        void SetEventInterest(Guid[] pValues, uint count);
        void SetEventSink(ISensorEvents pEvents); 
    }

    [Guid("E97CED00-523A-4133-BF6F-D3A2DAE7F6BA")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComImport]
    public class Sensor
    {
    }

    [Serializable, StructLayout(LayoutKind.Sequential)]
    public struct SYSTEMTIME 
    {
        public short wYear;
        public short wMonth;
        public short wDayOfWeek;
        public short wDay;
        public short wHour;
        public short wMinute;
        public short wSecond;
        public short wMilliseconds;

        public static implicit operator DateTime(SYSTEMTIME st)
        {
            return new DateTime(st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
        }
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("0AB9DF9B-C4B5-4796-8898-0470706A2E1D")]
    public interface ISensorDataReport
    {
        void GetTimestamp(out SYSTEMTIME timeStamp);
        void GetSensorValue(ref PROPERTYKEY pKey, out PROPVARIANT pValue);
        void GetSensorValues(IPortableDeviceKeyCollection pKeys, out IPortableDeviceValues ppValues); 
    }

    [Guid("4EA9D6EF-694B-4218-8816-CCDA8DA74BBA")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComImport]
    public class SensorDataReport
    {
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("9B3B0B86-266A-4AAD-B21F-FDE5501001B7")]
    public interface ISensorManagerEvents
    {
        void OnSensorEnter(ISensor pSensor, SensorState state); 
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("5D8DCC91-4641-47E7-B7C3-B74F48A6C391")]
    public interface ISensorEvents
    {
        void OnStateChanged(ISensor pSensor, SensorState state);
        void OnDataUpdated(ISensor sensor, ISensorDataReport pNewData);
        void OnEvent(ISensor pSensor, [MarshalAs(UnmanagedType.LPStruct)] Guid eventID, IPortableDeviceValues pEventData);
        void OnLeave([MarshalAs(UnmanagedType.LPStruct)] Guid sensorID); 
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("7490B4D4-1BE9-469A-9743-37A27C1D80AF")]
    public interface ILogicalSensorManager
    {
        void Connect([MarshalAs(UnmanagedType.LPStruct)] Guid logicalID, IPropertyStore pPropertyStore);
        void Uninstall([MarshalAs(UnmanagedType.LPStruct)] Guid logicalID);
        void Disconnect([MarshalAs(UnmanagedType.LPStruct)] Guid logicalID); 
    }

    [Guid("50A7B286-7D23-41E6-9440-4DAEE00DC5F0")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComImport]
    public class LogicalSensorManager
    {
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("6848f6f2-3155-4f86-b6f5-263eeeab3143")]
    public interface IPortableDeviceValues
    {
        void GetCount(out uint count);
        void GetAt(uint index, out PROPERTYKEY pKey, out PROPVARIANT pValue);
        void SetValue(ref PROPERTYKEY key, ref PROPVARIANT pValue);
        void GetValue(ref PROPERTYKEY key, out PROPVARIANT pValue);
        void SetStringValue(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.LPWStr)] string value);
        void GetStringValue(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.LPWStr)] out string value);
        void SetUnsignedIntegerValue(ref PROPERTYKEY key, uint value);
        void GetUnsignedIntegerValue(ref PROPERTYKEY key, out uint value);
        void SetSignedIntegerValue(ref PROPERTYKEY key, int value);
        void GetSignedIntegerValue(ref PROPERTYKEY key, out int value);
        void SetUnsignedLargeIntegerValue(ref PROPERTYKEY key, ulong value);
        void GetUnsignedLargeIntegerValue(ref PROPERTYKEY key, out ulong value);
        void SetSignedLargeIntegerValue(ref PROPERTYKEY key, long value);
        void GetSignedLargeIntegerValue(ref PROPERTYKEY key, out long value);
        void SetFloatValue(ref PROPERTYKEY key, float value);
        void GetFloatValue(ref PROPERTYKEY key, out float value);
        void SetErrorValue(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.Error)] uint error);
        void GetErrorValue(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.Error)] out uint error);
        void SetKeyValue(ref PROPERTYKEY key, ref PROPERTYKEY value);
        void GetKeyValue(ref PROPERTYKEY key, out PROPERTYKEY pValue);
        void SetBoolValue(ref PROPERTYKEY key, bool value);
        void GetBoolValue(ref PROPERTYKEY key, out bool value);
        void SetIUnknownValue(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.IUnknown)] object value);
        void GetIUnknownValue(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.IUnknown)] out object value);
        void SetGuidValue(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.LPStruct)] Guid value);
        void GetGuidValue(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.LPStruct)] out Guid value);
        void SetBufferValue(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 2)] byte[] pValue, int count);
        void GetBufferValue(ref PROPERTYKEY key, [MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 2), Out] out byte[] pValue, out int count);
        void SetIPortableDeviceValuesValue(ref PROPERTYKEY key, IPortableDeviceValues value);
        void GetIPortableDeviceValuesValue(ref PROPERTYKEY key, out IPortableDeviceValues value);
        void SetIPortableDevicePropVariantCollectionValue(ref PROPERTYKEY key, IPortableDevicePropVariantCollection value);
        void GetIPortableDevicePropVariantCollectionValue(ref PROPERTYKEY key, out IPortableDevicePropVariantCollection value);
        void SetIPortableDeviceKeyCollectionValue(ref PROPERTYKEY key, IPortableDeviceKeyCollection value);
        void GetIPortableDeviceKeyCollectionValue(ref PROPERTYKEY key, out IPortableDeviceKeyCollection value);
        void SetIPortableDeviceValuesCollectionValue(ref PROPERTYKEY key, IPortableDeviceValuesCollection value);
        void GetIPortableDeviceValuesCollectionValue(ref PROPERTYKEY key, out IPortableDeviceValuesCollection value);
        void RemoveValue(ref PROPERTYKEY key);
        void CopyValuesFromPropertyStore(IPropertyStore store);
        void CopyValuesToPropertyStore(IPropertyStore store);
        void Clear();
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("89b2e422-4f1b-4316-bcef-a44afea83eb3")]
    public interface IPortableDevicePropVariantCollection
    {
        void GetCount(out uint count);
        void GetAt(uint index, out PROPVARIANT pValue);
        void Add(PROPVARIANT value);
        void GetType(out VarEnum pvt);
        void ChangeType(VarEnum vt);
        void Clear();
        void RemoveAt(uint index); 
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("dada2357-e0ad-492e-98db-dd61c53ba353")]
    public interface IPortableDeviceKeyCollection
    {
        void GetCount(out uint count);
        void GetAt(uint index, out PROPERTYKEY key);
        void Add(PROPERTYKEY key);
        void Clear();
        void RemoveAt(uint index); 
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("6e3f2d79-4e07-48c4-8208-d8c2e5af4a99")]
    public interface IPortableDeviceValuesCollection
    {
        void GetCount(out int count);
        void GetAt(uint index, out IPortableDeviceValues pValues);
        void Add(IPortableDeviceValues value);
        void Clear();
        void RemoveAt(uint index); 
    }
}