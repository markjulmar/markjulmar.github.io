﻿using System;
using System.Runtime.InteropServices;

namespace Windows7.Interop
{
    /// <summary>
    /// These are property settings set via SetProp(MICROSOFT_TABLETPENSERVICE_PROPERTY)
    /// </summary>
    [Flags, Serializable]
    public enum TabletSettings
    {
        TABLET_DISABLE_PRESSANDHOLD        = 0x00000001,
        TABLET_DISABLE_PENTAPFEEDBACK      = 0x00000008,
        TABLET_DISABLE_PENBARRELFEEDBACK   = 0x00000010,
        TABLET_DISABLE_TOUCHUIFORCEON      = 0x00000100,
        TABLET_DISABLE_TOUCHUIFORCEOFF     = 0x00000200,
        TABLET_DISABLE_TOUCHSWITCH         = 0x00008000,
        TABLET_DISABLE_FLICKS              = 0x00010000,
        TABLET_ENABLE_FLICKSONCONTEXT      = 0x00020000,
        TABLET_ENABLE_FLICKLEARNINGMODE    = 0x00040000,
        TABLET_DISABLE_SMOOTHSCROLLING     = 0x00080000,
        TABLET_DISABLE_FLICKFALLBACKKEYS   = 0x00100000,
        TABLET_ENABLE_MULTITOUCHDATA       = 0x01000000,
        TABLET_ENABLE_ROTATEGESTURE        = 0x02000000
    }

    /// <summary>
    /// RegisterTouchWindow flags
    /// </summary>
    [Flags, Serializable]
    public enum RegisterTouchFlags
    {
        /// <summary>
        /// Coalesce events (normal processing)
        /// </summary>
        TWF_NONE      = 0x00000000,
        /// <summary>
        /// Do not coalesce events
        /// </summary>
        TWF_FINETOUCH = 0x00000001  
    }

    /// <summary>
    /// Type of touch occuring
    /// </summary>
    [Flags, Serializable]
    public enum TouchEventFlags
    {
        /// <summary>
        /// Contact Move
        /// </summary>
        TOUCHEVENTF_MOVE = 0x0001,
        /// <summary>
        /// Contact Down
        /// </summary>
        TOUCHEVENTF_DOWN = 0x0002,
        /// <summary>
        /// Contact up
        /// </summary>
        TOUCHEVENTF_UP = 0x0004,
        /// <summary>
        /// Contact in range
        /// </summary>
        TOUCHEVENTF_INRANGE = 0x0008,
        /// <summary>
        /// Primary contact
        /// </summary>
        TOUCHEVENTF_PRIMARY = 0x0010,
        /// <summary>
        /// Event not coalesced
        /// </summary>
        TOUCHEVENTF_NOCOALESCE = 0x0020,
        /// <summary>
        /// Event from pen
        /// </summary>
        TOUCHEVENTF_PEN = 0x0040,
    }

    /// <summary>
    /// Event flags for touch events
    /// </summary>
    [Flags, Serializable]
    public enum TouchEventMask
    {
        /// <summary>
        /// dwTime field contains a system generated value
        /// </summary>
        TOUCHINPUTMASKF_TIMEFROMSYSTEM  = 0x0001,
        /// <summary>
        /// dwExtraInfo field is valid
        /// </summary>
        TOUCHINPUTMASKF_EXTRAINFO       = 0x0002,
        /// <summary>
        /// cxContact and cyContact fields are valid
        /// </summary>
        TOUCHINPUTMASKF_CONTACTAREA     = 0x0004,
    }

    /// <summary>
    /// Represents an X/Y point in 16-bit values
    /// </summary>
    [Serializable, StructLayout(LayoutKind.Sequential)]
    public struct POINTS
    {
        /// <summary>
        /// X coordinate
        /// </summary>
        public short X;
        /// <summary>
        /// Y coordinate
        /// </summary>
        public short Y;
    }

    /// <summary>
    /// Represents an X/Y point in 32-bit values
    /// </summary>
    [Serializable, StructLayout(LayoutKind.Sequential)]
    public struct POINT
    {
        /// <summary>
        /// X coordinate
        /// </summary>
        public int X;
        /// <summary>
        /// Y coordinate
        /// </summary>
        public int Y;
    }

    /// <summary>
    /// Touch event parameters
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct TOUCHINPUT
    {
        /// <summary>
        /// X coordinate in 100ths of a pixel (screen coordinates)
        /// </summary>
        public int X;
        /// <summary>
        /// Y coordinate in 100ths of a pixel (screen coordinates)
        /// </summary>
        public int Y;
        /// <summary>
        /// HWND where touch occurred
        /// </summary>
        public IntPtr hSource;
        /// <summary>
        /// Unique touch ID
        /// </summary>
        public uint dwID;
        /// <summary>
        /// Touch flags
        /// </summary>
        [MarshalAs(UnmanagedType.U4)] public TouchEventFlags dwFlags;
        /// <summary>
        /// Touch mask flags
        /// </summary>
        [MarshalAs(UnmanagedType.U4)] public TouchEventMask dwMask;
        /// <summary>
        /// Time (ticks) of event
        /// </summary>
        public uint dwTime;
        /// <summary>
        /// Parameters for touch
        /// </summary>
        public IntPtr dwExtraInfo;
        /// <summary>
        /// Size of contact
        /// </summary>
        public int cxContact;
        /// <summary>
        /// Size of contact
        /// </summary>
        public int cyContact;
    }

    /// <summary>
    /// RegisterGestureWindow flags
    /// </summary>
    [Flags, Serializable]
    public enum RegisterGestureFlags
    {
        GHWF_FINAL = 0x00000001    
    }

    /// <summary>
    /// Gesture flags - GESTUREINFO.dwFlags
    /// </summary>
    [Flags, Serializable]
    public enum GestureFlags
    {
        /// <summary>
        /// Gesture beginning
        /// </summary>
        GF_BEGIN = 0x00000001,
        /// <summary>
        /// Touch completed - inertia from touch continuing
        /// </summary>
        GF_INERTIA = 0x00000002,
        /// <summary>
        /// Gesture ending
        /// </summary>
        GF_END = 0x00000004
    }

    /// <summary>
    /// Gesture IDs
    /// </summary>
    [Serializable]
    public enum GestureID
    {
        /// <summary>
        /// All gesture types
        /// </summary>
        GID_ALL = 0,
        /// <summary>
        /// Gesture beginning (type unknown)
        /// </summary>
        GID_BEGIN = 1,
        /// <summary>
        /// Gesture ending
        /// </summary>
        GID_END = 2,
        /// <summary>
        /// Zoom gesture
        /// </summary>
        GID_ZOOM = 3,
        /// <summary>
        /// Pan (move) gesture
        /// </summary>
        GID_PAN = 4,
        /// <summary>
        /// Rotate gesture
        /// </summary>
        GID_ROTATE = 5,
        /// <summary>
        /// Two finger gesture
        /// </summary>
        GID_TWOFINGERTAP = 6,
        /// <summary>
        /// Rollover gesture
        /// </summary>
        GID_ROLLOVER = 7,
    }

    /// <summary>
    /// Gesture configuration values for GetGestureConfig
    /// </summary>
    [Serializable, Flags]
    public enum GestureConfigFlags
    {
        /// <summary>
        /// Specifies synchronous operation. The uTimeout parameter is considered valid and the 
        /// function does not return until a response is received or until a timeout occurs. 
        /// </summary>
        GCF_SYNC            = 0x0001,
        /// <summary>
        /// If the specified target window is blocked, the API function fails with either 
        /// ERROR_TIMEOUT or a new error code indicating the operation failed because the window 
        /// or thread is blocked.
        /// </summary>
        GCF_ABORTIFHUNG     = 0x0002,
        /// <summary>
        /// If the specified target window or any window in the target window's parent chain is 
        /// blocked, the API function fails with either the error code ERROR_TIMEOUT or a new 
        /// error code indicating the operation failed because the window or thread is blocked. 
        /// </summary>
        GCF_ABORTIFHUNGANY  = 0x0004,
    }

    /// <summary>
    /// Gesture configuration flags - GESTURECONFIG.dwWant or GESTURECONFIG.dwBlock
    /// </summary>
    [Flags, Serializable]
    public enum WantGestures
    {
        /// <summary>
        /// No gestures blocked or wanted
        /// </summary>
        GC_NONE = 0,
        /// <summary>
        /// All gestures blocked or wanted
        /// </summary>
        GC_ANY = 1,
        /// <summary>
        /// Pan with single finger vertically
        /// </summary>
        GC_PAN_WITH_SINGLE_FINGER_VERTICALLY = 0x00000002,
        /// <summary>
        /// Pan with single finger horizontally
        /// </summary>
        GC_PAN_WITH_SINGLE_FINGER_HORIZONTALLY = 0x00000004,
        /// <summary>
        /// Add gutter to edge of pan
        /// </summary>
        GC_PAN_WITH_GUTTER = 0x00000008,
        /// <summary>
        /// Inertia events follow touch up on PAN gesture
        /// </summary>
        GC_PAN_WITH_INERTIA = 0x00000010
    }

    /// <summary>
    /// Gesture configuration structure
    ///  - Used in SetGestureConfig and GetGestureConfig
    ///  - Note that any setting not included in either GESTURECONFIG.dwWant or
    ///    GESTURECONFIG.dwBlock will use the parent window's preferences or
    ///    system defaults.
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct GESTURECONFIG
    {
        /// <summary>
        /// Gesture ID (type)
        /// </summary>
        [MarshalAs(UnmanagedType.U4)] public GestureID dwID;
        /// <summary>
        /// Settings related to gesture ID that are to be turned on
        /// </summary>
        [MarshalAs(UnmanagedType.U4)] public WantGestures dwWant;
        /// <summary>
        /// Settings related to gesture ID that are to be turned off
        /// </summary>
        [MarshalAs(UnmanagedType.U4)] public WantGestures dwBlock;
    }

    /// <summary>
    /// Gesture information structure
    ///   - Pass the HGESTUREINFO received in the WM_GESTURE message lParam into the
    ///     GetGestureInfo function to retrieve this information.
    ///   - If cbExtraArgs is non-zero, pass the HGESTUREINFO received in the WM_GESTURE
    ///     message lParam into the GetGestureExtraArgs function to retrieve extended
    ///     argument information.
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct GESTUREINFO
    {
        /// <summary>
        /// sizeof(GESTUREINFO)
        /// </summary>
        public int cbSize;                                           
        /// <summary>
        /// see GF_* flags
        /// </summary>
        [MarshalAs(UnmanagedType.U4)] public GestureFlags dwFlags;     
        /// <summary>
        /// gesture ID (type)
        /// </summary>
        [MarshalAs(UnmanagedType.U4)] public GestureID dwID;           
        /// <summary>
        /// Window targeted by gesture
        /// </summary>
        public IntPtr hwndTarget;                                       
        /// <summary>
        /// Location of gesture in screen coordinates
        /// </summary>
        public POINTS ptsLocation;                                     
        /// <summary>
        /// Internally used but represents unique ID for gesture
        /// </summary>
        public uint dwInstanceID;                                      
        /// <summary>
        /// Internally used
        /// </summary>
        public uint dwSequenceID;                                    
        /// <summary>
        /// Arguments for gestures whose arguments fit in 8 BYTES
        /// </summary>
        [MarshalAs(UnmanagedType.U8)] public long ullArguments;    
        /// <summary>
        /// Size, in bytes, of extra arguments, if any, that accompany this gesture
        /// </summary>
        public uint cbExtraArgs;                                       
    }

    /// <summary>
    /// Gesture notification structure
    ///   - The WM_GESTURENOTIFY message lParam contains a pointer to this structure.
    ///   - The WM_GESTURENOTIFY message notifies a window that gesture recognition is
    ///     in progress and a gesture will be generated if one is recognized under the
    ///     current gesture settings.
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct GESTURENOTIFYSTRUCT
    {
        /// <summary>
        /// Size, in bytes, of this structure
        /// </summary>
        public int cbSize;              
        /// <summary>
        /// Unused - must be zero
        /// </summary>
        public uint dwFlags;
        /// <summary>
        /// Handle to window targeted by the gesture
        /// </summary>
        public IntPtr hwndTarget;     
        /// <summary>
        /// Starting location in screen coordinates
        /// </summary>
        public POINTS ptsLocation;      
        /// <summary>
        /// Internally used but represented unique ID for gesture
        /// </summary>
        public uint dwInstanceID;       
    }
}
