// *****************************************************************************
// * This is an automatically generated header file for UI Element definition  *
// * resource symbols and values. Please do not modify manually.               *
// *****************************************************************************

#pragma once

#define tabHome 2 
#define tabHome_LabelTitle_RESID 60001
#define grpMain 3 
#define grpMain_LabelTitle_RESID 60002
#define grpColors 4 
#define grpColors_LabelTitle_RESID 60003
#define cmdColors 100 
#define cmdColors_LabelTitle_RESID 60004
#define cmdColors_TooltipTitle_RESID 60005
#define cmdColors_TooltipDescription_RESID 60006
#define cmdColors_SmallImages_RESID 60007
#define cmdHelp 101 
#define cmdHelp_LabelTitle_RESID 60008
#define cmdSpinner 102 
#define cmdSpinner_LabelTitle_RESID 60009
#define cmdExit 103 
#define cmdExit_LabelTitle_RESID 60010
#define cmdExit_Keytip_RESID 60011
#define cmdExit_TooltipTitle_RESID 60012
#define cmdExit_TooltipDescription_RESID 60013
#define cmdExit_LargeImages_RESID 60014
#define cmdClear 104 
#define cmdClear_LabelTitle_RESID 60015
#define cmdClear_Keytip_RESID 60016
#define cmdClear_TooltipTitle_RESID 60017
#define cmdClear_TooltipDescription_RESID 60018
#define cmdClear_SmallImages_RESID 60019
#define cmdClear_LargeImages_RESID 60020
#define recentItems 5 
#define recentItems_LabelTitle_RESID 60021
#define QAT 6 
#define QAT_LabelTitle_RESID 60022
#define customizeQAT 7 
#define customizeQAT_LabelTitle_RESID 60023
#define InternalCmd2_LabelTitle_RESID 60024
