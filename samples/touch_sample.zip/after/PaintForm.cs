﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Windows7.Interop;

namespace WinForms
{
    public partial class PaintForm : Form, IUIApplication, IUICommandHandler
    {
        private int _strokeSize = 2;
        private Color _currentColor = Color.Black;
        private IUIFramework _ribbonFW;

        /// <summary>
        /// This structure is used to track points (touches)
        /// </summary>
        class PointInfo : IDisposable
        {
            public List<Point> Points { get; private set; }
            public Pen Color { get; private set; }

            public PointInfo(int strokeSize, Color clr)
            {
                Points = new List<Point>();
                Color = new Pen(clr, strokeSize);
            }

            public void Dispose()
            {
                Color.Dispose();
            }
        }

        private readonly Dictionary<uint, PointInfo> activePts = new Dictionary<uint, PointInfo>();
        private readonly List<PointInfo> completedLines = new List<PointInfo>();

        public PaintForm()
        {
            Load += Form1_Load;
            InitializeComponent();
        }

        void Form1_Load(object sender, EventArgs e)
        {
            // Create the ribbon
            _ribbonFW = (IUIFramework) new ScenicIntentUIFramework();
            _ribbonFW.Initialize(Handle, this);
            _ribbonFW.LoadUI(NativeMethods.GetModuleHandle(null), "APPLICATION_RIBBON");

            // Register this as touch target
            if (!NativeMethods.RegisterTouchWindow(Handle, RegisterTouchFlags.TWF_FINETOUCH))
                MessageBox.Show(string.Format("Failed to register touch window - {0:X}", Marshal.GetLastWin32Error()));

            // Turn on multi-touch
            if (!NativeMethods.SetProp(Handle, NativeMessages.MICROSOFT_TABLETPENSERVICE_PROPERTY,
                        new IntPtr((int)TabletSettings.TABLET_ENABLE_MULTITOUCHDATA)))
                MessageBox.Show(string.Format("Failed to register multi-touch support - {0:X}", Marshal.GetLastWin32Error()));
        }

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case NativeMessages.WM_TOUCHDOWN:
                case NativeMessages.WM_TOUCHUP:
                case NativeMessages.WM_TOUCHMOVE:
                    OnTouch(m.WParam.ToInt32(), m.LParam);
                    return;
            }
            base.WndProc(ref m);
        }


        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            foreach (var ptEntry in completedLines.Concat(activePts.Values))
            {
                if (ptEntry.Points.Count > 1)
                    e.Graphics.DrawLines(ptEntry.Color, ptEntry.Points.ToArray());
            }
        }

        void OnTouch(int count, IntPtr touchMsg)
        {
            var tips = new TOUCHINPUT[count];
            if (NativeMethods.GetTouchInputInfo(touchMsg, count, tips, 
                            Marshal.SizeOf(new TOUCHINPUT())))
            {
                using (var rgn = new Region())
                {
                    for (int i = 0; i < tips.Length; i++)
                    {
                        var touch = tips[i];

                        PointInfo ptInfo;
                        if (!activePts.TryGetValue(touch.dwID, out ptInfo))
                        {
                            ptInfo = new PointInfo(_strokeSize, _currentColor);
                            activePts.Add(touch.dwID, ptInfo);
                        }

                        if ((touch.dwFlags & (TouchEventFlags.TOUCHEVENTF_DOWN | TouchEventFlags.TOUCHEVENTF_MOVE)) > 0)
                        {
                            ptInfo.Points.Add(ConvertPoint(touch.X, touch.Y));
                            RectangleF? invalidBox = GetBoundingRectangle(ptInfo.Points);
                            if (invalidBox != null)
                            {
                                invalidBox.Value.Inflate(20,20);
                                if (i == 0)
                                    rgn.Intersect(invalidBox.Value);
                                else
                                    rgn.Union(invalidBox.Value);
                            }
                        }
                        else if ((touch.dwFlags & TouchEventFlags.TOUCHEVENTF_UP) > 0)
                        {
                            activePts.Remove(touch.dwID);
                            if (ptInfo.Points.Count > 1)
                                completedLines.Add(ptInfo);
                            else
                                ptInfo.Dispose();
                        }
                    }
                    Invalidate(rgn);
                }
            }
            NativeMethods.CloseTouchInputHandle(touchMsg);
        }

        private Point ConvertPoint(int x, int y)
        {
            var pt = new POINT { X = x/100, Y = y/100 };
            NativeMethods.ScreenToClient(Handle, ref pt);
            return new Point(pt.X, pt.Y);
        }

        private static RectangleF? GetBoundingRectangle(ICollection<Point> list)
        {
            using(var path = new GraphicsPath())
            {
                if (list.Count > 1)
                {
                    path.AddLines(list.Skip(list.Count - 2).ToArray());
                    var rect = path.GetBounds();
                    rect.Inflate(10f,10f);
                    return rect;
                }
            }
            return null;
        }

        #region IUIApplication Members

        public void OnCreateUICommand(uint commandId, UI_COMMANDTYPE typeID, out IUICommandHandler commandHandler)
        {
            commandHandler = this;
        }

        public void OnDestroyUICommand(uint commandId, UI_COMMANDTYPE typeID, IUICommandHandler commandHandler)
        {
            throw new NotImplementedException();
        }

        public void OnViewChanged(uint viewId, UI_VIEWTYPE typeID, object view, UI_VIEWVERB verb, int uReasonCode)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IUICommandHandler Members

        public void Execute(int commandId, UI_EXECUTIONVERB verb, ref PROPERTYKEY key, ref PROPVARIANT currentValue, IUISimplePropertySet commandExecutionProperties)
        {
            if (verb == UI_EXECUTIONVERB.UI_EXECUTIONVERB_EXECUTE)
            {
                switch (commandId)
                {
                    case 100:  // Select Color
                        int val = currentValue.AsInt32();
                        _currentColor = Color.FromArgb(val & 0xff, (val >> 8) & 0xff, (val >> 16) & 0xff);
                        break;
                    case 101:  // Help
                        break;
                    case 102:  // Spinner
                        _strokeSize = currentValue.AsInt32() + 2;
                        break;
                    case 103:  // Exit
                        Close();
                        break;
                    case 104: // Clear
                        completedLines.Clear();
                        Invalidate();
                        break;
                    default:
                        break;
                }
            }
        }

        public void UpdateProperty(int commandId, ref PROPERTYKEY key, ref PROPVARIANT currentValue, out PROPVARIANT newValue)
        {
            // Update the spinner initial value
            if (commandId == 102 && key.fmtid == RibbonPropertyKeys.UI_PKEY_DecimalValue.fmtid)
            {
                newValue = new PROPVARIANT();
                newValue.SetValue(_strokeSize);
            }
            else if (commandId == 100 && key.fmtid == RibbonPropertyKeys.UI_PKEY_Color.fmtid)
            {
                newValue = new PROPVARIANT();
                int color = (_currentColor.B << 16) + (_currentColor.G << 8) + _currentColor.R;
                newValue.SetValue(color);
            }
            // Don't set anything else.
            else throw new NotSupportedException();
        }

        #endregion
    }
}
