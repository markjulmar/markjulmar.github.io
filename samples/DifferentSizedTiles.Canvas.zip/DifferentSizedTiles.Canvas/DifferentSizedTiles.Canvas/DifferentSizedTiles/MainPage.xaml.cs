﻿using DifferentSizedTiles.ViewModels;

namespace DifferentSizedTiles
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void OnPanelSizeChanged(object sender, Windows.UI.Xaml.SizeChangedEventArgs e)
        {
            // Populate DC after first resize so we don't see small-ish items on first render.
            if (DataContext == null)
            {
                DataContext = new MainViewModel();
            }

            // Set the new actual height
            MainViewModel vm = (MainViewModel) DataContext;
            vm.ViewHeight = e.NewSize.Height;
        }
    }
}
