﻿using JulMar.Windows.Mvvm;

namespace DifferentSizedTiles.ViewModels
{
    /// <summary>
    /// This represents a single color box in our view.
    /// </summary>
    public sealed class ColorViewModel : SimpleViewModel
    {
        #region Data
        private int _heightPercent;
        private double _height, _width;
        private double _top, _left;
        #endregion

        /// <summary>
        /// Color for this item
        /// </summary>
        public string Color { get; set; }

        /// <summary>
        /// Index of the item (used for label)
        /// </summary>
        public int Index { get; set; }

        /// <summary>
        /// Row for the item (used for label)
        /// </summary>
        public int Row { get; set; }

        /// <summary>
        /// Column for the item (used for label)
        /// </summary>
        public int Col { get; set; }

        /// <summary>
        /// Left position relative to (0,0).
        /// </summary>
        public double Left
        {
            get { return _left; }
            set { SetPropertyValue(ref _left, value); }
        }

        /// <summary>
        /// Top position - changes when the Height of the GridView
        /// is altered (i.e. screen orientation)
        /// </summary>
        public double Top
        {
            get { return _top; }
            set { SetPropertyValue(ref _top, value); }
        }

        /// <summary>
        /// Width of this item
        /// </summary>
        public double Width
        {
            get { return _width; }
            set { SetPropertyValue(ref _width, value); }
        }

        /// <summary>
        /// Height to use for this item - calculated by the MainViewModel
        /// once it knows the actual height of the GridView using the Height %
        /// </summary>
        public double Height
        {
            get { return _height; }
            set { SetPropertyValue(ref _height, value); }
        }

        /// <summary>
        /// How much of the height to take up as a %
        /// </summary>
        public int HeightPercent
        {
            get { return _heightPercent; }
            set { SetPropertyValue(ref _heightPercent, value); }
        }

        /// <summary>
        /// This indicates if the cell is shared with another item in the 
        /// same column/row (side-by-side)
        /// </summary>
        public bool IsSplitCell { get; set; }

        /// <summary>
        /// Returns a string that represents the current object.
        /// </summary>
        public override string ToString()
        {
            return string.Format("{0}: {1} ({2}x{3}) {4}% [{5},{6}]", Index, Color, Width, Height, HeightPercent, Col, Row);
        }
    }
}
