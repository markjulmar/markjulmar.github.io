﻿using JulMar.Windows.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Windows.UI;

namespace DifferentSizedTiles.ViewModels
{
    /// <summary>
    /// The Main data driver for the application
    /// </summary>
    public sealed class MainViewModel : SimpleViewModel
    {
        #region Data
        private readonly Random _rng = new Random();
        private double _viewHeight = Double.NaN, _viewWidth;
        private readonly List<ColorViewModel> _backingStore;
        #endregion

        /// <summary>
        /// This is set to the actual height of the panel 
        /// it then calculates the proper height and top of each item
        /// </summary>
        public double ViewHeight
        {
            get { return _viewHeight; }
            set
            {
                // First record the overall change in height
                SetPropertyValue(ref _viewHeight, value);

                // Now walk through each item and calculate the final height based
                // on the percentage we randomly chose for this item.
                double top = 0;
                for (int index = 0; index < _backingStore.Count; index++)
                {
                    var cvm = _backingStore[index];
                    if (cvm.Row == 0)
                        top = 0;

                    cvm.Height = _viewHeight*(cvm.HeightPercent/100.0)*.9;

                    if (index > 0 && _backingStore[index - 1].IsSplitCell)
                    {
                        cvm.Top = _backingStore[index - 1].Top;
                    }
                    else
                    {
                        cvm.Top = top;
                        top += cvm.Height;
                    }
                }
            }
        }

        /// <summary>
        /// The calculated width of the panel - this is required so we get scrollbars in the GridView.
        /// </summary>
        public double ViewWidth
        {
            get { return _viewWidth; }
            set { SetPropertyValue(ref _viewWidth, value); }
        }

        /// <summary>
        /// The list of colors
        /// </summary>
        public IList<ColorViewModel> Colors { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public MainViewModel()
        {
            _backingStore = typeof(Colors).GetTypeInfo().DeclaredProperties
                                          .Select(p => new ColorViewModel { Color = p.Name })
                                          .ToList();

            int currentColumn = 0;
            double currentWidth = 0;

            // Calculate the position of each item. 
            for (int i = 0; i < _backingStore.Count; )
            {
                int columnWidth = _rng.Next(200, 500);
                int numberOfColors = _rng.Next(1, 7);
                int trackPct = 0;

                // Create a single column
                for (int c = 0; c < numberOfColors && trackPct < 95 && i < _backingStore.Count; i++, c++)
                {
                    ColorViewModel cvm = _backingStore[i];
                    cvm.Index = i + 1;
                    cvm.Col = currentColumn;
                    cvm.Row = c;
                    cvm.Left = currentWidth;

                    // Decide the height of this item.
                    int maxH = Math.Min(100 - trackPct, 100/numberOfColors);
                    int h = _rng.Next(15, maxH);

                    // Allow it to share row with second item
                    if (c > 0 && _backingStore[i-1].IsSplitCell)
                    {
                        var previousCell = _backingStore[i - 1];
                        cvm.Left = previousCell.Left + previousCell.Width;
                        cvm.Width = previousCell.Width;
                        cvm.HeightPercent = previousCell.HeightPercent;
                        c--;
                    }
                    else
                    {
                        trackPct += h;
                        cvm.HeightPercent = h;

                        if (c > 0 && numberOfColors > 2 && _rng.Next(4) == 1) // 1/4 chance
                        {
                            cvm.Width = (columnWidth / 2.0) - 5;
                            cvm.IsSplitCell = true;
                        }
                        else
                            cvm.Width = columnWidth;
                    }
                }

                // Make sure we always end on 100%
                _backingStore[i - 1].HeightPercent += 100 - trackPct;
                _backingStore[i - 1].Width = columnWidth;
                _backingStore[i - 1].IsSplitCell = false;

                currentColumn++;
                currentWidth += columnWidth;
            }

            // Store off the final colors
            Colors = _backingStore;

            // Store off the final width of the overall view.
            ViewWidth = currentWidth;
        }
    }
}
