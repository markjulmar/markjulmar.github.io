﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;

namespace DifferentSizedTiles
{
    /// <summary>
    /// This is here just to create a binding for the Height/Width on the GridViewItem.
    /// WinRT currently doesn't support attached properties in Style setters.
    /// </summary>
    public class VariableSizedGridView : GridView
    {
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            BindingOperations.SetBinding(element, Canvas.LeftProperty, new Binding { Path = new PropertyPath("Left") });
            BindingOperations.SetBinding(element, Canvas.TopProperty, new Binding { Path = new PropertyPath("Top") });
            BindingOperations.SetBinding(element, WidthProperty, new Binding { Path = new PropertyPath("Width") });
            BindingOperations.SetBinding(element, HeightProperty, new Binding { Path = new PropertyPath("Height") });

            base.PrepareContainerForItemOverride(element, item);
        }
    }
}
