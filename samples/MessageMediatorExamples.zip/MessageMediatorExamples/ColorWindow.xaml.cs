﻿using System.Linq;
using System.Windows;
using System.Windows.Media;

namespace MessageMediatorExamples
{
    /// <summary>
    /// Interaction logic for ColorWindow.xaml
    /// </summary>
    public partial class ColorWindow : Window
    {
        public ColorWindow()
        {
            Loaded += ColorWindowLoaded;
            InitializeComponent();
        }

        void ColorWindowLoaded(object sender, RoutedEventArgs e)
        {
            var colorList = typeof(Brushes).GetProperties().Select(pi => pi.GetValue(null, null));
            color1.ItemsSource = color2.ItemsSource = colorList;
        }
    }
}
