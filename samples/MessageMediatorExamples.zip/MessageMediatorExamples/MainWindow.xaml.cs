﻿using JulMar.Core.Interfaces;
using JulMar.Windows.Mvvm;
using MessageMediatorExamples.ViewModels;
using JulMar.Core;

namespace MessageMediatorExamples
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        private readonly IMessageMediator _messageMediator;

        public MainWindow()
        {
            _messageMediator = ViewModel.ServiceProvider.Resolve<IMessageMediator>();

            // Target the OnChangeColors method
            _messageMediator.RegisterHandler<MainViewModel>(ViewMessages.ChangeColors, OnChangeColors);

            // Register all [MessageMediatorTarget] methods on this object
            _messageMediator.Register(this);

            InitializeComponent();
        }

        private static void OnChangeColors(MainViewModel vm)
        {
            ColorWindow window = new ColorWindow {DataContext = vm};
            window.Show();
        }

        [MessageMediatorTarget(ViewMessages.ChangeFonts)]
        private void OnChangeFonts(MainViewModel vm)
        {
            FontWindow window = new FontWindow() {DataContext = vm};
            window.Show();
        }
    }
}
