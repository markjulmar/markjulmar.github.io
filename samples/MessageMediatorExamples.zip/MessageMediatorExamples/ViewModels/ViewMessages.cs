﻿namespace MessageMediatorExamples.ViewModels
{
    /// <summary>
    /// Messages used by VM + views
    /// </summary>
    public static class ViewMessages
    {
        public const string ChangeColors = "ChangeColors";
        public const string ChangeFonts = "ChangeFonts";
    }
}