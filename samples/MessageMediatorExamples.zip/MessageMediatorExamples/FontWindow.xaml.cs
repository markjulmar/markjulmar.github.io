﻿using System.Windows;

namespace MessageMediatorExamples
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class FontWindow : Window
    {
        public FontWindow()
        {
            InitializeComponent();
        }
    }
}
