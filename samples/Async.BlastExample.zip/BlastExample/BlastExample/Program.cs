﻿using System;
using System.Threading;
using Bio;
using Bio.Web.Blast;
using System.Collections.Generic;

namespace BlastExample
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            const string seq = "ACCTCCACTAGCTTTGTTTGTAGTGATGCTCTGTAGCACCACTGGGAAGCCCTTTAATGAATGTGCCTTTCCGCAAATCACACACACACAAATACACTTATAGAAACAAGGTGATTTTCTTGAA";
            ISequence sequence = new Sequence(Alphabets.DNA, seq);

            var blastService = new NCBIBlastHandler();

            IList<BlastResult> results;

            try
            {
                results = blastService.SubmitRequestAsync(
                    // Sequence to find
                    sequence,
                    // Set parameters using fluid syntax (replace Add eventually?
                    new BlastParameters()
                        .AddEx("Program", "blastn")
                        .AddEx("Database", "ecoli"),
                    // Wait up to 10 seconds for the response and support cancelation
                    new CancellationTokenSource(TimeSpan.FromSeconds(10)).Token).Result;
            }
            catch(AggregateException ex)
            {
                Console.WriteLine("Service is not available: " + ex.Flatten().InnerExceptions[0].Message);
                return;
            }

            if (results == null)
            {
                Console.WriteLine("No results returned.");
                return;
            }

            foreach (var r in results)
            {
                var md = r.Metadata;
                if (md != null)
                {
                    Console.WriteLine("Metadata:");
                    Console.WriteLine("Database: {0}, Program: {1}, Version: {2}", md.Database, md.Program, md.Version);
                    Console.WriteLine("Query Sequence: {0}", md.QuerySequence);
                    Console.WriteLine("Parameter Query: {0}", md.ParameterEntrezQuery);
                    Console.WriteLine("Parameter Expect: {0}", md.ParameterExpect);
                    Console.WriteLine("Parameter Filter: {0}", md.ParameterFilter);
                    Console.WriteLine("Gap Extend: {0}, Open: {1}", md.ParameterGapExtend, md.ParameterGapOpen);
                    Console.WriteLine("Include: {0}, MatchScore: {1}, Mismatch Score: {2}", md.ParameterInclude, md.ParameterMatchScore, md.ParameterMismatchScore);
                    Console.WriteLine("Matrix: {0}, Pattern: {1}", md.ParameterMatrix, md.ParameterPattern);
                    Console.WriteLine("Def: {0}, Query Id: {1}, Query Len: {2}", md.QueryDefinition, md.QueryId, md.QueryLength);
                }
                foreach (var rec in r.Records)
                {
                    Console.WriteLine();
                    Console.WriteLine("Hits:");
                    foreach (var h in rec.Hits)
                    {
                        Console.WriteLine("Id: {0}, Length: {1}", h.Id, h.Length);
                        Console.WriteLine("Accession: {0}, Def: {1}", h.Accession, h.Def);
                        foreach (var hs in h.Hsps)
                        {
                            Console.WriteLine("  Alignment length: {0}", hs.AlignmentLength);
                            Console.WriteLine("  Bit Score: {0}, Density: {1}, EValue: {2}, Gaps: {3}", hs.BitScore, hs.Density, hs.EValue, hs.Gaps);
                            Console.WriteLine("  Hit Sequence: {0}\r\nStart: {1}, End: {2}, Frame: {3}", hs.HitSequence, hs.HitStart, hs.HitEnd, hs.HitFrame);
                        }
                    }
                }
            }
        }
    }
}