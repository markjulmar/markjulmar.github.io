﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Threading;
using System.Threading.Tasks;
using Bio;
using Bio.Web;
using Bio.Web.Blast;

namespace BlastExample
{
    public static class NcbiBlastRequestExtensions
    {
        public static BlastParameters AddEx(this BlastParameters bp, string parameterName, string parameterValue)
        {
            bp.Add(parameterName, parameterValue);
            return bp;
        }

        public static Task<IList<BlastResult>> SubmitRequestAsync(this NCBIBlastHandler handler, ISequence sequence, BlastParameters searchParameters)
        {
            return handler.SubmitRequestAsync(new List<ISequence>(new[] { sequence }), searchParameters, CancellationToken.None);
        }

        public static Task<IList<BlastResult>> SubmitRequestAsync(this NCBIBlastHandler handler, ISequence sequence, BlastParameters searchParameters, CancellationToken cancellationToken)
        {
            return handler.SubmitRequestAsync(new List<ISequence>(new[] { sequence }), searchParameters, cancellationToken);
        }

        public static Task<IList<BlastResult>> SubmitRequestAsync(this NCBIBlastHandler handler, IList<ISequence> sequences, BlastParameters searchParameters)
        {
            return handler.SubmitRequestAsync(sequences, searchParameters, CancellationToken.None);
        }

        public static Task<IList<BlastResult>> SubmitRequestAsync(this NCBIBlastHandler handler, IList<ISequence> sequences, BlastParameters searchParameters, CancellationToken cancellationToken)
        {
            var jobId = handler.SubmitRequest(sequences, searchParameters);
            return Task.Run(async () =>
            {
                cancellationToken.ThrowIfCancellationRequested();

                ServiceRequestInformation info = handler.GetRequestStatus(jobId);
                if (info.Status != ServiceRequestStatus.Waiting 
                    && info.Status != ServiceRequestStatus.Ready
                    && info.Status != ServiceRequestStatus.Queued)
                {
                    throw new BlastException() { ServiceRequestInformation = info };
                }

                do
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    if (info.Status != ServiceRequestStatus.Ready)
                    {
                        if (info.Status == ServiceRequestStatus.Error || info.Status == ServiceRequestStatus.Canceled)
                        {
                            throw new BlastException() { ServiceRequestInformation = info };
                        }
                        
                        await Task.Delay(1000, cancellationToken);
                    }

                    info = handler.GetRequestStatus(jobId);

                } while (info.Status != ServiceRequestStatus.Ready);

                cancellationToken.ThrowIfCancellationRequested();

                if (info.Status != ServiceRequestStatus.Ready)
                {
                    throw new BlastException("Timed out") { ServiceRequestInformation = info };
                }

                return handler.FetchResultsSync(jobId, searchParameters);
            }, cancellationToken);
        }
    }

    [Serializable]
    public class BlastException : Exception
    {
        public ServiceRequestInformation ServiceRequestInformation { get; set; }

        public BlastException()
        {
        }

        public BlastException(string message) : base(message)
        {
        }

        public BlastException(string message, Exception inner) : base(message, inner)
        {
        }

        protected BlastException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
