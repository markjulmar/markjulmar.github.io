using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System.Net;

namespace TfsCmd
{
    class ExecQuery : BaseCommand
    {
        public ExecQuery()
            : base("WQL", "Execute a WorkItem Query.", "Wql [query]")
        {
        }

        public override void Execute(DbParameters tfsServer, string[] args)
        {
            ImpersonateUser impUser = null;

            try
            {
                // Impersonate the expected user.
                // BUGBUG: only works if connected to domain; replaced with network credentials directly to TFS class.
                //if (!string.IsNullOrEmpty(tfsServer.uid))
                //{
                //    impUser = new ImpersonateUser(tfsServer.uid, tfsServer.domain, tfsServer.password, LogonType.LOGON32_LOGON_NEW_CREDENTIALS, LogonProvider.LOGON32_PROVIDER_DEFAULT);
                //}

                // Create creds if necessary
                ICredentials creds = null;
                if (!string.IsNullOrEmpty(tfsServer.uid))
                    creds = new NetworkCredential(tfsServer.uid, tfsServer.password, tfsServer.domain);

                // Connect to TFS and get the work item store.
                TeamFoundationServer tfs = new TeamFoundationServer(tfsServer.TFSServer, creds);
                WorkItemStore store =(WorkItemStore) tfs.GetService(typeof(WorkItemStore));

                // Execute the query and retrieve a collection of workitems
                string wiqlQuery = String.Join(" ", args);
                wiqlQuery = wiqlQuery.Substring(wiqlQuery.IndexOf(' ') + 1);
                WorkItemCollection workitems = store.Query(wiqlQuery);

                Console.WriteLine(wiqlQuery);
                Console.WriteLine();

                foreach (WorkItem workItem in workitems)
                {
                    Console.WriteLine("ID: {0}\nDescription: {1}", workItem.Id, workItem.Description);
                    Console.WriteLine("Area: {0} {1}", workItem.AreaId, workItem.AreaPath);
                    Console.WriteLine("Iteration: {0} {1}", workItem.IterationId, workItem.IterationPath);
                    Console.WriteLine("Created by {0} on {1}", workItem.CreatedBy, workItem.CreatedDate);
                    Console.WriteLine("Changed by {0} on {1}", workItem.ChangedBy, workItem.ChangedDate);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Problem: {0}", e.Message);
            }
            finally
            {
                if (impUser != null)
                    impUser.UndoImpersonation();
            }
        }
    }
}
