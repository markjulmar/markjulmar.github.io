using System;
using System.Collections.Generic;

namespace TfsCmd
{
    class Program
    {
        static ICommand[] commands = 
            {
                new ListProjects(), 
                new ListWebServices(), 
                new ExecQuery(),
                new MoveWorkItem()
            };

        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                DbParameters dbParams = new DbParameters(args);
                string cmdText = args[0];
                foreach (ICommand cmd in commands)
                {
                    if (string.Compare(cmdText, cmd.Name, true) == 0)
                    {
                        cmd.Execute(dbParams, dbParams.extraParams.ToArray());
                        return;
                    }
                }
            }

            ShowHelp();

        }

        private static void ShowHelp()
        {
            Console.WriteLine("TfsCmd [command] [/t tfsserver] [/u user] [/p password] [params]");
            foreach (ICommand cmd in commands)
                Console.WriteLine("{0} - {1}\r\n\tTfsCmd {2}", cmd.Name, cmd.HelpText, cmd.Example);
        }
    }
}
