using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace TfsCmd
{
    class ListProjects : BaseCommand
    {
        public ListProjects() : base("ListProjects", "Lists the active projects on the TF server.", "ListProjects")
        {
        }

        public override void Execute(DbParameters tfsServer, string[] args)
        {
            bool isVerbose = Array.IndexOf<string>(args, "/v") > 0 || Array.IndexOf<string>(args, "/V") > 0;
            try
            {
                using(IDataReader rdr = DbUtilities.ExecuteDataReader(tfsServer, "TfsIntegration",
                    "select project_id, project_name, tbl_projects.state, TemplateName " +
                    "from dbo.tbl_projects, dbo.Templates " +
                    "where dbo.Templates.TemplateID = dbo.tbl_projects.template_id"))
                {
                   while (rdr.Read())
                   {
                       Console.WriteLine("Project Name: {0}", rdr["project_name"]);
                       Console.WriteLine("Status: {0}", rdr["state"]);
                       Console.WriteLine("Guid: {0}", rdr["project_id"]);
                       Console.WriteLine("Process Template: {0}", rdr["TemplateName"]);

                       using (IDataReader rdrProps = DbUtilities.ExecuteDataReader(tfsServer, "TfsIntegration", 
                                "select name, value from tbl_project_properties where project_id=?", rdr["project_id"]))
                       {
                           if (isVerbose)
                           {
                                Console.WriteLine("Defined Properties: ");
                                while (rdrProps.Read())
                                {
                                    Console.WriteLine("Name: {0}", rdrProps["name"]);
                                    Console.WriteLine("{0}", rdrProps["value"]);
                                }
                           }
                           else
                           {
                               string propNames = ""; int i = 0;
                               while (rdrProps.Read())
                               {
                                   if (i > 0)
                                       propNames += ", ";
                                   propNames += rdrProps["name"];
                               }
                               if (propNames.Length > 0)
                                   Console.WriteLine("Defined Properties: {0}", propNames);
                           }

                       }

                       Console.WriteLine();
                   }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to list projects: {0}", ex.Message);
            }
        }
    }
}
