using System;
using System.Collections.Generic;
using System.Text;

namespace TfsCmd
{
    interface ICommand
    {
        string Name { get; }
        string HelpText { get; }
        string Example { get; }
        void Execute(DbParameters tfsServer, string[] args);
    }

    abstract class BaseCommand : ICommand
    {
        string _name;
        string _helpText;
        string _example;

        public BaseCommand(string name, string helpText, string example)
        {
            _name = name;
            _helpText = helpText;
            _example = example;
        }

        public string Name
        {
            get { return _name; }
        }

        public string Example
        {
            get { return _example;  }
        }

        public string HelpText
        {
            get { return _helpText; }
        }

        public abstract void Execute(DbParameters tfsServer, string[] args);
    }
}
