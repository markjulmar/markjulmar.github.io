using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace TfsCmd
{
    class ListWebServices : BaseCommand
    {
        const int DEFAULT_PORT = 8080;

        public ListWebServices() : base("ListServices", "Displays the web services exposed by the TF server.", "ListWebServices")
        {
        }

        public override void Execute(DbParameters tfsServer, string[] args)
        {
            try
            {
                using (IDataReader rdr = DbUtilities.ExecuteDataReader(tfsServer, "TfsIntegration", "select * from dbo.tbl_service_interface"))
                {
                    while (rdr.Read())
                    {
                        bool isWebService = rdr["url"].ToString().StartsWith("/");
                        Console.WriteLine("{0} = {2}{1}",
                            rdr["name"], rdr["url"],
                            (isWebService) ? string.Format("http://{0}:{1}", tfsServer.TFSServer, DEFAULT_PORT) : "");
                    }
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Problem reading services list from TFS: {0}", ex.Message);
            }
        }
    }
}
