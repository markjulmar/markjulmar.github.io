using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Transactions;

namespace TfsCmd
{
    /// <summary>
    /// Lame version to move a work item .. doesn't attempt to fixup anything except iteration (which is project-specific).
    /// It may leave the wrong user in place -- so edit the WI with TeamExplorer after you move it
    /// </summary>
    class MoveWorkItem : BaseCommand
    {
        // Tables where WI are stored.  Do we need to change all?
        readonly string[] WiTables = { "WorkItemsAre", "WorkItemsLatest"/*, "WorkItemsWere"*/ };
        // WI database name
        readonly string WiDatabase = "TfsWorkItemTracking";

        public MoveWorkItem() : base("MoveWorkItem", "Moves a work item from one Team Project to another", "MoveWorkItem [id] [ProjectName]")
        {
        }

        public override void Execute(DbParameters tfsServer, string[] args)
        {
            int id;
            if ((args.Length != 3) ||
                (Int32.TryParse(args[1], out id) == false))
            {
                Console.WriteLine(this.Example);
                return;
            }

            string newProject = args[2];

            try 
            {
                    foreach (string tbl in WiTables)
                        MoveWorkItemInTable(tfsServer, tbl, id, newProject);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to move work item: {0}", ex.Message);
            }

        }

        private void MoveWorkItemInTable(DbParameters tfsServer, string WiTable, int id, string newProject)
        {
            // Step 1: get the workitem info
            IDataReader rdr = DbUtilities.ExecuteDataReader(tfsServer, WiDatabase,
                        "SELECT WorkItems.ID, AreaId, IterationID, Title, TreeNodes.Name as ProjectName, TreeNodes2.Name as IterationName  " +
                            "FROM " + WiTable + " WorkItems, TreeNodes, TreeNodes TreeNodes2 " +
                            "WHERE WorkItems.ID = ? " +
                            "AND TreeNodes.TypeID='-42' AND TreeNodes.ParentID='0' AND TreeNodes.ID = AreaID " +
                            "AND TreeNodes2.TypeID='-44' AND TreeNodes2.ID = IterationID", id);
            if (!rdr.Read())
            {
                Console.WriteLine("Unable to find work item #{0}", id);
            }

            // Dump out existing project info ..
            int oldProjectId = (int)rdr["AreaId"];
            string iterationName = (string)rdr["iterationName"];
            Console.WriteLine("Work Item #{0}: \"{1}\" is currently located in project \"{2} ({3})\"", id, rdr["title"], rdr["projectName"], iterationName);
            rdr.Close();

            // Retrieve the new project id
            int newProjectId;
            if (!DbUtilities.ExecuteScalar<int>(out newProjectId, tfsServer, WiDatabase, "SELECT ID FROM TreeNodes WHERE Name=?", newProject))
            {
                Console.WriteLine("Could not locate project named {0}", newProject);
                return;
            }

            // Validate we are really moving ..
            if (newProjectId == oldProjectId)
            {
                Console.WriteLine("Work item is already associated with target project. No work done.");
                return;
            }

            // Try to match the iteration value in the new project; otherwise default to 1st one found.
            int newIterationId = 0;
            if (!String.IsNullOrEmpty(iterationName))
            {
                if (!DbUtilities.ExecuteScalar<int>(out newIterationId, tfsServer, WiDatabase,
                            "SELECT ID FROM TreeNodes WHERE Name=? AND ParentID=?", iterationName, newProjectId + 1))
                {
                    using (rdr = DbUtilities.ExecuteDataReader(tfsServer, WiDatabase, "SELECT ID, Name FROM TreeNodes WHERE ParentID=?", newProjectId + 1))
                    {
                        if (rdr.Read())
                        {
                            newIterationId = (int)rdr["id"];
                            iterationName = (string)rdr["name"];
                        }
                    }
                }
            }

            // Issue the update
            Console.WriteLine("Moving work item to \"{0} ({1})\"", newProject, iterationName);

            if (newIterationId != 0)
                DbUtilities.ExecuteNonQuery(tfsServer, WiDatabase, "UPDATE " + WiTable + " SET AreaID=?, IterationID=? WHERE id=?", newProjectId, newIterationId, id);
            else
                DbUtilities.ExecuteNonQuery(tfsServer, WiDatabase, "UPDATE " + WiTable + " SET AreaID=?, WHERE id=?", newProjectId, id);
        }
    }
}
