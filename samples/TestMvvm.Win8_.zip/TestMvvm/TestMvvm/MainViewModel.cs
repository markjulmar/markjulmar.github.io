﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JulMar.Windows.Interfaces;
using JulMar.Windows.Mvvm;
using Windows.UI.Popups;
using UICommand = JulMar.Windows.UI.UICommand;

namespace TestMvvm
{
    public class MainViewModel : ViewModel
    {
        private string _color;
        private string _text;
        private bool _changingColor;
        private string[] _colors = {"Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet"};

        public string Color
        {
            get { return _color; }
            set { SetPropertyValue(ref _color, value); }
        }

        public string Text
        {
            get { return _text; }
            set { SetPropertyValue(ref _text, value); }
        }

        public IDelegateCommand ShowPrompt { get; private set; }
        public IDelegateCommand MouseEnter { get; private set; }
        public IDelegateCommand MouseLeave { get; private set; }

        public MainViewModel()
        {
            ShowPrompt = new DelegateCommand(OnShowPrompt);
            MouseEnter = new AsyncDelegateCommand(OnMouseEnter, () => !_changingColor, () => _changingColor = false);
            MouseLeave = new AsyncDelegateCommand(OnMouseLeave, () => !_changingColor, () => _changingColor = false);

            Color = "Red";
            Text = "Windows 8 Loves MVVM";
        }

        private async void OnMouseEnter()
        {
            _changingColor = true;

            foreach (string color in _colors)
            {
                Color = color;
                await Task.Delay(250);
            }
        }

        private async void OnMouseLeave()
        {
            _changingColor = true;

            foreach (string color in _colors.Reverse())
            {
                Color = color;
                await Task.Delay(250);
            }
        }

        private async void OnShowPrompt()
        {
            IMessageVisualizer messageVisualizer = Resolve<IMessageVisualizer>();
            IUICommand result = await messageVisualizer.ShowAsync("Would you like to change the text?", "Windows 8 Loves MVVM",
                                        new MessageVisualizerOptions(UICommand.YesNoCancel));

            if (result == UICommand.Yes)
            {
                Text = "Windows 8 REALLY loves MVVM!";
            }
        }
    }
}
