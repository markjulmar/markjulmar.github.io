﻿using System;
using System.Net.Http;

namespace BookClient
{
    class Program
    {
        static void Main(string[] args)
        {
            HttpClient client = new HttpClient();
            var data = client.GetStringAsync("http://localhost:11081/api/name/").Result;
            Console.WriteLine(data);
        }
    }
}
