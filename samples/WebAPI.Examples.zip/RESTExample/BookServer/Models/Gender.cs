﻿namespace BookServer.Controllers
{
    public enum Gender
    {
        Male,Female
    }
}