﻿using System;
using System.Runtime.Serialization;

namespace BookServer.Controllers
{
    [Serializable, DataContract(Name="person")]
    public class Person
    {
        [DataMember(Name="name")]
        public string Name { get; set; }
        [DataMember(Name = "dob")]
        public DateTime DateOfBirth { get; set; }
        [DataMember(Name = "gender")]
        public Gender Gender { get; set; }
    }
}
