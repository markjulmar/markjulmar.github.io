﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

using BookServer.Controllers;

using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

using WebApplication1;

namespace BookServer
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Add our text/csv support
            GlobalConfiguration.Configuration.Formatters.Add(new CSVFormatter<Person>());

            // Turn on camel casing and enum strings for JSON output
            var jsonFormatter = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            jsonFormatter.SerializerSettings.Converters.Add(new StringEnumConverter());
            jsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver(); 

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
