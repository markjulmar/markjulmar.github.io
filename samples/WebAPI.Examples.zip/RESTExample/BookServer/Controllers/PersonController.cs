﻿using System;
using System.Web.Http;

namespace BookServer.Controllers
{
    public class PersonController : ApiController
    {
        public Person Get()
        {
            return new Person() { Name = "Mark", DateOfBirth = DateTime.Now, Gender = Gender.Male };
        }

    }
}