﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace BookServer.Controllers
{
    [RoutePrefix("api/name")]
    public class NameController : ApiController
    {
        private static List<string> names = new List<string>() { "Gilligan", "Skipper", "Mary Ann", "Ginger", "Professor", "Thurston", "Lovey" };

        public IEnumerable<string> Get()
        {
            return names;
        }

        public IHttpActionResult GetById(int id)
        {


            if (id < 0 || id >= names.Count) 
                return this.BadRequest();

            return this.Ok(names[id]);

            //if (id < 0 || id >= names.Count)
            //    throw new HttpResponseException(HttpStatusCode.BadRequest);

            //return this.Ok(names[id]);

            //try
            //{
            //    string name = names[id];
            //    return Request.CreateResponse(HttpStatusCode.OK, name);
            //}
            //catch (Exception ex)
            //{
            //    return new HttpResponseMessage(HttpStatusCode.BadRequest);
            //}
        }

        /// <summary>
        /// GET /api/name/filter/G
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        [Route("filter/{filter}")]
        public IEnumerable<string> GetByName(string filter)
        {
            return names.Where(n => n.Contains(filter));
        }

        [HttpPost]
        [Route("add")]
        public HttpResponseMessage AddName([FromBody] string name)
        {
            names.Add(name);

            return new HttpResponseMessage(HttpStatusCode.OK);
        }

        [HttpDelete]
        public void Remove(string id)
        {
            names.Remove(id);
        }
    }
}
