﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Web;

namespace WebApplication1
{
    public class CSVFormatter<T> : BufferedMediaTypeFormatter
    {
        public CSVFormatter()
        {
            SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/csv"));
        }


        public override bool CanReadType(Type type)
        {
            return false;
        }

        public override bool CanWriteType(Type type)
        {
            return type == typeof(T) || typeof(IEnumerable<T>).IsAssignableFrom(type);
        }

        public override void WriteToStream(Type type, object value, Stream writeStream, HttpContent content)
        {
            using (var writer = new StreamWriter(writeStream))
            {
                this.WriteHeader(writer);
                IEnumerable<T> collection = value as IEnumerable<T>;
                if (collection != null)
                {
                    foreach (T item in collection)
                    {
                        WriteItem(writer, item);
                    }
                }
                else
                {
                    this.WriteItem(writer, (T)value);
                }
            }
            writeStream.Close();
        }

        static char[] _specialChars = { ',', '\n', '\r', '"' };
        private string Escape(object o)
        {
            if (o == null)
                return "";
            string field = o.ToString();
            return field.IndexOfAny(_specialChars) != -1 ? String.Format("\"{0}\"", field.Replace("\"", "\"\"")) : field;
        }

        private void WriteHeader(StreamWriter writer)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var prop in typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (sb.Length > 0) sb.Append(",");
                sb.Append(this.Escape(prop.Name));
            }

            writer.WriteLine(sb.ToString());
        }
        private void WriteItem(StreamWriter writer, T item)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var prop in typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (sb.Length > 0) sb.Append(",");
                sb.Append(this.Escape(prop.GetValue(item)));
            }
            writer.WriteLine(sb.ToString());
        }
    }
}