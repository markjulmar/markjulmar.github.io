﻿using JulMar.Windows.Mvvm;

namespace ServicesTest
{
    public partial class App
    {
        public App()
        {
            ViewModel.RegisterKnownServiceTypes();
        }
    }
}
