﻿using System;
using System.Collections.Generic;
using JulMar.Windows.Mvvm;
using JulMar.Windows.Interfaces;
using System.Threading;

namespace ServicesTest.ViewModels
{
    /// <summary>
    /// Main View Model
    /// </summary>
    public class MainViewModel : ViewModel
    {
        private string _title, _result;

        /// <summary>
        /// Title for visualizations
        /// </summary>
        public string Title
        {
            get { return _title; }
            set { _title = value; OnPropertyChanged("Title"); }
        }

        /// <summary>
        /// Result
        /// </summary>
        public string Result
        {
            get { return _result; }
            set { _result = value; OnPropertyChanged("Result");}
        }

        /// <summary>
        /// Visualization Command list
        /// </summary>
        public IList<TitledCommand> VisualizationCommands { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public MainViewModel()
        {
            VisualizationCommands = new List<TitledCommand>
            {
                new TitledCommand("Show Message", new DelegatingCommand<string>(OnShowMessage, 
                    s => !string.IsNullOrEmpty(Title) && !string.IsNullOrEmpty(s))),
                new TitledCommand("Show Error", new DelegatingCommand<string>(OnShowError,
                    s => !string.IsNullOrEmpty(Title) && !string.IsNullOrEmpty(s))),        
                new TitledCommand("Show Notification", new DelegatingCommand<string>(OnShowNotification, 
                    s => !string.IsNullOrEmpty(Title))),
            };
        }

        private void OnShowMessage(string message)
        {
            var messageVisualizer = Resolve<IMessageVisualizer>();
            if (messageVisualizer != null)
            {
                Result = Enum.GetName(typeof (MessageResult),
                                      messageVisualizer.Show(Title, message, MessageButtons.YesNoCancel));
            }
        }

        private void OnShowError(string errorMessage)
        {
            var errorVisualizer = Resolve<IErrorVisualizer>();
            if (errorVisualizer != null)
            {
                Result = errorVisualizer.Show(Title, errorMessage).ToString();
            }
        }

        private void OnShowNotification(string message)
        {
            var notifyVisual = Resolve<INotificationVisualizer>();
            if (notifyVisual != null)
            {
                using (notifyVisual.BeginWait(Title, message))
                {
                    // Sleep for 2sec, pretending to work
                    Thread.Sleep(2000);
                }
            }
        }
    }
}
