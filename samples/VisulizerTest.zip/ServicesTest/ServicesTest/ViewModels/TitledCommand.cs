﻿using System.Windows.Input;

namespace ServicesTest.ViewModels
{
    /// <summary>
    /// Simple command + title text
    /// </summary>
    public class TitledCommand
    {
        /// <summary>
        /// Title to display
        /// </summary>
        public string Title { get; private set; }

        /// <summary>
        /// Command to execute
        /// </summary>
        public ICommand Command { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="title"></param>
        /// <param name="cmd"></param>
        public TitledCommand(string title, ICommand cmd)
        {
            Title = title;
            Command = cmd;
        }
    }
}