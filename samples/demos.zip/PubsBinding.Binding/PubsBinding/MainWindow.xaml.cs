﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PubsBinding.Models;

namespace PubsBinding
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            Loaded += new RoutedEventHandler(MainWindow_Loaded);
            InitializeComponent();
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            author firstAuthor;

            using (pubsEntities context = new pubsEntities())
            {
                var AuthorsThatStartWithA =
                     from a in context.authors
                     where a.firstname.StartsWith("A")
                     select a;

                //var AuthorsThatStartWithA =
                //    context.authors.Where(a => a.firstname.StartsWith("A"));

                firstAuthor = AuthorsThatStartWithA.FirstOrDefault();
            }

            //tbFirstName.Text = firstAuthor.firstname;

            //Binding binding = new Binding();
            //binding.Source = firstAuthor;
            //binding.Path = new PropertyPath("firstname");
            //tbFirstName.SetBinding(TextBox.TextProperty, binding);

            //tbFirstName.SetBinding(TextBox.TextProperty,
            //          new Binding("firstname") {Source = firstAuthor});

            DataContext = firstAuthor;

            //tbLastName.Text = firstAuthor.lastname;
            //tbPhone.Text = firstAuthor.phone;
        }

        void OnSave(object sender, RoutedEventArgs e)
        {
            author firstAuthor = (author) DataContext;

            MessageBox.Show(string.Format("{0} {1}", firstAuthor.firstname, firstAuthor.lastname));
        }
    }
}
