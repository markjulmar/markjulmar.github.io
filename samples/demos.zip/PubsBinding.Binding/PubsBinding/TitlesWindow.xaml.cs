﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PubsBinding.Models;

namespace PubsBinding
{
    /// <summary>
    /// Interaction logic for TitlesWindow.xaml
    /// </summary>
    public partial class TitlesWindow : Window
    {
        public TitlesWindow()
        {
            InitializeComponent();
            Loaded += TitlesWindow_Loaded;
        }

        void TitlesWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Could manually load enum
            //categories.Items.Add(BookCategory.Business);
            //categories.Items.Add(BookCategory.Computers);

            // Could use reflection
            //foreach (var item in Enum.GetValues(typeof(BookCategory)))
            //{
            //    categories.Items.Add(item);
            //}

            OnCategorySelected(null, null);
        }

        private void OnCategorySelected(object sender, SelectionChangedEventArgs e)
        {
            if (grid == null)
                return;

            string category = categories.SelectedItem.ToString();

            using (pubsEntities context = new pubsEntities())
            {
                var titles = context.books
                    .Where(b => string.Compare(b.category, category) == 0);

                grid.ItemsSource = titles.ToList();
            }
        }
    }
}
