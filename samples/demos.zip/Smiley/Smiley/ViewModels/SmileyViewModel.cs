﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JulMar.Windows.Mvvm;
using System.Windows.Input;
using System.Threading;

namespace Smiley.ViewModels
{
    public enum StateOfMind
    {
        Happy,
        Angry,
        Sad,
    }

    public class SmileyViewModel : SimpleViewModel
    {
        private StateOfMind _state;
        public StateOfMind State
        {
            get { return _state; }
            set
            {
                _state = value;
                // Notify the UI about the change
                // on the UI thread (for Silverlight)
                _uiContext.Post(o =>
                    OnPropertyChanged("State"), null);
            }
        }

        private SynchronizationContext _uiContext;

        public ICommand ChangeState { get; private set; }

        public SmileyViewModel()
        {
            _uiContext = SynchronizationContext.Current;
            ChangeState = new DelegatingCommand<string>(s => State = (StateOfMind) Enum.Parse(typeof(StateOfMind), s));
        }
    }
}
