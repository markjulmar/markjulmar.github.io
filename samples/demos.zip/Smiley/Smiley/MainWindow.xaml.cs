﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Smiley.ViewModels;
using System.Windows.Threading;

namespace Smiley
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
		    DataContext = new SmileyViewModel();
			this.InitializeComponent();

			// Insert code required on object creation below this point.
		}

	    private DispatcherTimer timer;

        private void OnRandomTimer(object sender, RoutedEventArgs e)
        {
            if (timer != null)
                timer.Stop();
            timer = new DispatcherTimer(TimeSpan.FromMilliseconds(50), DispatcherPriority.Normal, OnChangeFace,
                                        this.Dispatcher) {IsEnabled = true};
        }

        static Random RNG = new Random();

        private void OnChangeFace(object sender, EventArgs e)
        {
            // Pretend data is coming in from some external data source..
            SmileyViewModel vm = (SmileyViewModel) DataContext;

            var validValues = Enum.GetValues(typeof (StateOfMind))
                .Cast<StateOfMind>().ToList();

            // New data arrived.. Change view model.
            // Viewmodel raises INotifyPropertyChanged
            // Data binding will be driven off this.
            var newValue = validValues[RNG.Next(validValues.Count)];
            while (newValue == vm.State)
                newValue = validValues[RNG.Next(validValues.Count)];

            vm.State = newValue;
        }
	}
}