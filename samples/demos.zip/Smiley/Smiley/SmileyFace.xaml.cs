﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Smiley
{
	/// <summary>
	/// Interaction logic for SmileyFace.xaml
	/// </summary>
	public partial class SmileyFace : UserControl
	{
	    public static readonly DependencyProperty TextProperty =
	        TextBlock.TextProperty.AddOwner(typeof (SmileyFace));

	    public string Text
	    {
            get { return (string) base.GetValue(TextProperty); }
            set { base.SetValue(TextProperty, value);}
	    }

	    public static readonly DependencyProperty FillProperty =
	        Shape.FillProperty.AddOwner(typeof (SmileyFace),
	                                    new FrameworkPropertyMetadata(Brushes.Yellow,
	                                                                  FrameworkPropertyMetadataOptions.AffectsRender));

        //public static readonly DependencyProperty FillProperty =
        //    DependencyProperty.Register("Fill",
        //                                typeof (Brush), typeof (SmileyFace),
        //                                new FrameworkPropertyMetadata(Brushes.Yellow,
        //                                                              FrameworkPropertyMetadataOptions.AffectsRender));
        
        public Brush Fill
        {
            get { return (Brush)base.GetValue(FillProperty); }
            set { base.SetValue(FillProperty, value); }
        }
        
        //private Brush _fill;
        //public Brush Fill
        //{
        //    get { return _fill; }
        //    set { _fill = value;
        //        if (faceEllipse != null)
        //            faceEllipse.InvalidateVisual();
        //    }
        //}

	    public SmileyFace()
		{
            Fill = Brushes.Yellow;
            this.InitializeComponent();
		}
	}
}