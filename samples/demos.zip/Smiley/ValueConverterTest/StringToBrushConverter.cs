﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows.Media;

namespace ValueConverterTest
{
    // Declare so we can use this in XAML.
    // XAML does not allow generics.
    public class StringColorDictionary : Dictionary<string,Brush>
    {
        public StringColorDictionary()
        {
        }
    }

    [ValueConversion(typeof(string), typeof(Brush))]
    public class StringToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string text = value.ToString();

            var colorDictionary = (StringColorDictionary)parameter;

            Brush brush;
            if (colorDictionary.TryGetValue(text, out brush))
                return brush;

            return Brushes.Black;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
