﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqLambda
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] names = {"Larry", "Curly", "Moe",
                             "Joe", "Mike", "Carl", "Jim",
                             "Alice", "Linda", "Katy", "Amanda"};

            //List<string> results = new List<string>();
            //foreach (var name in names)
            //{
            //    if (name.Length >= 4)
            //        results.Add(name);
            //}

            //var results = from name in names
            //              where name.Length >= 4
            //              orderby name 
            //              select name;

            //var results = names.Where(name => name.Length >= 4)
            //    .OrderBy(name => name)
            //    .Select(name => name);

            //Func<string, bool> whereClause = 
            //    delegate(string input)
            //    {
            //        return input.Length >= 4;
            //    };

            var results = names
                .Where(input => input.Length >= 4)
                .OrderBy(name => name);

            int count = 0;
            foreach (var result in results)
            {
                //if (count++ > 3)
                //    break;
                Console.WriteLine( result );
            }
        }

        private static string OrderStrings(string input)
        {
            return new string(input.Reverse().ToArray());
        }

        //private static bool StringLenGreater4(string input)
        //{
        //    return input.Length >= 4;
        //}

        //private delegate bool StringWhereClause(string input);

    }

    static class Extensions
    {
        public static IEnumerable<T> InternalWhere<T>(this IEnumerable<T> source, Func<T, bool> whereClause)
        {
            //List<T> results = new List<T>();
            foreach (T entry in source)
            {
                if (whereClause(entry) == true)
                    yield return entry;
            }
            //return results;
        }
    }
}
