﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Vocabulous
{
    class Program
    {
        static void Main(string[] args)
        {
            XDocument doc = XDocument.Load(@"vocabwords.xml");

            var words = doc.Root.Elements("letter")
                .ToDictionary(xe => xe.Attribute("value").Value,
                              xe => xe.Elements("word")
                                      .Select(word => word.Value));

            foreach (var entry in words)
            {
                Console.WriteLine("Letter: {0}", entry.Key);
                foreach (var item in entry.Value)
                {
                    Console.WriteLine( "\t{0}", item );
                }
            }

            // Get the letter with the most words
            var letterWithMostWords =
                words.OrderByDescending(kvp => kvp.Value.Count())
                     .Select(kvp => new { Letter = kvp.Key, Count = kvp.Value.Count() })
                     .First();
            Console.WriteLine( "Letter with most words: {0}, Count={1}", letterWithMostWords.Letter, letterWithMostWords.Count );

            // Get the longest words
            //var longestWord =
            //    words.SelectMany(kvp => kvp.Value)
            //        .OrderByDescending(word => word.Length)
            //        .First();

            var longestWord =
                words.OrderByDescending(kvp => kvp.Value.Count())
                    .First().Value
                    .OrderByDescending(word => word.Length)
                    .First();

            Console.WriteLine("Longest word is: {0}", longestWord);

            longestWord = "";
            foreach (var item in words)
            {
                foreach (var word in item.Value)
                {
                    if (word.Length > longestWord.Length)
                        longestWord = word;
                }
            }

            Console.WriteLine( "Longest word (2) is: {0}", longestWord );
        }
    }
}
