﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PubsBinding.Models
{
    public enum BookCategory
    {
        Business,
        Cooking,
        Computers,
        Psychology, 
        Fiction,
    }
}
