﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PubsBinding.Models;
using PubsBinding.ViewModels;

namespace PubsBinding
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            Loaded += new RoutedEventHandler(MainWindow_Loaded);
            InitializeComponent();
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            DataContext = new MainAuthorsViewModel();
        }

        //void OnSave(object sender, RoutedEventArgs e)
        //{
        //    var firstAuthor = (AuthorViewModel) DataContext;

        //    MessageBox.Show(firstAuthor.Name);
        //}
    }
}
