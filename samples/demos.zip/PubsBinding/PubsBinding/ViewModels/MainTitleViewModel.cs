﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JulMar.Windows.Mvvm;
using PubsBinding.Models;

namespace PubsBinding.ViewModels
{
    public class MainTitleViewModel : SimpleViewModel
    {
        private BookCategory _selectedCategory;
        public BookCategory SelectedCategory
        {
            get { return _selectedCategory; }
            set
            {
                _selectedCategory = value; 
                OnPropertyChanged(() => SelectedCategory);
                OnPropertyChanged(() => Books);
            }
        }

        public IEnumerable<BookCategory> AvailableCategories
        {
            get
            {
                return Enum.GetValues(typeof (BookCategory))
                    .Cast<BookCategory>();
            }
        }

        public IEnumerable<BookViewModel> Books
        {
            get
            {
                int index = 1;
                string selectedCategory = SelectedCategory.ToString();
                using (pubsEntities context = new pubsEntities())
                {
                    var titles = context.books
                        .Where(b => string.Compare(b.category, selectedCategory) == 0);

                    return titles
                        .ToList()
                        .Select(b => new BookViewModel(index++, b));
                }
            }
        }
    }
}
