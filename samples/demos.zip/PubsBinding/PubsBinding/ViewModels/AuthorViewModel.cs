﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using JulMar.Windows.Mvvm;
using PubsBinding.Models;

namespace PubsBinding.ViewModels
{
    public class AuthorViewModel : SimpleViewModel
    {
        private MainAuthorsViewModel _parent;
        private author _author;

        public AuthorViewModel(MainAuthorsViewModel parent, author author)
        {
            _parent = parent;
            _author = author;
        }

        public string Name
        {
            get { return _author.firstname + " " + _author.lastname; }
        }

        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set
            {
                if (_isSelected != value)
                {
                    _isSelected = value;
                    OnPropertyChanged("IsSelected");
                    _parent.OnAuthorSelectionChanged(this);

                    IsExpanded = _isSelected;
                }
            }
        }

        private bool _isExpanded;
        public bool IsExpanded
        {
            get { return _isExpanded; }
            set { _isExpanded = value; OnPropertyChanged("IsExpanded"); }
        }

        public string FirstName
        {
            get { return _author.firstname; }
            set
            {
                _author.firstname = value; 
                OnPropertyChanged(() => FirstName);
                OnPropertyChanged(() => Name);
            }
        }

        public string LastName
        {
            get { return _author.lastname; }
            set
            {
                _author.lastname = value;
                OnPropertyChanged(() => Name);
                OnPropertyChanged(() => LastName);
            }
        }

        public string PhoneNumber
        {
            get { return _author.phone; }
            set { _author.phone = value; OnPropertyChanged("PhoneNumber"); }
        }

        public IList<BookViewModel> AuthoredTitles
        {
            get
            {
                int index = 1;
                using (pubsEntities ctx = new pubsEntities())
                {
                    return ctx.authors
                        .First(a => a.id == _author.id)
                        .books.Select(b => new BookViewModel(index++, b))
                        .ToList();
                }
            }
        }
    }
}
