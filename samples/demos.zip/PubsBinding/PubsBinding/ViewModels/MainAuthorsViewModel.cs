﻿using System;
using System.Collections.Generic;
using System.Linq;
using JulMar.Windows.Mvvm;
using PubsBinding.Models;
using System.Windows.Input;
using JulMar.Windows.Interfaces;

namespace PubsBinding.ViewModels
{
    public class MainAuthorsViewModel : ViewModel
    {
        public IList<AuthorViewModel> Authors { get; private set; }

        private AuthorViewModel _selectedAuthor;
        public AuthorViewModel SelectedAuthor
        {
            get { return _selectedAuthor; }
            set
            {
                if (_selectedAuthor != value)
                {
                    if (_selectedAuthor != null)
                        _selectedAuthor.IsSelected = false;

                    _selectedAuthor = value;

                    if (_selectedAuthor != null)
                        _selectedAuthor.IsSelected = true;

                    OnPropertyChanged("SelectedAuthor", "IsAuthorSelected");
                }
            }
        }

        public bool IsAuthorSelected
        {
            get { return SelectedAuthor != null; }
        }

        //public ICommand ShowAuthor { get; private set; }

        public MainAuthorsViewModel()
        {
            //ShowAuthor = new DelegatingCommand(OnShowAuthor, () => SelectedAuthor != null);

            using (pubsEntities context = new pubsEntities())
            {
                var allAuthors =
                    from a in context.authors
                    select a;
                Authors = allAuthors
                    .ToList()
                    .Select(a => new AuthorViewModel(this, a))
                    .ToList();
            }

            SelectedAuthor = null; //Authors.FirstOrDefault();
        }

        public void ShowAuthor()
        {
            OnShowAuthor();
        }

        void OnShowAuthor()
        {
            IMessageVisualizer notificationVisualizer = Resolve<IMessageVisualizer>();
            if (notificationVisualizer != null)
            {
                notificationVisualizer.Show("", SelectedAuthor.Name, MessageButtons.OK);
            }
            //MessageBox.Show(SelectedAuthor.Name);
        }

        internal void OnAuthorSelectionChanged(AuthorViewModel authorViewModel)
        {
            SelectedAuthor = authorViewModel;
        }
    }
}
