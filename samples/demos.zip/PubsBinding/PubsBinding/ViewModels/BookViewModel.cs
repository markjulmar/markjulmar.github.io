﻿using System;
using JulMar.Windows.Mvvm;
using PubsBinding.Models;
using System.Threading;

namespace PubsBinding.ViewModels
{
    public class BookViewModel : SimpleViewModel
    {
        private readonly int _index;
        private readonly book _book;

        public BookViewModel(int index, book book)
        {
            _index = index;
            _book = book;
        }

        public int RowIndex
        {
            get { return _index; }
        }

        public string Title
        {
            get { return _book.title; }
            set
            {
                string newTitle = value;

                if (newTitle == null)
                    throw new Exception("Missing title");

                newTitle = newTitle.Trim();
                if (string.IsNullOrEmpty(newTitle))
                    throw new Exception("Missing title");

                if (_book.title != newTitle)
                {
                    _book.title = newTitle;
                    OnPropertyChanged(() => Title);
                }
            }
        }

        public BookCategory Category
        {
            get
            {
                BookCategory bc;
                if (Enum.TryParse(_book.category, out bc))
                    return bc;

                return BookCategory.Fiction;
            }

            set { _book.category = value.ToString(); OnPropertyChanged(() => Category); }
        }

        public double Price
        {
            get
            {
                return (_book.price == null)
                    ? 0 
                    : (double) _book.price;
            }
            set
            {
                if (value == 0)
                    _book.price = null;
                else
                    _book.price = (decimal) value; 
                OnPropertyChanged(() => Price);
            }
        }

        public DateTime PublishDate
        {
            get { return _book.pubdate; }
            set { _book.pubdate = value; OnPropertyChanged(() => PublishDate); }
        }
    }
}
